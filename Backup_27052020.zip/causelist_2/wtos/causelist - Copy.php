<? 
$okImg=$site['url'].'image/tick.png';
$importImg=$site['url'].'image/import.png';
function getFile($link)
{
	if($link=='')
	{
	  echo 'Missing Link';
	  exit();
	
		/*$filename = "sample.html";
		$handle = fopen($filename, "rb");
		$contents = fread($handle, filesize($filename));
		fclose($handle);*/
	}else
	{
		$contents = file_get_contents($link);
		
	}
	if($contents!='')
	{
		$fString=strip_tags($contents);
		return $fString;
	}
}




if(count($os->department)!=3)
{
  echo "Department Error";  exit();
}

function checkMonthlyList()
{
 global $os;
  $query="SELECT count(*) c, DATE_FORMAT(dailydate, '%d-%m-%Y') d FROM dailylist";
  $cdl=$os->mq($query);
  $cdl=$os->mfa($cdl);
  return $cdl;

}
function checkDailyList()
{
 global $os;
  $query="SELECT count(*) c, DATE_FORMAT(dailydate, '%d-%m-%Y') d FROM dailylist";
  $cdl=$os->mq($query);
  $cdl=$os->mfa($cdl);
  return $cdl;

}

function totalCaseData()
{
 global $os;
  $query="SELECT count(*) c FROM dailylist";
  $cdl=$os->mq($query);
  $cdl=$os->mfa($cdl);
  return $cdl;

}
function getItemsNo($val)
{   
      $finalItems=array();
	  
	 
      preg_match_all("/ITEM .*?MONTHLY LIST/", str_replace("\n",',',$val), $monthlyMatches);
	 
	  
	  
	  
	  if(is_array($monthlyMatches[0]))
	  {
	  
	    foreach($monthlyMatches[0] as $cc=>$items)
		{
		
		  if($items!='')
		  {
				$items=str_replace("\n",',',$items);
				$replaceBlank=array('MONTHLY LIST','FROM THE ','OF THE','COMBINED','ITEM', 'NOS.','NO.','.');
				$itemStr=str_replace( $replaceBlank,'', $items);  
				
				$itemStr=str_replace( array('AND','TO'),array(',','-'), $itemStr); // general format
		  	// _d($itemStr); #5656
				
				
				
				$itemStrA=preg_match_all('/[0-9]+.?-.?[0-9]+/',$itemStr,$itemRange);
				$itemStr=str_replace( $itemRange[0],'', $itemStr); // general format
				
		  // _d($itemRange);
		   #---------------$itemRange extract ----------------
	
		   foreach($itemRange[0] as $itemRangeStr)
		   {
		    $itemRangeStrA=explode('-',$itemRangeStr);
			
		    $itemRangeA=range($itemRangeStrA[0],$itemRangeStrA[1]);
		    foreach($itemRangeA as $v)
			{
			 $finalItems[]= $v;
			} 
			 
		
		   }
		   
		   
		   
		   
		   
		   $itemStr=str_replace(' ',',',$itemStr);
		   $itemStrA=preg_match_all('/[0-9]+/',$itemStr,$itemSingles);
		    foreach($itemSingles[0] as $v)
			{
			 $finalItems[]= $v;
			} 
		   
		
		   
		   
		 }
		 }
		 
		// _d($items);
	   // _d($finalItems);
	  
	  }
	 
	  return $finalItems;
	 

}

 function extractCaseVal($caseString)
 {
 
   $case=array();
    preg_match_all("/[A-Z]+\s\d+\/\d+\s/", $caseString, $matches);
	
	if(is_array($matches[0]))
	{
	     $case['CASE NO']=implode("\n",$matches[0]);
	     $caseString=str_replace($matches[0],'',$caseString);
	
	}
	  $lines=explode("\n",$caseString);
	if(is_array($lines))
	{
	     
		 $fLA=explode(' Vs',$lines[0]);
		 
		 $causT1=$fLA[0];
		 $pt1=$fLA[1];
		 
		 if($pt1=='')
		 {
					  $fLA=explode(' And',$lines[0]);
					  $causT1=$fLA[0];
					  $pt1=$fLA[1];
		 }
		 
		 
		 
		 
		 if(substr($lines[1],0,2)=='  ')
		 {
		    $causT2=$lines[1];
		 }else
		 {
		   $pt2=$lines[1];
		   $causT2=$lines[2];
		 
		 }
		 
		$case['CAUSE TITLE']=trim("$causT1 Vs $causT2");
		$case['PTNR']=trim("$pt1 $pt2");
		 
		
	
	}
	
  
  
 return $case;
  
	
	
   
 }

function importDailyList()
{
 
  
	global $os;
	
	$warningList='';## not implemented
	$dailydate=$os->now();
	$modifyDate=$os->now();
	$modifyBy=$os->userDetails['adminId']; 
	$addedDate=$os->now();
	$addedBy=$os->userDetails['adminId'];
	$link=$os->getByFld('caselinks','caselinksId','1','daily');
	
    $caseStr=getFile($link);
    $os->mq('TRUNCATE TABLE dailylist');
   ## search 5555
   $strArr=preg_split("/COURT NO\./", $caseStr,-1);
   foreach($strArr as $val)
   {
        $importSQL='';
		$sqlStrArr=array();
		$courtNo =(int)$val; # echo $courtNo.'<br>';
		if($courtNo<1)continue;		 
		$floorA = explode("\n",$val);
		$floors =$floorA['1'];
		
		
		
		
		#-----  monthly data search
		
		$monthlyItems= getItemsNo($val); // 2012-01-24  
		
		 $cases=	 preg_split('/\n(\d+)\.\s/', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
		#----- monthly data search end 
	    	foreach($cases as $cvK=>$casesVal)
					{
					
					    $itemNo=$cases[$cvK-1];
						
						if((int) $itemNo>0)
						{
					      $cV=extractCaseVal($casesVal);
						  
						  $caseNo=$cV['CASE NO'];
						  $title=$cV['CAUSE TITLE'];
						  $advocate=$cV['PTNR'];
						
						}
						## 	$courtNo $floor $itemNo $caseNo $title $advocate $monthlyItems 
						
						## generateSql  666
						$sqlStrArr[]= "(NULL , '$itemNo', '$caseNo', '$title', '$advocate', '$floors', '$courtNo', '$monthlyItems', '$warningList', '$dailydate', '0', '$addedBy', '$addedDate', '$modifyBy', '$modifyDate') ";
						
						
						
						
						 
						
						
						 ## generateSql   666
					   
					} 
					if(count($sqlStrArr)>0){
					$importSQL = implode(',',$sqlStrArr);
					}
					
					## import to table  888
				
				if($importSQL!=''){
				$importSQL='INSERT INTO `causelist`.`dailylist` (`dailylistId` ,`itemNo` ,`caseNo` ,`title` ,`advocate` ,`floors` ,`courtNo` ,`monthlyItems` ,`warningList` ,`dailydate` ,`ignorData` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ' . $importSQL;
				$os->mq($importSQL );
				}
				     ## import to table  888
   
   }
   
   ## search 5555
   
  // 
 
}
function importMonthlyList()
{
   
 
}

function getItemsNo($val)
{   
      $finalItems=array();
	  
	 
      preg_match_all("/ITEM .*?MONTHLY LIST/", str_replace("\n",',',$val), $monthlyMatches);
	 
	  
	  
	  
	  if(is_array($monthlyMatches[0]))
	  {
	  
	    foreach($monthlyMatches[0] as $cc=>$items)
		{
		
		  if($items!='')
		  {
				$items=str_replace("\n",',',$items);
				$replaceBlank=array('MONTHLY LIST','FROM THE ','OF THE','COMBINED','ITEM', 'NOS.','NO.','.');
				$itemStr=str_replace( $replaceBlank,'', $items);  
				
				$itemStr=str_replace( array('AND','TO'),array(',','-'), $itemStr); // general format
		  	// _d($itemStr); #5656
				
				
				
				$itemStrA=preg_match_all('/[0-9]+.?-.?[0-9]+/',$itemStr,$itemRange);
				$itemStr=str_replace( $itemRange[0],'', $itemStr); // general format
				
		  // _d($itemRange);
		   #---------------$itemRange extract ----------------
	
		   foreach($itemRange[0] as $itemRangeStr)
		   {
		    $itemRangeStrA=explode('-',$itemRangeStr);
			
		    $itemRangeA=range($itemRangeStrA[0],$itemRangeStrA[1]);
		    foreach($itemRangeA as $v)
			{
			 $finalItems[]= $v;
			} 
			 
		
		   }
		   
		   
		   
		   
		   
		   $itemStr=str_replace(' ',',',$itemStr);
		   $itemStrA=preg_match_all('/[0-9]+/',$itemStr,$itemSingles);
		    foreach($itemSingles[0] as $v)
			{
			 $finalItems[]= $v;
			} 
		   
		
		   
		   
		 }
		 }
		 
		// _d($items);
	   // _d($finalItems);
	  
	  }
	 
	  return $finalItems;
	 

}

function getInnerContent($startkey,$endKey,$str)
{
   $rs='NO RESULTS';
   $ex='(.*?)';
  echo  $rex ="/$startkey $ex $endKey/";
   
      if(preg_match_all($rex , $str, $matches))
  {
   if($matches[0]!='')
   {
     unset($matches[0]);
   }
   $rs= $matches;
  }
 
   
   
   return $rs;

}
 
?>