<?php
include('includes/config.php');
include('top.php');

// config 

$rowId=$_GET['editRowId'];
$listPAGE='smsTemplate';
$primeryTable='smstemplate';
$primeryField='smstemplateId';
$editHeader='EDIT SMS TEMPLATE';
// get row data
if($rowId)
  {
        
		 $where="$primeryField='$rowId'";
		$pageData=$os->getT($primeryTable,'',$where);
		
		
		if(isset($pageData[0]))
		{
		  $pageData=$pageData[0];
		   $accessStr  =  $pageData['access'];
		  if($accessStr!=''){$accessArr = explode(',',$accessStr);}
		  
		}
        
  }




$active=array('Active'=>'Active','Inactive'=>'Inactive');
//$adminAccess=array('0'=>'No','1'=>'Yes');
?>

	<table class="container">
				<tr>
					<td   class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td   class="middle" style="padding-left:5px;">
			  
			  
			 <div class="formsection">
						<h3><?php  echo $editHeader; ?></h3>
						
						<form  action="<? echo $listPAGE ?>.php" method="post"   enctype="multipart/form-data">
						
						
						
						<fieldset class="cFielSet"  >
						<legend  class="cLegend"> SMS Details</legend>
						<span>    </span> 
						
						<table border="0" class="formClass"   >
						
						
						<tr >
							<td>Title </td>
							<td>
								<input value="<?php if(isset($pageData['templateTitle'])){ echo $pageData['templateTitle']; } ?>" type="text" name="templateTitle" class="textbox fWidth"/>
							</td>
							
						</tr>
						
						<tr >
							<td>SMS Text </td>
							<td colspan="4">
								<textarea  name="smsText" id="smsText" rows="5" cols="50"><?php if(isset($pageData['smsText'])){ echo stripslashes($pageData['smsText']); } ?></textarea>
						
							
							
							
							</td>
							<td><? foreach($os->smsKey as $key=>$val){ echo $key; }?></td>

														
						</tr>
						
						<tr >
							<td>Active </td>
							<td>
								<select name="active" >	  
								<?php	$os->onlyOption($active,$pageData['active']); ?>
								</select>
							</td>
						</tr>
						
						<tr >
							<td>Priority </td>
							<td>
								<input value="<?php if(isset($pageData['priority'])){ echo $pageData['priority']; } ?>" type="text" name="priority" class="textbox fWidth"/>
							</td>
							
						</tr>
						
							</table>
							
						
						            
						     
											
						
						</fieldset>
						
						
						
						<input type="submit" class="submit"  value="Save" />	
									<input type="button" class="submit"  value="Cancel" 
									onclick="javascript:window.location='<? echo $listPAGE ?>.php';" />	
									
									
									 <input type="hidden" name="rowId" value="<?php echo $rowId; ?>" />
                                     <input type="hidden" name="operation" value="updateField" />
						
						
						
						
						
						
						
						
						</form>
						
					</div>
			  </td>
			  </tr>
			</table>


					

   
	<? include('bottom.php')?>