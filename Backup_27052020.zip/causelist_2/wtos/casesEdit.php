<?php
include('includes/config.php');
include('top.php');

// config 

$rowId=$_GET['editRowId'];
$listPAGE='cases';
$primeryTable='cases';
$primeryField='casesId';
$editHeader='Edit Cases';
$addHeader='Add Cases';
$listPAGEUrl=$listPAGE.'.php?'.$os->addParams(array('hideTopLeft'),'');
// get row data
if($rowId)
  {
        
		
		$where="$primeryField='$rowId'";
		$pageData=$os->getT($primeryTable,'',$where);
		
		
		if(isset($pageData[0]))
		{
		  $pageData=$pageData[0];
		}
        
  }else{ $editHeader=$addHeader;  }

?>

	<table class="container">
				<tr>
					<td   class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td   class="middle" style="padding-left:5px;">
			  
			  
			 <div class="formsection">
						<h3><?php  echo $editHeader; ?></h3>
						
						<form  action="<? echo $listPAGEUrl ?>" method="post"   enctype="multipart/form-data"  

id="recordEditForm"  >
												
						<fieldset class="cFielSets"  >
						<legend  class="cLegend">Records Details</legend>
						<span>    </span> 
						
						<table border="0" class="formClass"   >
												
						
<tr >
	  									<td>SL No </td>
										<td><input value="<?php if(isset($pageData['slNo'])){ echo $pageData['slNo']; } ?>" type="text" name="slNo" id="slNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Date </td>
										<td><input value="<?php if(isset($pageData['dated'])){ echo $pageData['dated']; } ?>" type="text" name="dated" id="dated" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Case No </td>
										<td><input value="<?php if(isset($pageData['caseNo'])){ echo $pageData['caseNo']; } ?>" type="text" name="caseNo" id="caseNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Title </td>
										<td><input value="<?php if(isset($pageData['title'])){ echo $pageData['title']; } ?>" type="text" name="title" id="title" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Dept. </td>
										<td><select name="dept" id="dept" class="textbox fWidth" >	<? 
										  $os->onlyOption($os->department,$pageData['dept']);	?></select>	
  
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Tag </td>
										<td><input value="<?php if(isset($pageData['tag'])){ echo $pageData['tag']; } ?>" type="text" name="tag" id="tag" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>HOD </td>
										<td><input value="<?php if(isset($pageData['hod'])){ echo $pageData['hod']; } ?>" type="text" name="hod" id="hod" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Client Rep. </td>
										<td><input value="<?php if(isset($pageData['clientRep'])){ echo $pageData['clientRep']; } ?>" type="text" name="clientRep" id="clientRep" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Background </td>
										<td><input value="<?php if(isset($pageData['background'])){ echo $pageData['background']; } ?>" type="text" name="background" id="background" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Instruction </td>
										<td><input value="<?php if(isset($pageData['Instruction'])){ echo $pageData['Instruction']; } ?>" type="text" name="Instruction" id="Instruction" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Aor No </td>
										<td><input value="<?php if(isset($pageData['aorNo'])){ echo $pageData['aorNo']; } ?>" type="text" name="aorNo" id="aorNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Aor-Councel </td>
										<td><input value="<?php if(isset($pageData['aorCouncel'])){ echo $pageData['aorCouncel']; } ?>" type="text" name="aorCouncel" id="aorCouncel" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Councel-1 </td>
										<td><input value="<?php if(isset($pageData['councel_1'])){ echo $pageData['councel_1']; } ?>" type="text" name="councel_1" id="councel_1" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Councel-2 </td>
										<td><input value="<?php if(isset($pageData['councel_2'])){ echo $pageData['councel_2']; } ?>" type="text" name="councel_2" id="councel_2" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Remarks </td>
										<td><input value="<?php if(isset($pageData['remarks'])){ echo $pageData['remarks']; } ?>" type="text" name="remarks" id="remarks" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Status </td>
										<td><select name="status" id="status" class="textbox fWidth" >	<? 
										  $os->onlyOption($os->caseStatus,$pageData['status']);	?></select>	
  
										</td>						
										</tr>
											
										
										
						
						</table>
							
						
						            
						     
											
						
						</fieldset>
						
						
						
						<input type="submit" class="submit"  value="Save" />	
									<input type="button" class="submit  popupHide"  value="Cancel" 	onclick="os.jump('<?php echo $listPAGEUrl ?>');" />
									
									
									 <input type="hidden" name="rowId" value="<?php echo $rowId; ?>" />
                                     <input type="hidden" name="operation" value="updateField" />
						
						
						
						
						
						
						
						
						</form>
						
					</div>
			  </td>
			  </tr>
			</table>


				<script>
				 dateCalander();
				</script>	

   
	<? include('bottom.php')?>