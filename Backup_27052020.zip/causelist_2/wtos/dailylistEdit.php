<?php
include('includes/config.php');
include('top.php');

// config 

$rowId=$_GET['editRowId'];
$listPAGE='dailylist';
$primeryTable='dailylist';
$primeryField='dailylistId';
$editHeader='Edit Dailylist';
$addHeader='Add Dailylist';
$listPAGEUrl=$listPAGE.'.php?'.$os->addParams(array('hideTopLeft'),'');
// get row data
if($rowId)
  {
        
		
		$where="$primeryField='$rowId'";
		$pageData=$os->getT($primeryTable,'',$where);
		
		
		if(isset($pageData[0]))
		{
		  $pageData=$pageData[0];
		}
        
  }else{ $editHeader=$addHeader;  }

?>

	<table class="container">
				<tr>
					<td   class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td   class="middle" style="padding-left:5px;">
			  
			  
			 <div class="formsection">
						<h3><?php  echo $editHeader; ?></h3>
						
						<form  action="<? echo $listPAGEUrl ?>" method="post"   enctype="multipart/form-data"  

id="recordEditForm"  >
												
						<fieldset class="cFielSets"  >
						<legend  class="cLegend">Records Details</legend>
						<span>    </span> 
						
						<table border="0" class="formClass"   >
												
						
<tr >
	  									<td>Item No </td>
										<td><input value="<?php if(isset($pageData['itemNo'])){ echo $pageData['itemNo']; } ?>" type="text" name="itemNo" id="itemNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Case No </td>
										<td><input value="<?php if(isset($pageData['caseNo'])){ echo $pageData['caseNo']; } ?>" type="text" name="caseNo" id="caseNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Title </td>
										<td><input value="<?php if(isset($pageData['title'])){ echo $pageData['title']; } ?>" type="text" name="title" id="title" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Advocate </td>
										<td><input value="<?php if(isset($pageData['advocate'])){ echo $pageData['advocate']; } ?>" type="text" name="advocate" id="advocate" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Floor </td>
										<td><input value="<?php if(isset($pageData['floor'])){ echo $pageData['floor']; } ?>" type="text" name="floor" id="floor" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Court No </td>
										<td><input value="<?php if(isset($pageData['courtNo'])){ echo $pageData['courtNo']; } ?>" type="text" name="courtNo" id="courtNo" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>MonthlyItems </td>
										<td><input value="<?php if(isset($pageData['monthlyItems'])){ echo $pageData['monthlyItems']; } ?>" type="text" name="monthlyItems" id="monthlyItems" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Warning List </td>
										<td><input value="<?php if(isset($pageData['warningList'])){ echo $pageData['warningList']; } ?>" type="text" name="warningList" id="warningList" class="textbox fWidth"/>
										</td>						
										</tr>
											
										
										<tr >
	  									<td>Dated </td>
										<td><input value="<?php if(isset($pageData['dailydate'])){ echo $os->showDate($pageData['dailydate']); } ?>" type="text" name="dailydate" id="dailydate" class="dtpk textbox fWidth"/>
										</td>						
										</tr>
											
										
										
						
						</table>
							
						
						            
						     
											
						
						</fieldset>
						
						
						
						<input type="submit" class="submit"  value="Save" />	
									<input type="button" class="submit  popupHide"  value="Cancel" 	onclick="os.jump('<?php echo $listPAGEUrl ?>');" />
									
									
									 <input type="hidden" name="rowId" value="<?php echo $rowId; ?>" />
                                     <input type="hidden" name="operation" value="updateField" />
						
						
						
						
						
						
						
						
						</form>
						
					</div>
			  </td>
			  </tr>
			</table>


				<script>
				 dateCalander();
				</script>	

   
	<? include('bottom.php')?>