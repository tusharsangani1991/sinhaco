<?php


include('includes/config.php');
include('top.php');
 
$os->setFlash($flashMsg);
?>


<? 
$fusionChart=false;


 $caseLinks=$os->getRowById('caselinks','caselinksId',1);
  

 ?>


	<table class="container">
				<tr>
					<td   class="leftside">
						
				 
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td   class="middle" style="padding-left:5px;">
			  
			  
			  <!--  ggggggggggggggg   -->
			  <style>
			  .checkList{ border:1px solid #009900; margin:5px; padding:5px; height:40px; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px;}
			  </style>
			  <style>
 .loadImage{ margin:10px 0px 0px 5px; float:left; width:35px;}
 .loadText{ margin:10px 0px 0px 0px;float:left; width:500px; font-size:14px; font-style:italic; font-weight:bold; color:#009900;}
 .import{opacity: 0.7;
    filter: alpha(opacity=70);}
.import:hover{opacity: 1;
    filter: alpha(opacity=100);}
	
	
	
 
 </style>
 
 <? 
  
 if($os->userDetails['adminType'] == 'Super Admin')
 { 
   
	
	$dept1acc='ok'; $dept2acc='ok'; $dept3acc='ok';
	
 }else{
  if($os->userDetails['dept'] == 'Dept. 1'){   $dept1acc='ok'; }
   if($os->userDetails['dept'] == 'Dept. 2'){   $dept2acc='ok'; }
    if($os->userDetails['dept'] == 'Dept. 3'){   $dept3acc='ok'; }
 
 }
 
 ?>
			
			  <!--<div class="headertext">  </div>-->
			  <div style="width:650px; height:500px; margin:10px 0px 0px 100px;">
			  <div id="updateKeywordsOutputDiv"  style="font-size:18px; color:#CC3300; font-style:italic; font-weight:bold; text-align:center; height:40px;"></div>
			   <div class="checkList" style="font-size:18px; color:#9900CC; font-style:italic; font-weight:bold; text-align:center;">Welcome to Causelist Extractor</div>
			   
			   <?  if($dept1acc=='ok'){ ?>
			   
			   <div class="checkList dept1acc" id=" "> 
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Dept. 1 Keywords:
			    <input type="text" onchange="updateKeywords('keywords')" id="keywords" value="<? echo $caseLinks['keywords'] ?>" style="width:280px; height:15px; border:0px solid #999999;text-align:left" />
			    <?php // $os->editTextField($caseLinks['keywords'],'caselinks','keywords','caselinksId',1 , $inputNameID='keywords',$extraParams='class="tField" style="width:280px; height:15px; border:0px solid #999999;text-align:left" ');?> </div> 
			    
			  </div>
			  <? } ?>
			    <?  if($dept2acc=='ok'){ ?>
			  <div class="checkList dept2acc" id=" "> 
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Dept. 2 Keywords: 
			    <input type="text" onchange="updateKeywords('keywords2')" id="keywords2" value="<? echo $caseLinks['keywords2'] ?>" style="width:280px; height:15px; border:0px solid #999999;text-align:left" />
			   <?php // $os->editTextField($caseLinks['keywords2'],'caselinks','keywords2','caselinksId',1 , $inputNameID='keywords2',$extraParams='class="tField" style="width:280px; height:15px; border:0px solid #999999;text-align:left" ');?> </div> 
			    
			  </div>
			   <? } ?>  <?  if($dept3acc=='ok'){ ?>
			  <div class="checkList dept3acc" id=" "> 
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Dept. 3 Keywords:
			   <input type="text" onchange="updateKeywords('keywords3')" id="keywords3" value="<? echo $caseLinks['keywords3'] ?>" style="width:280px; height:15px; border:0px solid #999999;text-align:left" />
			   
			    <?php // $os->editTextField($caseLinks['keywords3'],'caselinks','keywords3','caselinksId',1 , $inputNameID='keywords3',$extraParams='class="tField" style="width:280px; height:15px; border:0px solid #999999;text-align:left" ');?> </div> 
			    
			  </div>
			   <? } ?>
			 	  <div class="checkList" id=" "> 
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText"> Daily: <?php $os->editTextField($caseLinks['daily'],'caselinks','daily','caselinksId',1 , $inputNameID='unitPriceSS',$extraParams='class="tField" style="width:280px; height:15px; border:0px solid #999999;text-align:left" ');?> </div> 
			   <div class="loadImage import" style="cursor:pointer;">
			    <?php if($os->checkAccess('Import')){?>
			   <img onclick="importDailyList();"  src="<? echo $importImg ?>" />
			   <?  } ?>
			   
			    </div>
			  </div>
			  
			  
			
			  <div class="checkList" id="div_checkDailyList">&nbsp;</div>
			 
			  <div class="checkList" id=" "> 
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Monthly: <?php $os->editTextField($caseLinks['monthly'],'caselinks','monthly','caselinksId',1 , $inputNameID='unitPriceSS',$extraParams='class="tField" style="width:280px; height:15px; border:0px solid #999999;text-align:left" ');?> </div> 
			   <div class="loadImage import" style="cursor:pointer;">
			   
			    <?php if($os->checkAccess('Import')){?>
			   <img onclick="importMonthlyList();"  src="<? echo $importImg ?>" /> 
			   	<?  } ?>
			   </div>
			  </div>
			    <div class="checkList" id="div_checkMonthlyList">&nbsp;</div>
		
			   <div class="checkList" id="div_totalCaseData">&nbsp;</div>
			   
			   <?include('sendSms.php');?>
			   
			 
	 <div class="checkList" id=" "> 
	
			   <div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText"> SMS BALANCE : <span style="color:red;"><? 
	
	$smsObj= new sms;
	echo $msgBalance=$smsObj->balance();?></span>  </div> 
	
	</div> 
	
	
	
	
	
			   
			    <div class="" style="font-size:12px; color:#9900CC; font-style:italic; padding-top:15px; text-align:center;">For any help please contact admin@webtrackers.co.in</div>
			  </div>
				 
				 
				
			  
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>


 <script> 
 <? $loadImage=$site['url'].'image/loading.gif';?>
 
function checkMonthlyList(month)
{

    var url='month='+month+'&';
     url='<? echo $site['url'] ?>/ajaxCauselist.php?checkMonthlyList=OK&'+url;
	//alert(url);
	os.animateMe.div='div_checkMonthlyList';
	os.animateMe.html='<div class="loadImage"><img  src="<? echo $loadImage ?>" /> </div><div class="loadText">&nbsp;Please wait. Checking Monthly List...</div>';
	os.setAjaxFunc('monthlyData',url);
return false;

}
function monthlyData(data)
{
os.setHtml('div_checkMonthlyList',data);
checkDailyList('0');
}


function checkDailyList(day)
{

    var url='day='+day+'&';
     url='<? echo $site['url'] ?>/ajaxCauselist.php?checkDailyList=OK&'+url;
	//alert(url);
	os.animateMe.div='div_checkDailyList';
	os.animateMe.html='<div class="loadImage"><img src="<? echo $loadImage ?>" /> </div><div class="loadText">&nbsp;Wait please .  Checking Daily List...</div>';
	os.setAjaxFunc('dailyData',url);
return false;

}

function dailyData(data)
{
  os.setHtml('div_checkDailyList',data);
  totalCaseData();
}

function totalCaseData(day)
{

    var url='day='+day+'&';
     url='<? echo $site['url'] ?>/ajaxCauselist.php?totalCaseData=OK&'+url;
	//alert(url);
	os.animateMe.div='div_totalCaseData';
	os.animateMe.html='<div class="loadImage"><img src="<? echo $loadImage ?>" /> </div><div class="loadText">&nbsp;Wait please .  Counting Case List...</div>';
	os.setAjaxFunc('totalCaseDatas',url);
return false;

}

function totalCaseDatas(data)
{
  os.setHtml('div_totalCaseData',data);
}
function importDailyList()
{
	var url='day=0&';
	url='<? echo $site['url'] ?>/ajaxCauselist.php?importDailyList=OK&'+url;
	//alert(url);
	os.animateMe.div='div_checkDailyList';
	os.animateMe.html='<div class="loadImage"><img src="<? echo $loadImage ?>" /> </div><div class="loadText">&nbsp;Wait please .  Importing Daily List...</div>';
	os.setAjaxHtml('div_checkDailyList',url);
	return false;


} 
function importMonthlyList()
{
	var url='day=0&';
	url='<? echo $site['url'] ?>/ajaxCauselist.php?importMonthlyList=OK&'+url;
	//alert(url);
	os.animateMe.div='div_checkMonthlyList';
	os.animateMe.html='<div class="loadImage"><img src="<? echo $loadImage ?>" /> </div><div class="loadText">&nbsp;Wait please .   Importing Monthly List...</div>';
	os.setAjaxHtml('div_checkMonthlyList',url);
	return false;
}





function startWorking()
{
checkMonthlyList('0');
}
startWorking();

function updateKeywords(id)
{


     var searchKewords = os.getVal(id);
	 searchKewords=searchKewords.replace('&' ,'*AND*');
	 
	var url='updateKeywords=OK&id='+id+'&searchKewords='+searchKewords+'&';
	url='<? echo $site['url'] ?>/ajaxCauselist.php?updateKeywords=OK&'+url;
	 
	//alert(url);
	os.animateMe.div='updateKeywordsOutputDiv';
	os.animateMe.html='<div class="loadImage"><img  src="<? echo $loadImage ?>" /> </div><div class="lodingText">&nbsp;Please wait. Working in progress...</div>';
	os.setAjaxFunc('updateKeywordsOutput',url);
	return false;



}
function updateKeywordsOutput(data)
{
 
os.setHtml('updateKeywordsOutputDiv',data);

}


</script>


   
	<? include('bottom.php')?>