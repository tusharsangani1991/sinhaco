<? 
error_reporting(0);
session_start();
include('includes/config.php');
include('top.php');
ini_set('max_execution_time', '-1');
ini_set('memory_limit', '2048M'); 
include('sendSms.php');
$contactNo=array();
$remarksData=array();
$dailyDate=getDailyDate();
$ajaxFilePath= 'messageAjax.php';
$c=0;
?>
<?

$keyAndDept=explode('_',$_GET['key']);


if($keyAndDept[0]=="all")
{
$searchData =$_SESSION['downloadSearchData']['searchCombine'];
}
$msgEnquery='';
if($_POST['message']=='OK')
{
if(isset($_POST['checkMsg'])||$_POST['chkMsgMobileNo']!='')
{
//$searchDataTemp[0]=array_pop($searchData);

$searchDataTemp[0]='single msg';
$searchData=$searchDataTemp;
}

foreach($searchData as $record)
{
	
	
$msg=$_POST['msgText'];
$counsel='';
if($keyAndDept[1]=="Dept. 3")
{
 //$counsel=$record['councel_1'];
  $counsel=$record['aorCouncel'].$record['councel_1'].$record['councel_2'].$record['remarks'];

}

else
{
 $counsel=$record['hod'].$record['clientRep'].$record['remarks'];

}

if($counsel!='')
{
preg_match_all('/[0-9]{10}/', $counsel, $matches);
$mobileNoArray=$matches[0];
$mobileNo=implode(",",$mobileNoArray);
if(isset($_POST['checkMsg'])||$_POST['chkMsgMobileNo']!='')
{
 $mobileNo=$_POST['chkMsgMobileNo'];
 
}

if($mobileNo!='')
{
	//$mobileNo=7595836017;
$smsObj= new sms;
$os->smsKey['[#Case_No#]']=$record['caseNo'];
$os->smsKey['[#Item_No#]']=$record['itemNo'];
$os->smsKey['[#Cause_Title#]']=$record['title'];
$os->smsKey['[#Court_No#]']=$record['courtNo'];
$os->smsKey['[#Date#]']=$dailyDate;

foreach($os->smsKey as $key=>$val)
{ 
  $msg= str_ireplace( $key, $val,$msg);
  $smsText=addslashes($msg);
}
$singleMobNo=explode(",",$mobileNo);


for($i=0;$i<count($singleMobNo);$i++)
{
$smsNumbersStr= $singleMobNo[$i];

$msgIdStr=$smsObj->sendSmsAndGetMsgId($mobileNo,$smsText);
preg_match('#\[(.*?)\]#', $msgIdStr, $matches);
$msgId=$matches[1];
$os->saveSendingSms($smsText,$mobileNos=$smsNumbersStr , $status='send',$note=$msgId);


$c++;
}



}
}
}
if($c!=0)
{
	$msgEnquery='<font style="color:#00CC00" > Message sent successfully.</font> ';
}

}





 
?>

 <style>
.headerimage{ display:none;}
</style>
  <style>

.actionLink a {
    padding: 3px 5px 3px 5px;
    border-right: 1px solid #000;
    border-bottom: 1px solid #000;
    background-color: #0098E1;
    color: #FFFFFF;
    text-decoration: none;
    border-radius: 3px;
    margin: 0px 5px;
}
</style>
<div class="listHeader"> SMS SEND</div>
<div style="width:100%; margin:10px 0px 0px 20px;">
 


 <table>
 <tr>
 <td valign="top" >
 
 <form method="post" action="">
<input type="hidden" name="message" value="OK" />
 <input type="hidden" name="status" value="Active" />
  <h2  style="font-weight:bold;"><? echo $msgEnquery ?></h2>
  <span style="font-weight:bold;font-size:15px;"><p>Message</p>
 </span>

<textarea style="width: 402px;height: 137px;"  name="msgText" id="msgText" ></textarea><br /> 

<strong> Single Msg</strong><input  name="checkMsg"  type="checkbox" value="">
<strong>Mobile No:</strong><input value="" type="text" name="chkMsgMobileNo" id="chkMsgMobileNo" class="textboxxx  fWidth "/>


	<input type="submit" name="button" value="Send"  style="cursor:pointer; color:#009900;margin-top:17px;" />
 
  </form>

 
	
 </td>
 <td valign="top"  >
 <div style="margin-top:75px;">
 <? foreach($os->smsKey as $key=>$val){ echo $key.'</br>';
}?>
 </div>
 </td>
 <td valign="top">
 
	<table class="table_top" style="width:auto">
	
	
	<tr style=" background:#eeeeee;">
		<th class="headertext">
	Message Template List 
		</th>
		
	</tr>
	<tr>
	<td class="scroll" valign="top">
	<div class="scroll_div" style="width:300px;">
	
<table  border="0" cellspacing="0" style="width:100%;" cellpadding="0" class="noBorder"  >
<tr class="borderTitle" >
<td >#</td>
<td ><b>Available Template</b></td>  
<td style="width:60px;" ><b>Action</b></td>  
</tr>
<?php
$c=0;
$smsQuery="select * from smstemplate where smstemplateId>0  and active='active' order by priority ";
$smsTemMq=$os->mq($smsQuery);  
while($record=$os->mfa( $smsTemMq)){ 
$c++;
?>
<tr class="trListing" >
<td><?php echo $c; ?>     </td>
<td><?php echo $record['smsText']?> </td>  

<td style="vertical-align: middle;">                   
<span class="actionLink">
<a href="javascript:void(0)" onclick="setMessageVal('<?php echo  $record['smsText']; ?>') ">Use It</a>
</span>
</td>



</tr>
<? 
} ?>  
</table> 
</div>
	</td>
	
	
	</tr>
	</table>

	
	
 </td>
 <td valign="top" >
 
  <strong>Date: </strong> <input class="wtDateClass textbox fWidth" type="text" name="f_smsDate_s" id="f_smsDate_s" value="<?echo $os->showDate($os->now());?>" style="width:85px;" /> <strong>(dd-mm-yyyy)</strong>&nbsp;
	<span style="display:none"><strong>    To Date:</strong>  <input class="dtpk textbox" type="text" name="t_smsDate_s" id="t_smsDate_s" value="<?echo $os->showDate($os->now());?>" style="width:85px;"  /> &nbsp;&nbsp;
 </span>
  <input type="button" value="Search" onclick="WT_smsListing();" style="cursor:pointer;"/>
  <input type="button" value="Reset" style="display:none;" onclick="searchReset();" style="cursor:pointer;"/>

 <table class="table_top" style="width:auto">
 
	<tr style=" background:#eeeeee;">
		<th class="headertext" align="center">
	Send Sms List 
		</th>
		
	</tr>
	<tr>
	<td class="scroll" valign="top">
	<div class="scroll_div" style="width:500px;height: 480px;">
	<div id="WT_smsListingDiv"></div>
</div>
	</td>
	
	
	</tr>
 </table>
 </td>
 </tr>
 
 </table>
 
 


<style>
.listTableAPP{ border:1px dotted  #666666;}
.listTableAPP td{border:none; border-bottom:1px dotted #EFEFEF; border-right:1px dotted #666666;}
.gray{ color:#999999;}
</style>
<style>
.rollList{ width:67px; margin-top:1px; border:1px dotted #999999; background-color:#CCFFD9;  float:left;}
.rollBox{ height:400px; overflow-y:scroll;}
.assignedListBox{ margin-bottom:10px;}
.assignListCount{ margin:3px; border:1px dotted #999999; background-color:#FFD7C4;}
.assignListCount:hover{ background-color:#FFFFCA;}
.errorShow{ color:#FF0000; padding:5px;}
.scroll_div{height:500px;overflow-x:hidden;overflow-y:scroll;}
</style>
<style>
.tableclass{ border:2px groove #ffffff; float:left; padding-left:5px;}
.tableclass td{ border:2px groove #ffffff; padding:10px;}
.groove{border:2px groove #ffffff;}
.table_top{ border:1px solid #cecece; border-collapse:collapse; border-spacing:0; width:1400px;}
.table_top td{ vertical-align:top;}
.table_top td, .table_top th{ border:1px solid #b3b3b3;}
.list_ta{ border-collapse:collapse; border-spacing:0;}
.list_ta th,.list_ta td{ border:1px solid #cecece;}
.list_ta td{ padding:1px 1px; vertical-align:top;}
.list_ta  tbody {height:500px;overflow-y: scroll;}
.list_ta thead, .list_ta tbody tr { }  
</style>
</div>


<script>
<? $loadImage=$site['url'].'image/loading.gif';?> 
function setMessageVal(message)
{
	os.setVal('msgText',message);
  
}
function WT_smsListing()
{
var f_smsDate_sVal= os.getVal('f_smsDate_s');

if(os.check.empty('f_smsDate_s','Please enter any Date')==false){ return false;}
var t_smsDate_sVal= os.getVal('t_smsDate_s');
var url='<? echo $ajaxFilePath ?>?WT_smsListing=OK&f_smsDate_s='+f_smsDate_sVal+'&t_smsDate_s='+t_smsDate_sVal;
os.animateMe.div='WT_smsListingDiv';
os.animateMe.html='<div class="loadImage"><img  src="<? echo $loadImage?>"  /> <div class="loadText">&nbsp;Please wait. Working...</div></div>';	
os.setAjaxHtml('WT_smsListingDiv',url);
  
}
function searchReset()
{
	var setSmsDate='<?echo $os->showDate($os->now())?>';
	os.setVal('f_smsDate_s',setSmsDate);
	os.setVal('t_smsDate_s',setSmsDate);
	WT_smsListing();
}

 WT_smsListing();
</script> 
<script>
dateCalander();
</script>
<? include('bottom.php')?>