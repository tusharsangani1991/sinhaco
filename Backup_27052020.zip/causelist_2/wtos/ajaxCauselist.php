<? 
 session_start();
set_time_limit (0);
ob_start();
include('includes/config.php');
include('coomon.php');
include('causelist.php');
ob_end_clean();



 
if($_GET['checkMonthlyList']=='OK')
{
  
	 $res=checkMonthlyList();
	 
	
	if($res['c']>0){
  
	?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Total records in monthly database are <span style="color:#FF0000"><? echo $res['c'] ?> </span>dated   <? echo $res['d'] ?> &nbsp;</div> <?
	 }else{
	 ?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Something wrong please import. &nbsp;</div> <?
	 }
	exit();
}
if($_GET['checkDailyList']=='OK')
{
   
    $res=checkDailyList();
	 
	
	if($res['c']>0){
  
	?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Total records in daily database are <span style="color:#FF0000"><? echo $res['c'] ?> </span>dated   <? echo $res['d'] ?> &nbsp;</div> <?
	 }else{
	 ?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Something wrong please import. &nbsp;</div> <?
	 }
	 
	 
	exit();
}


if($_GET['totalCaseData']=='OK')
{

  
  $res=totalCaseData();
   if($os->userDetails['adminType'] != 'Super Admin'){  
   $tmpDeptVal=$res[$defaultDeptCode];
   $res= array(); $res[$defaultDeptCode]= $tmpDeptVal;
   
    }
 
  
   $resTotal=array_sum($res);
	//_d($res);
	if($resTotal>0){
  
	?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Total case records  <span style="color:#FF0000"><? echo $resTotal ?> </span>
<span style="color:#CC0099; font-size:12px; font-weight:normal;">
	<? if($os->userDetails['adminType'] == 'Super Admin') { 
	
	foreach($res as $keyDept => $val ){
	 echo "$keyDept : $val  &nbsp;";
	} } ?></span>
	</div> <?
	
	
	
	 }else{
	 ?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">No Data found</div> <?
	 }
	 
	exit();
}

 if($_GET['importDailyList']=='OK')
{
  $os->wtlogs('importDailyList');
  
   importDailyList();
  
  
  
  
  
  
  $res=checkDailyList();
	 
	
	if($res['c']>0){
  
	?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Total records in daily database are <span style="color:#FF0000"><? echo $res['c'] ?> </span>dated   <? echo $res['d'] ?> &nbsp;</div> <?
	 }else{
	 ?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Something wrong please import. &nbsp;</div> <?
	 }
	 
}
if($_GET['importMonthlyList']=='OK')
{
 $os->wtlogs('importMonthlyList');
 
 importMonthlyList();
 
 
  $res=checkMonthlyList();
	 
	
	if($res['c']>0){
  
	?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Total records in monthly database are <span style="color:#FF0000"><? echo $res['c'] ?> </span>dated   <? echo $res['d'] ?> &nbsp;</div> <?
	 }else{
	 ?><div class="loadImage"><img  src="<? echo $okImg ?>" /> </div><div class="loadText">Something wrong please import. &nbsp;</div> <?
	 }
	exit();
}

























if($_GET['SearchData']=='OK')
{
 $os->wtlogs($_GET['key']);
?>
<div class="searchResults">

<?
		if($_GET['key']=='searchByKey')
		{  
			
		 $searchKewords=$_GET['searchKewords'];
		if($searchKewords==''){
		 $caseLinks=$os->getRowById('caselinks','caselinksId',1);
		 
		 $searchKewords=$caseLinks['keywords'];
		 }
		 
		
		 searchByKey($searchKewords);
		 
		
		 
		
		 exit();
		}
		if($_GET['key']=='searchByCaseNo')
		{
		   $dept=$_GET['dept'];
		  searchByCaseNo($dept);
		
		 exit();
		}
		if($_GET['key']=='searchByKeyAndCase')
		{
		  
			$searchKewords=$_GET['searchKewords'];
			$orderBy=$_GET['orderBy'];
			
			//echo $orderBy;
		 
			if($searchKewords==''){
			$caseLinks=$os->getRowById('caselinks','caselinksId',1);
			
			$searchKewords=$caseLinks['keywords'];
			}
			$dept=$_GET['dept'];
			
			searchCombine($searchKewords,$dept,$orderBy);
			 
		
		 exit();
		}

?> </div> <?
 exit();
}































if($_GET['updateKeywords']=='OK')
		{
		  
			$searchKewords=$_GET['searchKewords'];
			$id=$_GET['id'];
			if($searchKewords!=''){
			$searchKewords=str_replace('*AND*','&',$searchKewords);
			
			
			 $query="update caselinks set  $id='$searchKewords'  where caselinksId=1";
  $cdl=$os->mq($query);
  
  if($id=='keywords'){$idItxt='Dept. 1 Keywords  ';}
  if($id=='keywords2'){$idItxt='Dept. 2 Keywords  ';}
  if($id=='keywords2'){$idItxt='Dept. 2 Keywords  ';}
  
  
  
  
   echo " &diams; -----$idItxt  updated successfully-----  &diams;" ;
		
			}
			echo '  ';
		
		 exit();
		}




?>