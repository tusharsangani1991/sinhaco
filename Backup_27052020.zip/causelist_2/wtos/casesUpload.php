<?php
include('includes/config.php');
include('top.php');
 
 
 function getIdByCaseNo($caseListToEdit,$deptCode)
 {
           global $os;
		   $casesId=0;
		   
		    $caseListToEdit=explode("\n",$caseListToEdit);
			foreach($caseListToEdit as $kk=>$singleCase)  ## remove empty value
			{
			if(trim($singleCase)!='')  {$caseListToEditA[]= trim($singleCase);  }
			}
			
		  if(count($caseListToEditA)>0)
		  {
		  
			  $caseStr = implode('|',$caseListToEditA);
			  $caseQuery="select DISTINCT casesId from cases where caseNo RLIKE '$caseStr' and dept='$deptCode' limit 1";
			  $caseRs=$os->mq($caseQuery );
			  $caseRec=$os->mfa($caseRs );
			  
			//  _d($caseRec);
			// // $casesId
			  $casesId=$caseRec['casesId'];
			  
		  }
		  return $casesId;
 
 }
 
 


// config 

$DivIds['AJAXPAGE']='casesEdit';
$listPAGE='cases';
$primeryTable='cases';
$primeryField='casesId';
$listHeader='Upload Cases';
$action='';
## upload and save xls 444
  
$failMsg='';

if($_POST['uploadExcel']=='OK' )
{

$deptCode=$_POST['dept'];
$uploadType=$_POST['uploadType'];
if($deptCode=='')
{
$failMsg= 'Upload Fail . Please Select Department';
}



 if($deptCode!=''){
if($uploadType=='Delete Data and Upload Excel'){
                   $os->mq("DELETE FROM `sinhaco_causelist_2`.`cases` WHERE dept='$deptCode' ");
 }
 
 
 
 
$file=$_FILES['excel']['tmp_name'];
if($file==''){ $failMsg='Upload Fail .  Select Excel File..'; }
else{
$sqlStrArr=array(); 
require_once 'Excel/reader.php';
$dataX = new Spreadsheet_Excel_Reader();
$dataX->setOutputEncoding('CP1251');
$dataX->read($file); // uploaded excel file

/*
`casesId`, `slNo`, `dated`, `caseNo`, `title`, `dept`, `tag`, `hod`, `clientRep`, `background`, `Instruction`, `aorNo`, `aorCouncel`, `councel_1`, `councel_2`, `remarks`, `status`, `addedBy`, `addedDate`, `modifyDate`, `modifyBy`  */


$insertQueryInitial='INSERT INTO `sinhaco_causelist_2`.`cases` (`casesId` ,`slNo` ,`dated` ,`caseNo` ,`title` ,`dept` ,`tag` ,`hod` ,`clientRep` ,`background` ,`Instruction`,`aorNo`,`aorCouncel`,`councel_1`,`councel_2`,`remarks`,`status` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ';

 
 
 
 

$modifyDate=$os->now();
$modifyBy=$os->userDetails['adminId']; 
$addedDate=$os->now();
$addedBy=$os->userDetails['adminId'];


 

	for ($RowsNu = 2; $i <= $dataX->sheets[0]['numRows']; $RowsNu++)
	{ 
	
		if($dataX->sheets[0]['cells'][$RowsNu][1]!='' )
		{
		
		
		
			$action=''; // reset action for each row 
			$casesId=0;
			$xFile=$dataX->sheets[0]['cells'][$RowsNu];
			//_d($xFile);
			
			$dept=$deptCode;
			$status='Active';
			
			
			
			if($deptCode=='Dept. 1' || $deptCode=='Dept. 2' )
			{ 
				$slNo=$xFile[1];
				$dated=$xFile[2];
				$caseNo=$xFile[3];
				$title=addslashes($xFile[4]);
				$tag=addslashes($xFile[5]);
				$hod=addslashes($xFile[6]);
				$clientRep=addslashes($xFile[7]);
				$background=addslashes($xFile[8]);
				$Instruction=addslashes($xFile[9]);
				$remarks=addslashes($xFile[10]);
				
			 
			}
			if($deptCode=='Dept. 3' )
			{ 
				$slNo=$xFile[1];
				$dated=$xFile[2];
				$aorNo=addslashes($xFile[3]);
				$caseNo=$xFile[4];
				$title=addslashes($xFile[5]);
				$tag=addslashes($xFile[6]);
				$aorCouncel=addslashes($xFile[7]);
				$councel_1=addslashes($xFile[8]);
				$councel_2=addslashes($xFile[9]);
				$remarks=addslashes($xFile[10]);
				 
			 
			}
			 
					
					if($uploadType=='Upload By Tag' && $tag=='M' )  // modify  upload by tag M
				    {
                       $action='update';
                    }
				   if( $action=='update'){
				   
				  $casesId= getIdByCaseNo($caseNo,$dept);
				   
				   if($casesId>0){
				   
				   
				   ##  get id by case 
				   
				   
				   
				   
				   
				    $updateSql="UPDATE  cases set slNo='$slNo',dated='$dated',caseNo='$caseNo',title='$title',dept='$dept',tag='$tag',hod='$hod',clientRep='$clientRep',background='$background',Instruction='$Instruction',aorNo='$aorNo',aorCouncel='$aorCouncel',councel_1='$councel_1',councel_2='$councel_2',remarks='$remarks',modifyDate='$modifyDate',modifyBy='$modifyBy' where casesId=$casesId";
				 
					$os->mq($updateSql);
				     }
				 
				   }
				
				
				
				if($uploadType=='Delete Data and Upload Excel' ||   $uploadType=='Upload Excel') //new  upload 
				{  
				   
				   $action='insert';
				}
				if($uploadType=='Upload By Tag' && $tag=='N' )  // new  upload by tag N  remove other data
				 {
                      $action='insert';
                 }
				   
					 
				 if( $action=='insert'){
				
				 if($caseNo!=''){
				 
			 
               

				 
				 

		 $sqlStrArr[]="(NULL , '$slNo', '$dated', '$caseNo', '$title', '$dept', '$tag', '$hod', '$clientRep', '$background', '$Instruction', '$aorNo', '$aorCouncel', '$councel_1', '$councel_2', '$remarks', '$status', '$addedBy', '$addedDate', '$modifyDate','$modifyBy') ";
	
	
	 }
				 
				 
				   if(count($sqlStrArr)==50){   ##insert at a time 
					
				 
				
				## import to table  888
				$importSQL = implode(',',$sqlStrArr); 
				if($importSQL!=''){	$importSQL= $insertQueryInitial. $importSQL .";";
				 
				
				if($os->mq($importSQL )){ }
				else{ 			}
				
				
				$sqlStrArr=array();$importSQL='';  
				}
				## import to table  888
				
				}
			}
		
		
		 
		
		
	}
	if($dataX->sheets[0]['cells'][$RowsNu][1]=='' )
		{
			break;   
			//return;
		}
	
	}
	##upload remaining data
	
	
	
	
	if(is_array($sqlStrArr) && count($sqlStrArr)>0){   ##insert at a time 
					## import to table  888
					$importSQL = implode(',',$sqlStrArr); 
					
					 
					if($importSQL!=''){	$importSQL= $insertQueryInitial. $importSQL .";";
				 
					
				if($os->mq($importSQL )){}else{ 	}
					
				$sqlStrArr=array(); $importSQL='';
					}
					## import to table  888
					
					}
	
	
		$flashMsg=' Data uploade Successfully';
	
	}
	 } 
	 }
## upload and save xls 444

$os->setFlash($flashMsg);
//tinyMce();

//searching......

 

?>

	<table class="container">
				<tr>
					<td  class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td  class="middle" style="padding-left:5px;">
			  
			  
			  <div class="listHeader"> <?php  echo $listHeader; ?></div>
			  
			  <!--  ggggggggggggggg   -->
			  <br />
			  <?  if($failMsg!=''){ 
			  ?>
			  <div style="color:#FF0000;"> <b><? echo  $failMsg?> </b></div>
			  <? 
			  } ?>
			  <br />
			  <form action="" enctype="multipart/form-data" method="post">
			 
										  
										  
				  Department:						  
										  
										   <? if($os->userDetails['adminType']=='Admin'){ ?>
   <input type="text" name="dept" id="dept" value="<? echo $defaultDeptCode?>"  readonly="1"/>
										  
										  <? } else{?>
										
	
	<select name="dept" id="dept" class="textbox fWidth" ><option value="">Select Department</option>	<? 
										  $os->onlyOption($os->department,$dept);	?></select>	
										 
										  <? } ?>
  
										  
										  
 <br /> <br />
			  
			  
			  <input type="file" name="excel" /><br />
			  <span style="font-size:11px; font-style:italic; color:#CC6600"> File should have SL no in the first column. Only supported extension is .xls</span><br /><br />
			  <input type="hidden" name="uploadExcel" value="OK" />
			  
			  <? if($os->userDetails['adminType'] == 'Super Admin') {?>	
			  <input type="submit" name="uploadType" value="Delete Data and Upload Excel" style="cursor:pointer; color:#FF0000" /> &nbsp; &nbsp;
			   <input type="submit" name="uploadType" value="Upload Excel"  style="cursor:pointer;" />&nbsp;&nbsp;
			   <? } ?>
			   
			   
			   <input type="submit" name="uploadType" value="Upload By Tag"  style="cursor:pointer; color:#009900" />
			   
			   <br /><br />
			   <span style="font-size:11px; font-style:italic; color:#CC6600">
			     <? if($os->userDetails['adminType'] == 'Super Admin') {?>	
			    "Delete Data and Upload Excel" button  will erase all existing data and upload excel Data<br /> 
			   "Upload Excel" button  will upload excel Data only and create new records.<br /> 
			     <? } ?>
			   "Upload By Tag" button  will upload excel Data By Tag . Tag 'M' will modify existing data,  Tag 'N' will create new record. </span><br /><br />
			  
			 </form>
			 
			 <div style="margin:100px 0px 0px 300px;"> <a <? sTab('cases') ?> href="<? $seoLink->l('cases',true); ?>" >Back To Case List</a></div>
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>







	
    
    
   
	<? include('bottom.php')?>