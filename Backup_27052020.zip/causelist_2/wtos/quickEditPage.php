<? 
## v-1 author Mizanur Rahaman  mizanur82@gmail.com
global $os; 
  
function quickEdit_v_four($options ,$foreignIdValue,$functionId)
{
global $os;


if($foreignIdValue<1)
{
       $dataToSave[$options['foreignId']]='';
   $foreignIdValue=   $os->save($options['foreignTable'],$dataToSave);

}



$options['foreignIdValue']=$foreignIdValue;
$options['functionId']=$functionId;
$options['ajaxEditFunction']='ajaxEdit'.$functionId;
$options['ajaxViewFunction']='ajaxView'.$functionId;
$options['ajaxViewDataFunction']='ajaxViewData'.$functionId;
$options['ajaxDeleteFunction']='ajaxDeleteData'.$functionId;


$options['ajaxDiv']='ajaxDiv'.$functionId;
 


extract($options);
$sessionKey='quickEdit-'.$functionId;





$_SESSION[$sessionKey]=$options;

  ## form 
  
  
  ?>
  <style>
  .qaddButton{ font-size:18px; font-weight:bold; background-color:#009900;color:#FFFFFF; cursor:pointer; height:20px; width:20px; padding:0px; margin:0px; line-height:10px;-moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px;}
  .qdeleteButton{ font-size:18px; font-weight:bold; background-color:#FF0000;color:#FFFFFF; cursor:pointer; height:20px; width:20px; padding:0px; margin:0px; line-height:10px;-moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px;}
   .<? echo $functionId?>{ border:1px solid #CCCCCC; margin:2px 5px 10px 0px; padding:5px; -moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px;}
  .<? echo $functionId?> tr{ height:10px;}
  .<? echo $functionId?> td{ height:10px; padding:1px;}
  .<? echo $functionId?> tr:hover{ background-color:#F0F0F0;}
   .<? echo $functionId?> .PageHeading{ font-family:Verdana, Arial, Helvetica, sans-serif; font-size:18px; background:#007CB9; color:#FFFFFF; padding:2px; -moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px; font-style:italic;}
  .texts{-moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px;}
  .ddbox{-moz-border-radius:4px; -webkit-border-radius:4px; border-radius:4px;}
  
  
  </style>
  <? 
   foreach($fields as $fld=>$alise)
  {
       
  
 
  $scriptVarStr []="var ".$fld."=  escape(os.getVal('".$functionId.$fld."').trim());";
   $scriptUrlStr[]="'&".$fld."='+".$fld."";
  
  
  }
  ?>
  
  <div id="<? echo $ajaxDiv; ?>"> </div>
  
   <script>
   function <? echo $ajaxEditFunction ?>(foreignId)
   {
    <? echo  implode(" ",$scriptVarStr); ?>
	var vars=<? echo  implode('+',$scriptUrlStr); ?>;
	var url='ajxQuickEdit.php?foreignId='+foreignId+'&aQEsessonKey=<? echo $sessionKey ?>&getQuickEditValues=OK'+vars;
	 
	os.setAjaxFunc('<? echo $ajaxViewDataFunction ?>',url);
	
   
   }
   
   function <? echo $ajaxViewFunction ?>(foreignId)
   {
   
     
	var url='ajxQuickEdit.php?foreignId='+foreignId+'&aQEsessonKey=<? echo $sessionKey ?>&getQuickViewValues=OK';
	
	os.setAjaxFunc('<? echo $ajaxViewDataFunction ?>',url);
	   
   }
   
   function <? echo $ajaxDeleteFunction ?>(tableId)
   {
   
     if(confirm('Are you sure. You want to delete the record?'))
	 {
	var url='ajxQuickEdit.php?tableId='+tableId+'&aQEsessonKey=<? echo $sessionKey ?>&getQuickDeleteValues=OK';
	
	os.setAjaxFunc('<? echo $ajaxViewDataFunction ?>',url);
	}
	   
   }
   
   
   function <? echo $ajaxViewDataFunction ?>(data)
   {
     
	 
	 var D=data.split('-DATAFORM-');
	 var AC=data.split('-AUTOCOMPLETE-');
	  AC=AC[1];
	  
	  
	 
	
	 
	 
	 
	  os.setHtml('<? echo $ajaxDiv; ?>',D[0]);
	  
	   if(AC!=''){
	    
	  var ACstrA=AC.split('-MULTIPLEAC-');
	  
	    
	 for(var i=0;i<ACstrA.length;i++)
	 {
	 var ACstr=ACstrA[i].split('-CLASSSTR-');
	 
	 //alert(ACstr);
	 if(ACstr[0]!=''){
		$(document).ready(function(){    
		$("."+ACstr[0]+"").autocomplete(ACstr[1].split("##"));
		});    
		}
	 
	 }
	 }
	 
	 
	 
 
	$( ".dtpk" ).datepicker({
	dateFormat: 'dd-mm-yy',
	changeMonth: true,
	changeYear: true,
	yearRange: 'c-10:c+10'
	});
 
	 
	 
	  
     ///
   }
   
  <? echo $ajaxViewFunction ?>('<? echo $foreignIdValue ?>');
  
   </script>
  <? 


}


$options['PageHeading']='History2'; 
$options['foreignId']='pagecontentId'; 
$options['foreignTable']='pagecontent';
$options['table']='news';
$options['tableId']='newsId';
$options['tableQuery']="select * from news where [condition] order by newsdate "; ///   [condition]  rplaced  as   and $foreignId='$foreignIdValue'
$options['fields']=array('title'=>'TITLE','body'=>'BODY','newsdate'=>'DATE','active'=>'STATUS');

  $options['type']=array('title'=>'T','body'=>'AC','newsdate'=>'T','active'=>'AC'); 
//$options['type']=array('title'=>'T','body'=>'T','newsdate'=>'T','active'=>'DD');  //  T for text    DD drop down AC  auto complete
//$options['relation']=array('title'=>'','body'=>'','newsdate'=>'','active'=>'activeStatus'); // relationn for  array   $os->activeStatus  [DD and AC]
$options['relation']=array('title'=>'','body'=>'activeStatus','newsdate'=>'','active'=>'select * from pagecontent-fld-pagecontentId-fld-title');  //  select * from pagecontent where active='Y'-fld-pagecontentId-fld-title
$options['class']=array('title'=>'texts','body'=>'texts','newsdate'=>'texts dtpk','active'=>'ddbox');  ## add jquery date class
$options['add']='1';
$options['delete']='1';




