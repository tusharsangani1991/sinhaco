<?php
session_start();
include('includes/config.php');
include('coomon.php');
include('causelist.php');

  $downloadKey=$_GET['downloadKey'];
 
  $query=$_SESSION['downloadSearchData'][$downloadKey];
// if($query==''){exit();}
$fileToDownload=date('Ymdhi').'search.csv';
$fileToDownload=date('Y').'search.csv';

$fp = fopen($fileToDownload, 'w');

if($downloadKey=='searchByKey')
{
   $list=array('SL.','Case No','Title','Advocate','Court No.');
   fputcsv($fp, $list);
  // $queryRs=$os->mq($query);
   $count=1;
   
  $searchByKeyA=$_SESSION['downloadSearchData'][$downloadKey];
  foreach($searchByKeyA as $record)
 {
            $fields[0] =$count;
			$fields[1] =$record['caseNo'];
			$fields[2] =$record['title'];
			$fields[3] =$record['advocate'];
			$fields[4] =$record['courtNo'];
			
			 
			
		fputcsv($fp, $fields);
		$count++;	
		
		 
 }
 
 
 

}


if($downloadKey=='searchByCaseNo')
{
$dept=$_GET['dept'];

   if($dept=='Dept. 1' || $dept=='Dept. 2' ){
      $list=array('ITEM NO.','CASE NO ','CAUSE TITLE','COURT','HOD','CLIENT REP.','BACKGROUND','INSTRUCTION','LAWYER','COUNSEL ','SL NO.');
   }
   if($dept=='Dept. 3'){
   $list=array('ITEM NO.','CASE NO ','CAUSE TITLE','COURT','AOR/COUNSEL','COUNSEL - 1','COUNSEL - 2','LAWYER','COUNSEL ','SL NO.');
   }
   fputcsv($fp, $list);
   $queryRs=$os->mq($query);
   
   $normalSlNo=1;
   $searchByCaseNoA=$_SESSION['downloadSearchData'][$downloadKey];
   foreach($searchByCaseNoA as $record)
  
		{
		   
		
		
		 
		 if(is_array($record))
		 {
			$fields=array();
			
				$fields[] =$record['itemNo'];
				$fields[] =$record['caseNo'];
				$fields[] =$record['title'];
				$fields[] =$record['courtNo'];
				
				if($dept=='Dept. 1' || $dept=='Dept. 2' )
				{ 
					
					$fields[] =$record['hod'];
					$fields[] =$record['clientRep'];
					$fields[] =$record['background'];
					$fields[] =$record['Instruction'];
					
					
				}
				if($dept=='Dept. 3')
				{
				
				  
						
					$fields[] =$record['aorCouncel'];
					$fields[] =$record['councel_1'];
					$fields[] =$record['councel_2'];
					
					
				
				}
				$fields[] =$record['advocate'];
				$fields[] =$record['remarks'];
				$fields[] =$normalSlNo;
			    
				fputcsv($fp, $fields);
				$normalSlNo++;
					 
		 }
		 
		 
		 
		
		}
		 
		
		 
		
   
   
   

}

if($downloadKey=='searchCombine')
{
$dept=$_GET['dept'];

   if($dept=='Dept. 1' || $dept=='Dept. 2' ){
      $list=array('ITEM NO.','CASE NO ','CAUSE TITLE','COURT','HOD','CLIENT REP.','BACKGROUND','INSTRUCTION','LAWYER','COUNSEL ','SL NO.');
   }
   if($dept=='Dept. 3'){
   $list=array('ITEM NO.','CASE NO ','CAUSE TITLE','COURT','AOR/COUNSEL','COUNSEL - 1','COUNSEL - 2','LAWYER','COUNSEL ','SL NO.');
   }
   fputcsv($fp, $list);
  // $queryRs=$os->mq($query);
   
   $normalSlNo=1;
   $searchCombineData=$_SESSION['downloadSearchData'][$downloadKey];
   
   if($_GET['orderby']=='hod'){
   
   
   
    $searchCombineData= multySort($searchCombineData,'hod','ASC');
   }
   
   
   
   foreach($searchCombineData as $record)
   {
		   
		
		
		 
		 if(is_array($record))
		 {
			$fields=array();
			
				$fields[] =$record['itemNo'];
				$fields[] =$record['caseNo'];
				$fields[] =$record['title'];
				$fields[] =$record['courtNo'];
				
				if($dept=='Dept. 1' || $dept=='Dept. 2' )
				{ 
					
					$fields[] =$record['hod'];
					$fields[] =$record['clientRep'];
					$fields[] =$record['background'];
					$fields[] =$record['Instruction'];
					
					
				}
				if($dept=='Dept. 3')
				{
				
				  
						
					$fields[] =$record['aorCouncel'];
					$fields[] =$record['councel_1'];
					$fields[] =$record['councel_2'];
					
					
				
				}
				$fields[] =$record['advocate'];
				$fields[] =$record['remarks'];
				$fields[] =$normalSlNo;
			    
				fputcsv($fp, $fields);
				$normalSlNo++;
					 
		 }
		 
		 
		 
		
		}
		 
		
		 
		
   
   
   

}


if($downloadKey=='searchByCaseNoNotInUse')
{
   $list=array('SL.','Case No','Title','Advocate','Court No.');
   fputcsv($fp, $list);
   
   $queryRs=$os->mq($query);
   $count=1;
   
   
   
   
   
   
   
   
  
  while($record=$os->mfa($queryRs))
 {
            $fields[0] =$count;
			$fields[1] =$record['caseNo'];
			$fields[2] =$record['title'];
			$fields[3] =$record['advocate'];
			$fields[4] =$record['courtNo'];
			
			 
			
		fputcsv($fp, $fields);
		$count++;	
 }

}





fclose($fp);

header('Content-Type: application/csv'); //Outputting the file as a csv file
header('Content-Disposition: attachment; filename='.$fileToDownload); //Defining the name of the file and suggesting the browser to offer a 'Save to disk ' option
header('Pragma: no-cache');
echo readfile($fileToDownload); //Reading the contents of the file
