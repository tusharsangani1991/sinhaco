<?php
include('includes/config.php');
include('top.php');

// config 

$DivIds['AJAXPAGE']='dailylistEdit';
$listPAGE='dailylist';
$primeryTable='dailylist';
$primeryField='dailylistId';
$listHeader='List Dailylist';

 
$DivIds['EDITPAGE']=$site['url'].$DivIds['AJAXPAGE'].'.php?'.$os->addParams(array('hideTopLeft'),'').'editRowId=';
$listPAGEUrl=$listPAGE.'.php?'.$os->addParams(array('hideTopLeft'),'');
##  delete row
if(varG('operation')=='deleteRow')
{
       if($os->deleteRow($primeryTable,$primeryField,varG('delId')))
	   {
	     $flashMsg='Data Deleted Successfully';
	   }
}


##  update row
if(varP('operation'))
{

	 if(varP('operation')=='updateField')
	 {
	  $rowId=varP('rowId');
	
	  #---- edit section ----#
		
		
 $dataToSave['itemNo']=varP('itemNo'); 
 $dataToSave['caseNo']=varP('caseNo'); 
 $dataToSave['title']=varP('title'); 
 $dataToSave['advocate']=varP('advocate'); 
 $dataToSave['floor']=varP('floor'); 
 $dataToSave['courtNo']=varP('courtNo'); 
 $dataToSave['monthlyItems']=varP('monthlyItems'); 
 $dataToSave['warningList']=varP('warningList'); 
 $dataToSave['dailydate']=$os->saveDate(varP('dailydate')); 
 $dataToSave['ignorData']=varP('ignorData'); 

		 
		$dataToSave['modifyDate']=$os->now();
		$dataToSave['modifyBy']=$os->userDetails['adminId']; 
		 
		if($rowId < 1){
		$dataToSave['addedDate']=$os->now();
		$dataToSave['addedBy']=$os->userDetails['adminId'];
		}
		
		
		
	 
	 
	  
	  $insertedId=$os->save($primeryTable,$dataToSave,$primeryField,$rowId);
	  $flashMsg=($rowId)?'Record Updated Successfully':'Record Added Successfully';
	  $os->popUpSaveAssign($insertedId);
	  #---- edit section end ----#
	
	 }
	
	
}
 

/* searching */

 
$anditemNoA=  $os->andField('itemNo','itemNo',$primeryTable,'=');
   $itemNo=$anditemNoA['value']; $anditemNo=$anditemNoA['andField'];	 
$andcaseNoA=  $os->andField('caseNo','caseNo',$primeryTable,'%');
   $caseNo=$andcaseNoA['value']; $andcaseNo=$andcaseNoA['andField'];	 
$andtitleA=  $os->andField('title','title',$primeryTable,'%');
   $title=$andtitleA['value']; $andtitle=$andtitleA['andField'];	 
$andadvocateA=  $os->andField('advocate','advocate',$primeryTable,'%');
   $advocate=$andadvocateA['value']; $andadvocate=$andadvocateA['andField'];	 
$andfloorA=  $os->andField('floor','floor',$primeryTable,'%');
   $floor=$andfloorA['value']; $andfloor=$andfloorA['andField'];	 
$andcourtNoA=  $os->andField('courtNo','courtNo',$primeryTable,'%');
   $courtNo=$andcourtNoA['value']; $andcourtNo=$andcourtNoA['andField'];	 
$andmonthlyItemsA=  $os->andField('monthlyItems','monthlyItems',$primeryTable,'%');
   $monthlyItems=$andmonthlyItemsA['value']; $andmonthlyItems=$andmonthlyItemsA['andField'];	 
$andwarningListA=  $os->andField('warningList','warningList',$primeryTable,'%');
   $warningList=$andwarningListA['value']; $andwarningList=$andwarningListA['andField'];	 

   

$listingQuery=" select * from $primeryTable where $primeryField>0   $anditemNo  $andcaseNo  $andtitle  $andadvocate  $andfloor  $andcourtNo  $andmonthlyItems  $andwarningList    $andActive order by $primeryField desc  ";

##  fetch row
$recordsA=$os->pagingResult($listingQuery,$recordPerPage);
$records=$recordsA['records'];


 

$os->setFlash($flashMsg);
//tinyMce();

//searching......




?>

	<table class="container">
				<tr>
					<td  class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td  class="middle" style="padding-left:5px;">
			  
			  
			  <div class="listHeader"> <?php  echo $listHeader; ?></div>
			  
			  <!--  ggggggggggggggg   -->
			  
			  <div class="headertext">Search Option   <span style="float:right">Record per page  <?php  echo $recordPerPageDDS; ?></span></div>
			  <div class="searchB">
<table cellpadding="0" cellspacing="0">
	<tr>
	<td class="buttonSa">
	


   Case No: <input type="text" name="caseNo" id="caseNo" value="<?php echo $caseNo?>" style="width:100px;" /> &nbsp;  
    Title: <input type="text" name="title" id="title" value="<?php echo $title?>" style="width:100px;" /> &nbsp;  
   
   <div style="display:none;">
   
   Item No: <input type="text" name="itemNo" id="itemNo" value="<?php echo $itemNo?>" style="width:100px;" /> &nbsp;  
   Advocate: <input type="text" name="advocate" id="advocate" value="<?php echo $advocate?>" style="width:100px;" /> &nbsp;  
   Floor: <input type="text" name="floor" id="floor" value="<?php echo $floor?>" style="width:100px;" /> &nbsp;  
   Court No: <input type="text" name="courtNo" id="courtNo" value="<?php echo $courtNo?>" style="width:100px;" /> &nbsp;  
   MonthlyItems: <input type="text" name="monthlyItems" id="monthlyItems" value="<?php echo $monthlyItems?>" style="width:100px;" /> &nbsp;  
   Warning List: <input type="text" name="warningList" id="warningList" value="<?php echo $warningList?>" style="width:100px;" /> &nbsp;  
  </div>
	 
	
	<a class="searchButton" href="javascript:void(0)" onclick="javascript:searchText()">Search</a>
	&nbsp;
	<a class="resetButton" href="javascript:void(0)"   onclick="javascript:searchReset()">Reset</a>
	
	</td>
	</tr>
</table>
				</div>
				 <div class="headertext" style="margin-top:10px;">Total <? echo $os->paging->p['count']; ?>
				 <a class="refreshButton" href="" style="margin-left:20px;"> Refresh </a>    
				 <span style="float:right; display:none;"><a  class="addButton"  href="javascript:void(0)" onclick="os.editRecord('<? echo $DivIds['EDITPAGE']?>0') ">Add record</a></span></div>
				 
				 <table  border="0" cellspacing="0" cellpadding="0" class="listTable" >
							<tr class="borderTitle" >
								<td >#</td>
								
								
<td ><b>Item No</b></td>  
  <td width="100" ><b>Case No</b></td>  
  <td ><b>Title</b></td>  
  <td ><b>Advocate</b></td>  
  <td width="100" ><b>Floor</b></td>  
  <td ><b>Court No</b></td>  
  
  
  <td ><b>Dated</b></td>  
  
								
								 
								
                                
								
								
								<td style="display:none;" >Action </td>
								
							</tr>
							
						
							
							
							<?php
							  $c=1;
							 $i=$os->slNo();
							 if(is_array($records)){ foreach($records as $k=>$record){ 
							    
								 $DivIds =$os->divIds($record[$primeryField], $DivIds);
																 
								 $selected=0;
								
							
							 ?>
							
							<tr class="border" id="selected<?php echo $c;?>" onclick="trSelected('<?php echo $c;?>','<?php echo  count($records);?>');"   onmouseover="javascript:miz.switchRow('<?php echo  $DivIds['BUTTONS']; ?>')">
								<td><?php echo $i?>     </td>
								
								
<td><b><?php echo $record['itemNo']?></b></td>  
  <td><?php echo nl2br($record['caseNo']);?> </td>  
  <td><?php echo $record['title']?> </td>  
  <td><?php echo $record['advocate']?> </td>  
  <td><?php echo $record['floors']?> </td>  
  <td><?php echo $record['courtNo']?> </td>  
   
  
  <td><?php echo $os->showDate($record['dailydate']);?> </td>  
  
							 	
								
						  <td class="actionLink" style="display:none;" >                   
                        <span id="<?php echo  $DivIds['BUTTONS']; ?>"  style="display:none"  class="buttonSa">
						
						<a class="editButton" href="javascript:void(0)" onclick="os.editRecord('<? echo $DivIds['EDITPAGE']?><?php echo  $DivIds['EDITID']; ?>')">Edit</a>
						
						<a class="deleteButton" href="javascript:void(0)" onclick="os.deleteRecord('<?php echo  $DivIds['EDITID']; ?>') ">Delete</a>
						
						
						
						</span>
						
                        
                       </td>
														
					</tr>
				 
                            
							
							<?php $i++; $c++;
							} 
							}?>
							
							
							
						</table>
				 
				 		<?php echo $recordsA['links'];?>			
	         
	  <br />
			  
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>







	
    <script>
	
	 function searchText()
	 {
	 
	   
 var itemNoV= os.getVal('itemNo'); 
 var caseNoV= os.getVal('caseNo'); 
 var titleV= os.getVal('title'); 
 var advocateV= os.getVal('advocate'); 
 var floorV= os.getVal('floor'); 
 var courtNoV= os.getVal('courtNo'); 
 var monthlyItemsV= os.getVal('monthlyItems'); 
 var warningListV= os.getVal('warningList'); 
window.location='<?php echo $listPAGEUrl; ?>itemNo='+itemNoV +'&caseNo='+caseNoV +'&title='+titleV +'&advocate='+advocateV +'&floor='+floorV +'&courtNo='+courtNoV +'&monthlyItems='+monthlyItemsV +'&warningList='+warningListV +'&';
	  
	 }
	function  searchReset()
	{
			
	  window.location='<?php echo $listPAGEUrl; ?>itemNo=&caseNo=&title=&advocate=&floor=&courtNo=&monthlyItems=&warningList=&';	
	   
	
	}
		
	 dateCalander();
	
	</script>
	
    
   
	<? include('bottom.php')?>