<?php
include('includes/config.php');
include('os.php');

$rs=$os->mq('select * from wtlogs order by addedDate desc , wtlogsId desc ');

if($_GET['system']!=1){ exit();}

?>
<html>
<body>

<table border="1" cellpadding="1" cellspacing="0" style="font-size:9px; font-family:Verdana, Arial, Helvetica, sans-serif;">
  <tr>
  <td><b>ID.</b></td>
  <td><b>TITLE </b></td>
  <td><b>DESC</b></td>
  <td><b>USER</b></td>
  <td><b>DATE</b></td>
  
  </tr>
  
  <? 
  
 while($record=$os->mfa($rs))
 {
 

 
 ?>
 <tr>
 <td ><? echo $record['wtlogsId'] ?></td>
 <td width="120"><? echo nl2br($record['title']); ?></td>
 <td><? echo $record['description'] ?></td>
  <td><? echo $record['addedBy'] ?></td>
  <td><? echo $record['addedDate'] ?></td>
  
  </tr>
   
 <?
  
  
 

	 
 }
 
 
  
?>




</table>

	</body>
	</html>