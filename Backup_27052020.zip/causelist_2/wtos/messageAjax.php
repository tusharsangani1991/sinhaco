<? 
/*
   # wtos version : 1.1
   # page called by ajax script in rentbillDataView.php 
   #  
*/
include('includes/config.php');
include('top.php');

$pluginName='';
$os->loadPluginConstant($pluginName);

 
?><?

if($_GET['WT_smsListing']=='OK')
 
{
$where='';



//$f_smsDate_s= $os->setNget('f_smsDate_s'); $t_smsDate_s= $os->setNget('t_smsDate_s');
$f_smsDate_s= $_GET['f_smsDate_s']; $t_smsDate_s=$_GET['t_smsDate_s'];
$andsmsDate=$os->DateQ('dated',$f_smsDate_s,$f_smsDate_s,$sTime='00:00:00',$eTime='23:59:59');
 $listingQuery="select * from sms where smsId>0   $where $andsmsDate order by smsId desc ";

$smsMq=$os->mq($listingQuery);  
	 
 
?>
<div class="listingRecords">


<table  border="0" cellspacing="0" cellpadding="0" style="width:100%;" class="noBorder"  >
							<tr class="borderTitle" >
				<td >#</td>
<td ><b>Mobile No</b></td> 
<td style="width:100px;"><b>Status</b></td>
<td style="width:80px;"><b>Date</b></td>  
<td style="width:302px;" ><b>Sms</b></td>		
							 
 
						       	</tr>
							
							
							
							<?php
								  
						  	 $serial=0;  
						 
							while($record=$os->mfa( $smsMq)){ 
							 $serial++;
							    
								
							
						
							 ?>
							<tr class="trListing">
							
							
	<td><?php echo $serial; ?>     </td>
<td><?php echo $record['mobileNos']?> </td>  
<td style="width:100px;"><?php print_r($os->sendMsgStatus($record['note']));?> </td> 
<td style="width:80px;"><?php echo $os->showDate($record['dated'])?> </td> 
<td style="vertical-align: middle;width:302px;">                   
<?php echo $record['smsText']?>
</td>

								
				 </tr>
                          <? 
						  
						 
						  } ?>  
							
		
			
			
							 
		</table> 
		
		
		
		</div>
		
		<br />
		
		
						
<?php 
exit();
	
}
 

