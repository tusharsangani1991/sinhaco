-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 30, 2014 at 11:56 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `wtosversion`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `adminId` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `adminType` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobileNo` int(10) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`adminId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `name`, `adminType`, `username`, `password`, `address`, `email`, `mobileNo`, `addedDate`, `active`) VALUES
(26, 'Mizanur Rahaman', 'Super Admin', '123', '123', 'NP 210 saltlake sector V', '456456456', 0, '2012-12-15 12:09:37', 1),
(27, 'hi ', 'Admin', '222', '222', '', '', 0, '2013-06-02 10:39:28', 0),
(28, '3333', '', '', '', '', '', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `appearance`
--

CREATE TABLE IF NOT EXISTS `appearance` (
  `appearanceId` int(11) NOT NULL AUTO_INCREMENT,
  `logoImage` varchar(255) NOT NULL,
  `css` text NOT NULL,
  `sliderName` varchar(255) NOT NULL,
  `sliderEffect` varchar(255) NOT NULL,
  `sliderWidth` varchar(10) NOT NULL,
  `sliderHeight` varchar(10) NOT NULL,
  `sliderInterval` varchar(10) NOT NULL,
  `sliderAutoplay` tinyint(4) NOT NULL DEFAULT '0',
  `headerBgImg` varchar(255) NOT NULL,
  `headerBgImgCss` text NOT NULL,
  `footerBgImg` varchar(255) NOT NULL,
  `footerBgImgCss` text NOT NULL,
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  `bodyBgImg` varchar(200) NOT NULL,
  `bodyBgImgCss` varchar(100) NOT NULL,
  PRIMARY KEY (`appearanceId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `appearance`
--

INSERT INTO `appearance` (`appearanceId`, `logoImage`, `css`, `sliderName`, `sliderEffect`, `sliderWidth`, `sliderHeight`, `sliderInterval`, `sliderAutoplay`, `headerBgImg`, `headerBgImgCss`, `footerBgImg`, `footerBgImgCss`, `addedBy`, `addedDate`, `active`, `bodyBgImg`, `bodyBgImgCss`) VALUES
(1, 'wtos-images/121058_1160887324756617521.png', '', 'nivoSlider.php', 'fade', '500', '100', '3000', 1, 'wtos-images/855552_bgImg.jpg', 'no-repeat', 'wtos-images/595924_repeat.jpg', 'repeat-x', 26, '2013-05-23 10:52:00', 1, 'wtos-images/ep.jpg', 'no-repeat');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE IF NOT EXISTS `contactus` (
  `contactid` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `details` text NOT NULL,
  `addedBy` varchar(10) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`contactid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`contactid`, `name`, `email`, `mobile`, `details`, `addedBy`, `addedDate`, `active`, `image`) VALUES
(8, 'Mizanur Rahaman', 'mizanur82@gmail.com', '5555555555555', 'techno test', '', '2013-01-06 01:45:13', 0, 'wtos-images/822096_testattachment.txt'),
(9, 'xdfsdfsd', 'fdfsd', 'fsdfsdfsfs', '', '', '2013-02-08 05:38:36', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `imageuploader`
--

CREATE TABLE IF NOT EXISTS `imageuploader` (
  `imageId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `addedDate` datetime NOT NULL,
  PRIMARY KEY (`imageId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `imageuploader`
--

INSERT INTO `imageuploader` (`imageId`, `title`, `image`, `addedDate`) VALUES
(13, 'cartoon', 'wtos-images/cov_bg.png', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `lang`
--

CREATE TABLE IF NOT EXISTS `lang` (
  `langId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `code` varchar(20) NOT NULL,
  `defaultLang` tinyint(1) NOT NULL,
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`langId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `lang`
--

INSERT INTO `lang` (`langId`, `title`, `code`, `defaultLang`, `addedBy`, `addedDate`, `active`) VALUES
(1, 'English', 'en', 1, 26, '2013-02-26 09:19:22', 0),
(2, 'Bengali', 'ben', 0, 26, '2013-02-26 09:55:16', 0);

-- --------------------------------------------------------

--
-- Table structure for table `misc`
--

CREATE TABLE IF NOT EXISTS `misc` (
  `miscId` int(10) NOT NULL AUTO_INCREMENT,
  `adminId` int(10) NOT NULL,
  `newsId` int(10) NOT NULL,
  `pages` datetime NOT NULL,
  `addedDate` datetime NOT NULL,
  `addedBy` int(10) NOT NULL,
  `modifyDate` datetime NOT NULL,
  `modifyBy` int(10) NOT NULL,
  `active` tinyint(2) NOT NULL,
  PRIMARY KEY (`miscId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `misc`
--

INSERT INTO `misc` (`miscId`, `adminId`, `newsId`, `pages`, `addedDate`, `addedBy`, `modifyDate`, `modifyBy`, `active`) VALUES
(2, 26, 0, '2013-12-05 00:00:00', '2013-06-02 11:10:48', 26, '2013-06-05 12:37:54', 26, 0),
(3, 27, 0, '0000-00-00 00:00:00', '2013-06-03 01:20:46', 26, '2013-06-05 08:56:48', 26, 0),
(4, 0, 0, '0000-00-00 00:00:00', '2013-06-05 08:46:48', 26, '2013-06-05 08:46:48', 26, 0),
(5, 26, 0, '2013-06-05 00:00:00', '2013-06-05 12:38:05', 26, '2013-06-05 12:38:05', 26, 0);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `newsdate` varchar(50) NOT NULL,
  PRIMARY KEY (`newsId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsId`, `title`, `body`, `active`, `addedBy`, `addedDate`, `newsdate`) VALUES
(7, 'new i frame link', 'i love you', 1, 0, '0000-00-00 00:00:00', '23 January 2013'),
(8, 'i am so exited', 'ddw', 1, 0, '0000-00-00 00:00:00', '23 January 2013'),
(9, 'hi this is mizanur', 'erere yrtyryry rtry', 1, 26, '2013-07-04 12:33:12', 'test2'),
(16, 'zswf', 'sdfsfds', 1, 0, '0000-00-00 00:00:00', 'sdfsdfsd');

-- --------------------------------------------------------

--
-- Table structure for table `newsimg`
--

CREATE TABLE IF NOT EXISTS `newsimg` (
  `newsImgId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `addedBy` int(10) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` int(1) NOT NULL,
  `newsId` int(11) NOT NULL,
  PRIMARY KEY (`newsImgId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `newsimg`
--

INSERT INTO `newsimg` (`newsImgId`, `title`, `addedBy`, `addedDate`, `active`, `newsId`) VALUES
(13, '324234', 26, '2013-06-02 10:31:08', 1, 1),
(14, '52342', 26, '2013-06-02 10:31:03', 0, 2),
(15, 'hhh', 26, '2013-06-02 10:30:17', 0, 1),
(16, 'idream tab', 26, '2013-07-04 12:33:02', 0, 49);

-- --------------------------------------------------------

--
-- Table structure for table `pagecontent`
--

CREATE TABLE IF NOT EXISTS `pagecontent` (
  `pagecontentId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET latin1 NOT NULL,
  `content` text CHARACTER SET latin1 NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '1',
  `metaTag` varchar(200) CHARACTER SET latin1 NOT NULL,
  `metaDescription` varchar(255) CHARACTER SET latin1 NOT NULL,
  `addedBy` int(11) NOT NULL,
  `editedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `parentPage` varchar(10) CHARACTER SET latin1 NOT NULL,
  `preInclude` varchar(50) CHARACTER SET latin1 NOT NULL,
  `postInclude` varchar(50) CHARACTER SET latin1 NOT NULL,
  `seoId` varchar(250) CHARACTER SET latin1 NOT NULL,
  `externalLink` varchar(255) CHARACTER SET latin1 NOT NULL,
  `priority` int(4) NOT NULL,
  `heading` varchar(255) CHARACTER SET latin1 NOT NULL,
  `onHead` tinyint(1) NOT NULL,
  `onBottom` tinyint(1) NOT NULL,
  `openNewTab` tinyint(1) NOT NULL,
  `image` varchar(255) CHARACTER SET latin1 NOT NULL,
  `showImage` tinyint(1) NOT NULL,
  `langId` int(5) NOT NULL,
  `pageCss` text COLLATE utf8_unicode_ci NOT NULL,
  `metaTitle` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pagecontentId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

--
-- Dumping data for table `pagecontent`
--

INSERT INTO `pagecontent` (`pagecontentId`, `title`, `content`, `active`, `metaTag`, `metaDescription`, `addedBy`, `editedBy`, `addedDate`, `parentPage`, `preInclude`, `postInclude`, `seoId`, `externalLink`, `priority`, `heading`, `onHead`, `onBottom`, `openNewTab`, `image`, `showImage`, `langId`, `pageCss`, `metaTitle`) VALUES
(26, 'HOME', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>', 1, 'Home', 'Home', 26, 0, '2013-09-19 10:06:05', '0', '', '', 'home', '', 0, 'vuuuu', 1, 0, 0, '', 0, 1, '<style>.re{color:red;}</style>\r\n<div class="re">This s testing style </div>', ''),
(27, 'ABOUT US', '<p><span style="color: #008000;"><strong>&nbsp;&nbsp;wtbox-about us bengali -wtbox</strong><strong> <img src="../wtos-images/443785_Copy-of-photo-059.jpg" alt="" width="600" height="300" /></strong></span></p>\r\n<p style="text-align: justify;"><span style="color: #008000;"><strong>&nbsp;<br /></strong><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">TECHNO ENVIRON ENGINEERS (TEE) is consultancy organization entirely by specialized team of expertise that positioned industrial growth on the frontier of the Indian economy, in the engineering &amp; environmental map.</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">TECHNO ENVIRON ENGINEERS (TEE) is established for providing consulting engineering and Environment Clearance with EIA Studies services in India. The company offers integrated design and engineering consultancy services from concept to completion for a wide range of projects like </span><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">:<br /></span></em></span><br /><strong><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Integrated steel plant, which consists of Steel Plant, Power Plant, Sponge Iron, Blast Furnace, &nbsp;Rolling Mill, Ferro alloys, Cement Beneficiation.</span></em></span></strong><br /><strong><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Project Management activities like monitoring of present Environmental status and site selection as per the rules of MOEF, CPCB for different Industries.</span></em></span></strong><br /><br /><br /><br /><strong><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">OUR STRENGTHS</span></em></span></strong><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">&nbsp;</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">A tradition of excellence.</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Dedication to achieve goals.<br /></span></em></span><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">To obey the Rules &amp; Regulations of MOEF,&nbsp; CPCB &amp; State P.C.B</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">A team of qualified Engineers / Executives.</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Always towards commitment and solutions</span></em></span><br /><span style="color: #008000;"><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Assurance and working towards customers&rsquo; satisfaction.</span></em><br /><br /><br /><strong><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Services being provided by the Organisation are-</span></em></strong></span></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Environment Impact Assessment</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Design of Effluent Treatment Plant</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Operation and Maintenance of Effluent Treatment Plant, Water Treatment Plant and Sewage Treatment Plant</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Waste Water reuse Plan</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Waste Management Plan</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Air pollution control device supply &amp; commissioning</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Stack Monitoring</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Ambient Air Monitoring</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Air Dispersion Modeling</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Land use Preparation</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Quarry building through GIS System</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">Forest Diversion Plan</span></em></span><br /><span style="color: #008000;"><em><span style="font-size: medium; font-family: arial, helvetica, sans-serif;">&nbsp;</span></em></span><br /><br /><span style="color: #008000;">&nbsp;</span></p>', 1, 'About Us', 'About Us', 26, 0, '2014-03-23 06:08:55', '0', '', '', 'About Us', '', 1, 'ABOUT TECHNO ENVIRON ENGINEERS', 1, 0, 0, 'wtos-images/359009_about-us.png', 0, 1, '', ''),
(31, 'CONTACT US', '<p style="text-align: left;"><img src="../wtos-images/714936_logo%20(1).png" alt="" /><br /><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">TECHNO ENVIRON ENGINEERS</span></em></span><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">At/Po - NILGUNGE BAZAR, BARASAT</span></em></span><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">BARRACKPORE ROAD</span></em></span><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">KOLKATA- 700121</span></em></span><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">TELE/FAX 033-64178869</span></em></span><br /><span style="font-size: medium; color: #008000;"><em><span style="font-family: arial, helvetica, sans-serif;">MOB: 09088919330</span></em></span><br /><span style="color: #008000;">&nbsp;wtpage-contact-us.php-wtpage</span></p>', 1, 'Contact', 'Contact', 26, 0, '2013-05-23 10:59:07', '0', '', '', 'Contact', '', 4, 'Contact', 1, 0, 0, '', 0, 1, '', ''),
(42, 'SERVICES', '<p><br /><img src="../wtos-images/19982_services.jpg.jpg" alt="" width="600" height="350" /><br /><br /><br /><br /></p>\r\n<ul>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Environment Impact Assessment</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Design of Effluent Treatment Plant</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Operation and Maintenance of Effluent Treatment Plant, Water Treatment Plant and Sewage Treatment Plant</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Waste Water reuse Plan</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Waste Management Plan</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Air pollution control device supply &amp; commissioning</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Stack Monitoring</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Ambient Air Monitoring</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Air Dispersion Modeling</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Land use Preparation</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Quarry building through GIS System</span></em></li>\r\n<li><em><span style="color: #008000; font-size: medium; font-family: arial, helvetica, sans-serif;">Forest Diversion Plan.</span></em></li>\r\n</ul>\r\n<p>&nbsp;</p>', 1, 'SERVICES', 'SERVICES', 26, 0, '2013-02-27 12:05:00', '0', '', '', 'services', '', 2, 'SERVICES BEING PROVIDED BY THE ORGANISATION ', 1, 0, 0, '', 0, 1, '', ''),
(46, 'zssfgr', '', 1, 'zssfgr', 'zssfgr', 26, 0, '2013-02-27 10:04:01', '0', '', '', 'zssfgr', '', 0, 'zssfgr', 1, 0, 0, '', 0, 1, '', ''),
(47, 'rfqwet3rt', '', 1, 'rfqwet3rt', 'rfqwet3rt', 26, 0, '2013-03-10 03:27:48', '49', '', '', 'rfqtwer', '', 0, 'rfqwet3rt', 1, 0, 0, '', 0, 1, '', ''),
(48, 'df333333333333333', '', 1, 'df', 'df', 26, 0, '2013-02-27 10:02:05', '0', '', '', 'df', '', 0, 'df', 1, 0, 0, '', 0, 1, '', ''),
(49, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;', '<p>&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503; &#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;</p>', 1, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;', '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;', 26, 0, '2013-02-27 12:10:21', '0', '', '', 'about webtrackers', '', 1, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; &#2488;&#2478;&#2509;&#2474;&#2480;&#2509;&#2453;&#2503;', 1, 0, 0, '', 0, 2, '', ''),
(50, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; ', '<p>?????? ???????? ?????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ?????????????? ????????</p>', 1, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; ', '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; ', 26, 0, '2013-05-17 06:35:23', '0', '', '', 'amara-ke', '', 0, '&#2438;&#2478;&#2494;&#2470;&#2503;&#2480; ', 1, 0, 0, '', 0, 2, '<style>i love you</style>', '');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `settingsId` int(11) NOT NULL AUTO_INCREMENT,
  `keyword` varchar(200) NOT NULL,
  `value` text NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`settingsId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`settingsId`, `keyword`, `value`, `system`) VALUES
(1, 'email', 'admin@webtrackers.co.in', 0),
(2, 'metaKey', 'metaKey 2', 0),
(3, 'metaDescription', 'metaDescription', 0),
(4, 'siteTitle', 'siteTitle', 0),
(5, 'pageCount', '9', 1),
(6, 'homePageId', ' 26', 1),
(7, 'Deactivate Site', '0', 1),
(8, 'Deactivate Message', 'Site Temporarily Under Construction . Please contact admin@webtrtackerts.co.in', 1),
(9, 'Validate Wtos', 'not in use', 1),
(10, 'Validate WtosMessage', 'Please contact admin@webtrackers.co.in to enjoy uninterrupted service.', 1),
(11, 'Validate WtosDate', '==gMwETNtADNtATM', 1),
(12, 'Deactivate Date', '2014-07-02', 1),
(13, 'language', '2', 1),
(14, 'Styles', '<style>StylesStylesStylesStylesStylesStyles</style>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `sliderimage`
--

CREATE TABLE IF NOT EXISTS `sliderimage` (
  `sliderImageId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `langId` int(11) NOT NULL,
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`sliderImageId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `sliderimage`
--

INSERT INTO `sliderimage` (`sliderImageId`, `title`, `image`, `caption`, `langId`, `addedBy`, `addedDate`, `active`) VALUES
(2, '', 'wtos-images/fire_autumn_wallpaper_autumn_nature_wallpaper_1920_1200_widescreen_1452.jpg', '', 0, 26, '2013-03-20 08:48:56', 0),
(5, '', 'wtos-images/Nature Mountains photo.jpg', '', 0, 26, '2013-03-20 08:48:42', 0),
(6, '', 'wtos-images/nature6.jpg', '', 0, 26, '2013-03-20 08:48:49', 0),
(7, '', 'wtos-images/Nature-Full-HD-Wallpaper-national-geographic-7822261-1920-1080.jpg', '', 0, 26, '2013-03-20 08:49:02', 0),
(8, '', 'wtos-images/nature-hd-wallpapers-water.jpg', '', 0, 26, '2013-03-20 08:49:09', 0),
(10, '', 'wtos-images/nature-landscapes-windows-beautiful-wallpaper.jpg', '', 0, 26, '2013-03-20 08:50:03', 0),
(11, '', 'wtos-images/Nature-Spring-Season-Bright-hd-wallpaper.jpg', '', 0, 26, '2013-03-20 08:50:09', 0),
(12, '', 'wtos-images/nature-wallpaper-467926482.jpg', '', 0, 26, '2013-03-20 08:50:15', 0),
(13, '', 'wtos-images/wallpapers-nature-images-artistic-115115.jpg', '', 2, 26, '2013-03-20 08:50:20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `style`
--

CREATE TABLE IF NOT EXISTS `style` (
  `styleId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(25) NOT NULL,
  `css` text NOT NULL,
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`styleId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `style`
--

INSERT INTO `style` (`styleId`, `title`, `css`, `addedBy`, `addedDate`, `active`) VALUES
(1, 'Red Border 1px', 'border:1px solid #FF0000;', 26, '2013-02-27 07:31:54', 0);

-- --------------------------------------------------------

--
-- Table structure for table `wtbox`
--

CREATE TABLE IF NOT EXISTS `wtbox` (
  `wtboxId` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `accessKey` varchar(20) NOT NULL,
  `langId` int(11) NOT NULL,
  `css` text NOT NULL,
  `container` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `tinymce` tinyint(1) NOT NULL,
  `addedBy` int(11) NOT NULL,
  `addedDate` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`wtboxId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wtbox`
--

INSERT INTO `wtbox` (`wtboxId`, `title`, `accessKey`, `langId`, `css`, `container`, `content`, `tinymce`, `addedBy`, `addedDate`, `active`, `system`) VALUES
(1, 'Network', 'Network', 1, 'border:2px solid #000000;padding:10px;', 'div', '', 1, 26, '2014-03-23 06:08:25', 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
