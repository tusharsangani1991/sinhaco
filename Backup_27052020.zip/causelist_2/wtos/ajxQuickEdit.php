<? 
## v-1 author Mizanur Rahaman  mizanur82@gmail.com
session_start();
ob_start();
include('includes/config.php');
include('coomon.php');
ob_end_clean();

function viewQuickRows($options)
{
global $os;
 
extract($options);
if($foreignIdValue!='')
{ $condition .="  $foreignId!='' and $foreignId>0 ";
   $condition .=" and $foreignId='$foreignIdValue'";
}
$tableQuery=str_replace('[condition]',$condition,$tableQuery);
//echo $tableQuery;
$rs=$os->mq($tableQuery);

?>
<table cellpadding="0" cellspacing="0" class="<? echo $functionId ?>">
<tr><td colspan="30" class="PageHeading"> <? echo $PageHeading ?></td></tr>
  <tr>
   <td># <br /> </td>
  <?   
  
  
  ##form
  
  foreach($fields as $fld=>$alise)
  {
       ?>
     <td> <? echo $alise ?> 
	  <br />
	 <? if($type[$fld]=='T' || $type[$fld]==''){ ?> 
	 <input type="text" value="" id="<? echo $functionId.$fld ?>" name="<? echo $fld ?>" class="<? echo $class[$fld] ?>" />
	  <? }
	  else if($type[$fld]=='DD')
	  {
	
	  if($relation[$fld]!='')
	  {
	    
	   if( substr($relation[$fld],0,6)=='select' )
	      {
		     $qq=explode('-fld-',$relation[$fld]);
			 
		      $qq[0]= $os->mq($qq[0]);
			  while( $out=$os->mfa($qq[0]))
			   {
			     $os->ddDataType[$out[$qq[1]]]=$out[$qq[2]];
			   
			   }
	   
	        
	        
			} else
			{
			   $os->ddDataType=$os->{$relation[$fld]} ;
			
			}   
	 
	  
	  }
	  
	  
	  
	  
	   ?> 
	 <select  id="<? echo $functionId.$fld ?>" name=" <? echo $fld ?>" class="<? echo $class[$fld] ?>"> 
	 <?  $os->onlyOption($os->ddDataType); ?>
	 
	 </select>
	 <?  } 
	 else if($type[$fld]=='AC')
	  {
	
	  if($relation[$fld]!='')
	  {
	    
	   if( substr($relation[$fld],0,6)=='select' )
	      {
		     $qq=explode('-fld-',$relation[$fld]);
			 
		      $qq[0]= $os->mq($qq[0]);
			  while( $out=$os->mfa($qq[0]))
			   {
			     $os->ddDataType[$out[$qq[1]]]=$out[$qq[2]];
			   
			   }
	   
	        
	        
			} else
			{
			   $os->ddDataType=$os->{$relation[$fld]} ;
			
			}   
	 
	  
	  }
	  
	  
	  $classAC='autoComp'.$fld;
	  
	   ?> 
	    <input type="text" value="" id="<? echo $functionId.$fld ?>" name="<? echo $fld ?>" class="<? echo $class[$fld] ?> <? echo $classAC?>" />
	   
	 <? 
	 if(is_array($os->ddDataType)){
	 
	 $acString=implode('##',$os->ddDataType);
	 $fldACStr .=$classAC.'-CLASSSTR-'.$acString.'-MULTIPLEAC-';
	// echo $fldACStr;
	 }
	    
	 
	 // $os->onlyOption($os->ddDataType); ?>
	 
	 
	 <?  } ?>
	 
	 </td>
  
  <? 
   
  
  
  }
  ?>
  <td> &nbsp; <br /><input type="button" class="qaddButton" value="+"  onclick="<? echo $ajaxEditFunction ?>('<? echo $foreignIdValue ?>');" /></td>
   </tr>
  
   

<?
$sl=1;
while($row=$os->mfa($rs))
{


 ?>
 
  
 
  
  <tr>
  <td style="color:#FF8040; font-weight:bold;"><? echo $sl?> &nbsp;&nbsp; </td>
  <?
 foreach($fields as $fld=>$alise)
  {
       ?>
     <td>  
	 <? if($type[$fld]=='T' || $type[$fld]=='' ||  $type[$fld]=='AC'){  ##  view date need to add for date fields
	 
	  ?> 
	<? echo $row[$fld] ?>
	  <? }else if($type[$fld]=='DD'){
	
	  if($relation[$fld]!='')
	  {
	    
	   if( substr($relation[$fld],0,6)=='select' )
	      {
		     $qq=explode('-fld-',$relation[$fld]);
			 
		      $qq[0]= $os->mq($qq[0]);
			  while( $out=$os->mfa($qq[0]))
			   {
			     $os->ddDataType[$out[$qq[1]]]=$out[$qq[2]];
			   
			   }
	   
	        
	        } else
			{
			   $os->ddDataType=$os->{$relation[$fld]} ;
			
			}   
	 
	  
	  }
	  
	  
	  
	  echo $os->ddDataType[$row[$fld]];
	   ?> 
	 <select   class="<? echo $class[$fld] ?>" style="display:none;"> 
	 <? //  $os->onlyOption($os->ddDataType,$row[$fld]); ?>
	 
	 </select>
	 <?  } ?>
	 
	 </td>
  
  <? 
  
  
  }

?>
 <td> <input type="button" class="qdeleteButton" value="-"  onclick="<? echo $ajaxDeleteFunction ?>('<? echo $row[$tableId] ?>');" /></td>
   </tr>
  
  
  

<?
$sl++;
}

?>   </table> 
<?
echo '-DATAFORM--AUTOCOMPLETE-'.$fldACStr.'-AUTOCOMPLETE-';

}



if($_GET['getQuickEditValues']=='OK')
{
  
	
	$aQEsessonKey=varG('aQEsessonKey');
	$options=$_SESSION[$aQEsessonKey];
	$foreignIdVal=varG('foreignId');
	if($foreignIdVal==$options['foreignIdValue'])
	{
	extract($options);
	##   code starts
	

	
	
	
 foreach($fields as $fld=>$alise)
  {
      $dataForSave[$fld]=$_GET[$fld];
	   if($type[$fld]=='DATE')##  view date need date format
	  {  
	  
	  }
	
  
  
  }
  
  if($foreignIdVal>0){
  
  $dataForSave[$foreignId]=$foreignIdVal;
  }
  
	$dataForSave['addedBy']=$os->userDetails['adminId'];
	$dataForSave['addedDate']=date("Y-m-d h:i:s");
	$os->saveR($table,$dataForSave);
	
	
	
	##   view data
	
	viewQuickRows($options);
	
	
	}
	 
	
	exit();
}

if($_GET['getQuickViewValues']=='OK')
{
  
	
	$aQEsessonKey=varG('aQEsessonKey');
	$options=$_SESSION[$aQEsessonKey];
	$foreignIdVal=varG('foreignId');
	if($foreignIdVal==$options['foreignIdValue'])
	{
//s	extract($options);
	##   code start
	
	##   view datas
viewQuickRows($options);
	
	
	
	}
	
	exit();
}


if($_GET['getQuickDeleteValues']=='OK')
{
  
	
	$aQEsessonKey=varG('aQEsessonKey');
	$options=$_SESSION[$aQEsessonKey];
	$tableIdVal=varG('tableId');
	$table=$options['table'];
	$tableId=$options['tableId'];
	
	$tableQuery="delete from $table where  $tableId='$tableIdVal' ";
	$rs=$os->mq($tableQuery);
	viewQuickRows($options);
	exit();
}