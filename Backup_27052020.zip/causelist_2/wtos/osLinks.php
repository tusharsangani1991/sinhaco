<style>
.linkClass{
margin:2px 5px 2px 20px;
}

.linkCss{ text-decoration:none; color:#004E9B; margin:1px 5px 1px 2px; border:1px solid #5C5C5C; background:#ECF5FF;
border-top:none;
border-left:none;
height:15px; width:130px; padding:3px 3px 3px 3px; 
-moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px;
display:block;
font-weight:none;


}
.linkCss:hover{ text-decoration:none; color:#FFFFFF; margin:1px 5px 1px 2px; border:1px solid #002435; background:#0098E1;
border-top:none;
border-left:none;
height:15px; width:130px; padding:3px 3px 3px 3px;
-moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px;
display:block;
font-weight:bold;}
.linkCssSelected{text-decoration:none; color:#FFFFFF; margin:1px 5px 1px 2px; border:1px solid #002435; background:#0098E1;
border-top:none;
border-left:none;
height:15px; width:130px; padding:3px 3px 3px 3px;
-moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px;
display:block;
font-weight:bold;
}

.ca{ height:0px; clear:both; width:50px;}
</style>
<? 
						function sTab($pname )
						{
						 global $os;
						
						  $class='linkCss';
						  if($pname.'.php'==$os->currentPage)
						  {
						      $class='linkCssSelected';
							 
						  }
						 echo "class='$class'";
						}
						
						
						?>
						 
						
							
					<a <? sTab('dashBoard') ?> href="<? $seoLink->l('dashBoard',true); ?>" >Dash Board</a> <div class="ca">&nbsp;</div> 
					<a <? sTab('uploadPDFText') ?> href="<? $seoLink->l('uploadPDFText',true); ?>" >Upload PDF Text</a> <div class="ca">&nbsp;</div> 
					<a <? sTab('outPut') ?> href="<? $seoLink->l('outPut',true); ?>" >Search</a> <div class="ca">&nbsp;</div> 
					<a <? sTab('cases') ?> href="<? $seoLink->l('cases',true); ?>" >Case List</a> <div class="ca">&nbsp;</div> 
					<a <? sTab('casesUpload') ?> href="<? $seoLink->l('casesUpload',true); ?>" >Upload Excel</a> <div class="ca">&nbsp;</div>
					
					  <?php if($os->checkAccess('Edit')){?>
					<a <? sTab('casesUpdate') ?> href="<? $seoLink->l('casesUpdate',true); ?>" >Edit Cases</a> <div class="ca">&nbsp;</div>
				
				
					<? } ?>
					
					<a <? sTab('dailylist') ?> href="<? $seoLink->l('dailylist',true); ?>" >Daily List</a> <div class="ca">&nbsp;</div> 
					<a <? sTab('monthlylist') ?> href="<? $seoLink->l('monthlylist',true); ?>" >Monthly List</a> <div class="ca">&nbsp;</div> 
					<?php if($os->checkAccess('SMS Template')){?>
					<a <? sTab('smsTemplate') ?> href="<? $seoLink->l('smsTemplate',true); ?>" >SMS Template</a> <div class="ca">&nbsp;</div> 	
						
					<?}?> 
						 
						<? if($os->userDetails['adminType'] == 'Super Admin') {?>	
							<a <? sTab('admin') ?> href="<? $seoLink->l('admin',true); ?>" >Admin</a> <div class="ca">&nbsp;</div> 
					<?  } ?>
					<? if($linkok=='ok'){?>
						
						<a <? sTab('pageContent') ?>  href="<? $seoLink->l('pageContent',true); ?>" >Pages</a><div class="ca">&nbsp;</div>
						
						<a <? sTab('news') ?>  href="<? $seoLink->l('news',true); ?>" >Latest News</a><div class="ca">&nbsp;</div>
						
						<a <? sTab('lang') ?>  href="<? $seoLink->l('lang',true); ?>" >Language</a><div class="ca">&nbsp;</div>
						
						<a <? sTab('appearance') ?>  href="<? $seoLink->l('appearance',true); ?>" >Appearance</a><div class="ca">&nbsp;</div>
						<a <? sTab('sliderimage') ?>  href="<? $seoLink->l('sliderimage',true); ?>" >Sliderimage</a><div class="ca">&nbsp;</div>
						<a <? sTab('style') ?>  href="<? $seoLink->l('style',true); ?>" >Style</a><div class="ca">&nbsp;</div>
				 <a <? sTab('wtbox') ?>  href="<? $seoLink->l('wtbox',true); ?>" >BOX</a><div class="ca">&nbsp;</div>
						
						<a <? sTab('contactus') ?>  href="<? $seoLink->l('contactus',true); ?>" >Enquiries</a><div class="ca">&nbsp;</div>
						 
						<a <? sTab('imageuploader') ?> href="<? $seoLink->l('imageuploader',true); ?>" >Image Uploader</a> <div class="ca">&nbsp;</div>
							<a <? sTab('changepwd') ?> href="<? $seoLink->l('changepwd',true); ?>" >Change Password </a>  <div class="ca">&nbsp;</div>
						<a <? sTab('settings') ?> href="<? $seoLink->l('settings',true); ?>" > Settings</a> <div class="ca">&nbsp;</div> 
		   
						
						<? } ?>