<?php
include('includes/config.php');
include('top.php');
 
 
 


// config 

$DivIds['AJAXPAGE']='casesEdit';
$listPAGE='cases';
$primeryTable='cases';
$primeryField='casesId';
$listHeader='Upload Daily and monthly list from PDF Text';
$action='';
## upload and save xls 444
  
$failMsg='';

if($_POST['uploadtxt']=='OK' )
{
 if($_POST['uploadType']=='Upload Daily List' ){
 
 
  $os->dailyText=$_POST['dailyText'];
   if(trim($os->dailyText)!=''){
  importDailyListPDFText();
  }
 //_d($dailyText);
  
 
 }
 
 if($_POST['uploadType']=='Upload Monthly List' ){
 
 
 
 
  $os->monthlyText=$_POST['monthlyText'];
   if(trim($os->monthlyText)!=''){
  importMonthlyListPDFText();
  }
 
 
 }


}
## upload and save xls 444

$os->setFlash($flashMsg);
//tinyMce();

//searching......

 

?>

	<table class="container">
				<tr>
					<td  class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td  class="middle" style="padding-left:5px;">
			  
			  
			  <div class="listHeader"> <?php  echo $listHeader; ?></div>
			  
			  <!--  ggggggggggggggg   -->
			 
			  <?  if($failMsg!=''){ 
			  ?>
			  <div style="color:#FF0000;"> <b><? echo  $failMsg?> </b></div>
			  <? 
			  } ?>
			 
			  <form action="" enctype="multipart/form-data" method="post">
			 
				<table border="0" cellspacing="1" cellpadding="1">
  <tr>
    <td>Daily text<span style="color:#006600; font-size:9px; font-style:italic">&nbsp;  Copy text from Downloaded PDF[Daily list] and paste here</span></td>
    <td>Monthly text<span style="color:#006600; font-size:9px; font-style:italic">&nbsp;  Copy text from Downloaded PDF[Monthly list] and paste here</span></td>
  </tr>
  <tr>
    <td><textarea rows="30" cols="60" name="dailyText"></textarea></td>
    <td><textarea rows="30" cols="60" name="monthlyText"></textarea></td>
  </tr>
   <tr>
    <td> <input type="submit" name="uploadType" value="Upload Daily List"  style="cursor:pointer; color:#009900" /></td>
    <td> <input type="submit" name="uploadType" value="Upload Monthly List"  style="cursor:pointer; color:#009900" /></td>
  </tr>
</table>
						  
										  
	
			  
			<input type="hidden" name="uploadtxt" value="OK" />
			   
			   
			  
			   
			 
			  
			 </form>
			 
		
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>







	
    
    
   
	<? include('bottom.php')?>