<?php


include('includes/config.php');
include('top.php');
 
$os->setFlash($flashMsg);
?>


<? 
$fusionChart=false;

 $caseLinks=$os->getRowById('caselinks','caselinksId',1);

  

 ?>


	<table class="container">
				<tr>
					<td   class="leftside">
						
				 
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td   class="middle" style="padding-left:5px;">
			  
			  
			  <!--  ggggggggggggggg   -->
		<style>
		.checkList{ border:1px solid #990099; margin:5px; padding:5px; height:40px; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; width:200px; float:left; background-color:#999999; cursor:pointer;}
		.checkList:hover{ background-color:#3333CC;}
		.checkListSelected{  border:1px solid #990099; margin:5px; padding:5px; height:40px; -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; width:200px; float:left; background-color:#3333CC; cursor:pointer;}
		</style>
		<style>
		.loadImage{ margin:5px 0px 0px 2px; float:left; width:35px;}
		.loadText{ margin:10px 0px 0px 0px;float:left; width:160px; font-size:12px; font-style:italic; font-weight:bold; color:#FFFFFF;}
		.lodingText{ margin:10px 0px 0px 0px;float:left; width:160px; font-size:12px; font-style:italic; font-weight:bold; color:#0000FF;}
		.import{opacity: 0.7;
		filter: alpha(opacity=70);}
		.import:hover{opacity: 1;
		filter: alpha(opacity=100);}
		.searchResults{  border:1px solid #3333CC;  -moz-border-radius:3px; -webkit-border-radius:3px; border-radius:3px; padding:2px;}
		
		</style>
			 
			  <!--<div class="headertext">  </div>-->
			  <div style="width:1100px; height:500px; margin:10px 0px 0px 20px;">
			   <div class="checkList" style="font-size:18px; color:#9900CC; font-style:italic; font-weight:bold; text-align:center; display:none;">Welcome to Causelist Extractor</div>
			  
			   
			   <table><tr><td valign="top">
			    Key : <input type="text" name="searchKewords" id="searchKewords" style="width:400px;" value="<? echo $caseLinks['keywords'] ?>"/>
				
				 <input type="hidden" name="searchKewords" id="searchKewords1" style="width:400px;" value="<? echo $caseLinks['keywords'] ?>"/>
				  <input type="hidden" name="searchKewords" id="searchKewords2" style="width:400px;" value="<? echo $caseLinks['keywords2'] ?>"/>
				   <input type="hidden" name="searchKewords" id="searchKewords3" style="width:400px;" value="<? echo $caseLinks['keywords3'] ?>"/>
				
				<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  <span style="font-size:10px; font-style:italic; color:#990099;"> Enter multiple keyword seperated by comma(,) </span>
			   </td><td valign="top">
			   Department:
			    <? if($os->userDetails['adminType']=='Admin'){ ?>
   <input type="text" name="dept" id="dept" value="<? echo $defaultDeptCode?>"  readonly="1" style="width:125px;" />
    
										  <? } else{?>
										  
	
	<select name="dept" id="dept" class="textbox fWidth" onchange="setKey();" ><? 
										  $os->onlyOption($os->department,$dept);	?></select>	
										 
										  <? } ?>
			   </td></tr></table>
			   <? 
			    $searchAcc='display:none;';
				if($os->userDetails['adminType']!='Admin'){$searchAcc='';}
			   ?>
			   <div style="clear:both; height:1px;">&nbsp;</div>
			   <div class="checkList" style=" <? echo $searchAcc ?> " id="Tab1" onclick="searchByKey('1')"> 
			   <div class="loadImage"><img  src="<? echo $excelImg ?>" /> </div><div class="loadText">Search By Keywords:  </div> 
			    
			  </div>
			 
			  <div class="checkList" style=" <? echo $searchAcc ?> " id="Tab2" onclick="searchByCaseNo('2')"> 
			   <div class="loadImage"><img  src="<? echo $excelImg ?>" /> </div><div class="loadText">Search By Case List </div> 
			  
			  </div>
			    
			  <div class="checkList" id="Tab3" onclick="searchByKeyAndCase('3')" style="width:200px;"> 
			   <div class="loadImage"><img  src="<? echo $excelImg ?>" /> </div><div class="loadText"> Conbine:</div> 
			   
			  </div>
			  <div id="orderByhod" class="checkList" style="background-color:#FFFFFF; border:none" > 
			  <input type="checkbox" id="orderBy"  /> Order By HOD
			   
			  </div>
			  
			  
			  <div style="clear:both; height:1px;">&nbsp;</div>
			     
				 
				 
			   <div id="div_searchData" style="padding:5px;"> &nbsp; 
			   
			   
			   
			   </div>
			   
			    
			  </div>
				 
				 
				
			  
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>


 <script> 
 <? $loadImage=$site['url'].'image/loading.gif';?>
 
 
 function notinuse_searchAndPrint(key)
 {
    var searchKewords = os.getVal('searchKewords');
	 searchKewords=searchKewords.replace('&' ,'*AND*');
	  var dept = os.getVal('dept');
	var url='key='+key+'&searchKewords='+searchKewords+'&dept='+dept+'&';
	url='<? echo $site['url'] ?>/ajaxCauselist.php?SearchData=OK&'+url;
 }
 
function searchData(key)
{
     var searchKewords = os.getVal('searchKewords');
	 searchKewords=searchKewords.replace('&' ,'*AND*');
	  var dept = os.getVal('dept');
	  var orderBy=os.getObj('orderBy').checked;
	  if(orderBy){orderBy='hod';}else{orderBy='';}
	//  alert(orderBy);
	// return; 
	var url='key='+key+'&searchKewords='+searchKewords+'&dept='+dept+'&orderBy='+orderBy+'&';
	url='<? echo $site['url'] ?>/ajaxCauselist.php?SearchData=OK&'+url;
	 
	 
	os.animateMe.div='div_searchData';
	os.animateMe.html='<div class="loadImage"><img  src="<? echo $loadImage ?>" /> </div><div class="lodingText">&nbsp;Please wait. Searching in progress...</div>';
	os.setAjaxFunc('searchDataView',url);
	return false;

}
function searchDataView(data)
{
os.setHtml('div_searchData',data);

}

function checkedTab(st)
{
for(var i=1;i<=3;i++)
{
var tabid='Tab'+i;
  os.getObj(tabid).className='checkList';


}
 tabid='Tab'+st;
os.getObj(tabid).className='checkListSelected';

}

function searchByKey(tabId)
{
  checkedTab(tabId);
  searchData('searchByKey');

}
function searchByCaseNo(tabId)
{
  checkedTab(tabId);
   searchData('searchByCaseNo');
}

function  searchByKeyAndCase(tabId)
{
 checkedTab(tabId);
 searchData('searchByKeyAndCase');
}


function setKey()
{
 var searchKewords1 = os.getVal('searchKewords1');
  var searchKewords2 = os.getVal('searchKewords2');
   var searchKewords3 = os.getVal('searchKewords3');
    var depts = os.getVal('dept');
	var keys='';
	//alert(depts);
	if(depts=='Dept. 1'){ keys=searchKewords1; os.show('orderByhod');   }
	if(depts=='Dept. 2'){ keys=searchKewords2;os.show('orderByhod');  }
	if(depts=='Dept. 3'){ keys=searchKewords3;os.hide('orderByhod');  }
	os.setVal('searchKewords',keys);

}
</script>



<script>
		function printById(id){ // not in use
      	 
			var data = document.getElementById(id).innerHTML;
			
		 
			var  mywindow = window.open('bw', 'btp', 'height=600,width=1100,toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
			mywindow.document.write('<html><head> ');			
			/*optional stylesheet*/ //mywindow.document.write('<link rel="stylesheet" href="main.css" type="text/css" />');
			
			//mywindow.document.write('<link rel="stylesheet" href="http://localhost/broadwayandwest.co.uk/wtos/wtos-theme/css/style.css" type="text/css" />');
			
			mywindow.document.write('<style>.billPrint table td{ border-bottom:1px solid #F7F7F7;}</style></head><body>');
			mywindow.document.write(data);
			
			
			mywindow.document.write('</body></html>');
			mywindow.print();	
		//	mywindow.close();
			//mywindow.document.close();			
			//return true;
		
		}
	</script>
	 <? if($os->userDetails['adminType']=='Admin'){ ?>
    
   <script>
										  setKey(); </script>
										  <? } ?>


   
	<? include('bottom.php')?>