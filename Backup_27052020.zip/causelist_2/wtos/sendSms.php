<?php

set_time_limit (0 );
ini_set('max_input_vars', 100000);
class sms{
function sendSMS($smsText,$smsNumbersStr)
{
$sendComfirm=true;
 
 $post='';
$sendTme=date('Y-m-d h:i:s');
$smsNumbersStrArr=explode(',',$smsNumbersStr);  
$smsFinalStrArr=array();
foreach($smsNumbersStrArr as $val)
{
  if(trim($val)!='')
  {
  
  $smsFinalStrArr[]=$val;
  
  }
}

 ?>


 <?   
if($sendComfirm && count($smsFinalStrArr)>0){
    // GSERMC
  $url = "http://malert.in/new/api/api_http.php";
    $recipients = array('8017477871');
    $param = array(
        'username' => 'SINHAP',
        'password' => 'cause@2018',
        'senderid' => 'SINHAP',
        'text' => $smsText,
        'route' => 'Informative',
        'type' => 'text',
        'to' => implode(';', $smsFinalStrArr),
    );
   // $post = http_build_query($param, '', '&amp;');
	 foreach ($param as $key => $val) {
        $post .= '&' . $key . '=' . rawurlencode($val);
    }
	//echo $post;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Connection: close"));
    $result = curl_exec($ch);
    if(curl_errno($ch)) {
        $result = "cURL ERROR: " . curl_errno($ch) . " " . curl_error($ch);
    } else {
        $returnCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        switch($returnCode) {
            case 200 :
                break;
            default :
                $result = "HTTP ERROR: " . $returnCode;
        }
    }
	
    curl_close($ch);
	return($result);

 }

}

function sendSmsAndGetMsgId($mobileNo,$smsText)
{
	  $fc=file_get_contents ('https://malert.in/api/api_http.php?username=SINHAP&password=cause@2018&senderid=SINHAP&to='.$mobileNo.'&text='.$smsText.'&route=Informative&type=text');
	  return($fc);
	
}



function balance()
{
	
	 
	
	 $fc=file_get_contents ('http://malert.in/new/api/api_http_balance.php?username=SINHAP&password=cause@2018&route=Informative');
	$fc=json_decode($fc);
	$fc=$fc[0];
	echo $fc->balance;
}


function template($id='',$arrData=array())
{
  $template='';

  if($id=='New_OTP')
  {
   
	$template='Dear USER your OTP is #OTP# Please enter OTP to continue';
  }
  if($id=='MSG_SEND')
  {
    $template='Dear applicant your OTP is 71534 Please enter OTP to continue.';
	//$template=$text;
  }
  
  
 foreach($arrData as $key=>$val)
	{
		 $template= str_ireplace( $key, $val,$template);
	}  
  
  
  return $template;

}

}