<?php
include('includes/config.php');
include('top.php');


if($os->userDetails['adminType']=='Admin'){
$_GET['dept']=$defaultDeptCode;
}



if($_GET['dept']=='')
{
   $_GET['dept']=$defaultDeptCode;  ## for superAdmin

}
$deptCode=$_GET['dept'];
//echo $deptCode;
// config 

$DivIds['AJAXPAGE']='casesEdit';
$listPAGE='cases';
$primeryTable='cases';
$primeryField='casesId';
$listHeader='List Cases';

 
$DivIds['EDITPAGE']=$site['url'].$DivIds['AJAXPAGE'].'.php?'.$os->addParams(array('hideTopLeft'),'').'editRowId=';
$listPAGEUrl=$listPAGE.'.php?'.$os->addParams(array('hideTopLeft'),'');
##  delete row
if(varG('operation')=='deleteRow')
{
       if($os->deleteRow($primeryTable,$primeryField,varG('delId')))
	   {
	     $flashMsg='Data Deleted Successfully';
	   }
}


##  update row
if(varP('operation'))
{

	 if(varP('operation')=='updateField')
	 {
	  $rowId=varP('rowId');
	
	  #---- edit section ----#
		
		
 $dataToSave['slNo']=varP('slNo'); 
 $dataToSave['dated']=varP('dated'); 
 $dataToSave['caseNo']=varP('caseNo'); 
 $dataToSave['title']=varP('title'); 
 $dataToSave['dept']=varP('dept'); 
 $dataToSave['tag']=varP('tag'); 
 $dataToSave['hod']=varP('hod'); 
 $dataToSave['clientRep']=varP('clientRep'); 
 $dataToSave['background']=varP('background'); 
 $dataToSave['Instruction']=varP('Instruction'); 
 $dataToSave['aorNo']=varP('aorNo'); 
 $dataToSave['aorCouncel']=varP('aorCouncel'); 
 $dataToSave['councel_1']=varP('councel_1'); 
 $dataToSave['councel_2']=varP('councel_2'); 
 $dataToSave['remarks']=varP('remarks'); 
 $dataToSave['status']=varP('status'); 

		 
		$dataToSave['modifyDate']=$os->now();
		$dataToSave['modifyBy']=$os->userDetails['adminId']; 
		 
		if($rowId < 1){
		$dataToSave['addedDate']=$os->now();
		$dataToSave['addedBy']=$os->userDetails['adminId'];
		}
		
		
		
	 
	 
	  
	  $insertedId=$os->save($primeryTable,$dataToSave,$primeryField,$rowId);
	  $flashMsg=($rowId)?'Record Updated Successfully':'Record Added Successfully';
	  $os->popUpSaveAssign($insertedId);
	  #---- edit section end ----#
	
	 }
	
	
}
 

/* searching */

 
$andslNoA=  $os->andField('slNo','slNo',$primeryTable,'%');
   $slNo=$andslNoA['value']; $andslNo=$andslNoA['andField'];	 
$anddatedA=  $os->andField('dated','dated',$primeryTable,'%');
   $dated=$anddatedA['value']; $anddated=$anddatedA['andField'];	 
$andcaseNoA=  $os->andField('caseNo','caseNo',$primeryTable,'%');
   $caseNo=$andcaseNoA['value']; $andcaseNo=$andcaseNoA['andField'];	 
$andtitleA=  $os->andField('title','title',$primeryTable,'%');
   $title=$andtitleA['value']; $andtitle=$andtitleA['andField'];	 
$anddeptA=  $os->andField('dept','dept',$primeryTable,'%');
   $dept=$anddeptA['value']; $anddept=$anddeptA['andField'];	 
$andtagA=  $os->andField('tag','tag',$primeryTable,'%');
   $tag=$andtagA['value']; $andtag=$andtagA['andField'];	 
$andhodA=  $os->andField('hod','hod',$primeryTable,'%');
   $hod=$andhodA['value']; $andhod=$andhodA['andField'];	 
$andclientRepA=  $os->andField('clientRep','clientRep',$primeryTable,'%');
   $clientRep=$andclientRepA['value']; $andclientRep=$andclientRepA['andField'];	 
$andbackgroundA=  $os->andField('background','background',$primeryTable,'%');
   $background=$andbackgroundA['value']; $andbackground=$andbackgroundA['andField'];	 
$andInstructionA=  $os->andField('Instruction','Instruction',$primeryTable,'%');
   $Instruction=$andInstructionA['value']; $andInstruction=$andInstructionA['andField'];	 
$andaorNoA=  $os->andField('aorNo','aorNo',$primeryTable,'%');
   $aorNo=$andaorNoA['value']; $andaorNo=$andaorNoA['andField'];	 
$andaorCouncelA=  $os->andField('aorCouncel','aorCouncel',$primeryTable,'%');
   $aorCouncel=$andaorCouncelA['value']; $andaorCouncel=$andaorCouncelA['andField'];	 
$andcouncel_1A=  $os->andField('councel_1','councel_1',$primeryTable,'%');
   $councel_1=$andcouncel_1A['value']; $andcouncel_1=$andcouncel_1A['andField'];	 
$andcouncel_2A=  $os->andField('councel_2','councel_2',$primeryTable,'%');
   $councel_2=$andcouncel_2A['value']; $andcouncel_2=$andcouncel_2A['andField'];	 
$andremarksA=  $os->andField('remarks','remarks',$primeryTable,'%');
   $remarks=$andremarksA['value']; $andremarks=$andremarksA['andField'];	 
$andstatusA=  $os->andField('status','status',$primeryTable,'%');
   $status=$andstatusA['value']; $andstatus=$andstatusA['andField'];	 

   

$listingQuery=" select * from $primeryTable where $primeryField>0   $andslNo  $anddated  $andcaseNo  $andtitle  $anddept  $andtag  $andhod  $andclientRep  $andbackground  $andInstruction  $andaorNo  $andaorCouncel  $andcouncel_1  $andcouncel_2  $andremarks  $andstatus    $andActive order by  $primeryField desc  ";

##  fetch row
$recordsA=$os->pagingResult($listingQuery,$recordPerPage);
$records=$recordsA['records'];


 

$os->setFlash($flashMsg);
//tinyMce();

//searching......




?>
<style>

	.slNo{}
	.dated{}
	.caseNo{}
	.title{}
	.dept{}
	.tag{}
	
	<? if($deptCode=='Dept. 1' || $deptCode=='Dept. 2' ){ ?>
	.aorNo{ display:none;}
	.aorCouncel{display:none;}
	.councel_1{display:none;}
	.councel_2{display:none;}
	<? } ?>
	<? if($deptCode=='Dept. 3' ){ ?>
	.hod{display:none;}
	.clientRep{display:none;}
	.background{display:none;}
	.Instruction{display:none;}
	<? } ?>
	
	
	
	
	.remarks{}
	.status{}
	</style>			
	<table class="container">
				<tr>
					<td  class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td  class="middle" style="padding-left:5px;">
			  
			  
			  <div class="listHeader"> <?php  echo $listHeader; ?></div>
			  
			  <!--  ggggggggggggggg   -->
			  
			  <div class="headertext">Search Option   <span style="float:right">Record per page  <?php  echo $recordPerPageDDS; ?></span></div>
			  <div class="searchB">
<table cellpadding="0" cellspacing="0">
	<tr>
	<td class="buttonSa">
	

 
   Case No: <input type="text" name="caseNo" id="caseNo" value="<?php echo $caseNo?>" style="width:100px;" /> &nbsp;  
   Title: <input type="text" name="title" id="title" value="<?php echo $title?>" style="width:100px;" /> &nbsp;  
   
   <? if($os->userDetails['adminType']=='Admin'){ ?>
   <input type="hidden" name="dept" id="dept" value="<? echo $defaultDeptCode?>" />
										  
										  <? } else{?>
										   Dept.:
	
	<select name="dept" id="dept" class="textbox fWidth" ><option value="">Select Dept.</option>	<? 
										  $os->onlyOption($os->department,$dept);	?></select>	
										 
										  <? } ?>
  
   Status:
	
	<select name="status" id="status" class="textbox fWidth" ><option value="">Select Status</option>	<? 
										  $os->onlyOption($os->caseStatus,$status);	?></select>	
  
	 <div style="display:none;">
	 SL No: <input type="text" name="slNo" id="slNo" value="<?php echo $slNo?>" style="width:100px;" /> &nbsp;  
   Date: <input type="text" name="dated" id="dated" value="<?php echo $dated?>" style="width:100px;" /> &nbsp;  
   
    Tag: <input type="text" name="tag" id="tag" value="<?php echo $tag?>" style="width:100px;" /> &nbsp;  
   HOD: <input type="text" name="hod" id="hod" value="<?php echo $hod?>" style="width:100px;" /> &nbsp;  
   Client Rep.: <input type="text" name="clientRep" id="clientRep" value="<?php echo $clientRep?>" style="width:100px;" /> &nbsp;  
   Background: <input type="text" name="background" id="background" value="<?php echo $background?>" style="width:100px;" /> &nbsp;  
   Instruction: <input type="text" name="Instruction" id="Instruction" value="<?php echo $Instruction?>" style="width:100px;" /> &nbsp;  
   Aor No: <input type="text" name="aorNo" id="aorNo" value="<?php echo $aorNo?>" style="width:100px;" /> &nbsp;  
   Aor-Councel: <input type="text" name="aorCouncel" id="aorCouncel" value="<?php echo $aorCouncel?>" style="width:100px;" /> &nbsp;  
   Councel-1: <input type="text" name="councel_1" id="councel_1" value="<?php echo $councel_1?>" style="width:100px;" /> &nbsp;  
   Councel-2: <input type="text" name="councel_2" id="councel_2" value="<?php echo $councel_2?>" style="width:100px;" /> &nbsp;  
   Remarks: <input type="text" name="remarks" id="remarks" value="<?php echo $remarks?>" style="width:100px;" /> &nbsp;  
	 </div>
	
	<a class="searchButton" href="javascript:void(0)" onclick="javascript:searchText()">Search</a>
	&nbsp;
	<a class="resetButton" href="javascript:void(0)"   onclick="javascript:searchReset()">Reset</a>
	
	</td>
	</tr>
</table>
				</div>
				 <div class="headertext" style="margin-top:10px;">Total <? echo $os->paging->p['count']; ?>
				 <a class="tlinkCss refresh" href="" style="margin-left:20px; color:#000033"> Refresh </a>   &nbsp;&nbsp;
				 <a class="tlinkCss" style="color:#FF0000;" href="<? $seoLink->l('casesUpload',true); ?>"> Upload Excel </a>   &nbsp;&nbsp;
				
				 <span style="float:right;display:none;"><a  class="addButton"  href="javascript:void(0)" onclick="os.editRecord('<? echo $DivIds['EDITPAGE']?>0') ">Add record</a></span></div>
				 
				 <table  border="0" cellspacing="0" cellpadding="0" class="listTable" >
							<tr class="borderTitle" >
								<td >#</td>
								
								
  <td class="slNo" ><b>SL No</b></td>  
  <td class="dated" ><b>Date</b></td>  
   <td class="aorNo" ><b>Aor No</b></td>  
  <td class="caseNo" width="100" ><b>Case No</b></td>  
  <td class="title" ><b>Title</b></td>  
 <!-- <td class="dept" ><b>Dept.</b></td>  -->
  <td  class="tag"><b>Tag</b></td>  
  <td class="hod" ><b>HOD</b></td>  
  <td class="clientRep" ><b>Client Rep.</b></td>  
  <td class="background" ><b>Background</b></td>  
  <td class="Instruction" ><b>Instruction</b></td>  
 
  <td class="aorCouncel" ><b>Aor-Councel</b></td>  
  <td class="councel_1" ><b>Councel-1</b></td>  
  <td class="councel_2" ><b>Councel-2</b></td>  
  <td class="remarks" ><b>Remarks</b></td>  
  <td class="status" ><b>Status</b></td>  
  
								
								 
								
                                
								
								
								<td >Action </td>
								
							</tr>
							
							
							
							
							
							<?php
							  $c=1;
							 $i=$os->slNo();
							 if(is_array($records)){ foreach($records as $k=>$record){ 
							    
								 $DivIds =$os->divIds($record[$primeryField], $DivIds);
																 
								 $selected=0;
								
							
							 ?>
							
							<tr class="border" id="selected<?php echo $c;?>" onclick="trSelected('<?php echo $c;?>','<?php echo  count($records);?>');"   onmouseover="javascript:miz.switchRow('<?php echo  $DivIds['BUTTONS']; ?>')">
								<td><?php echo $i?>     </td>
								
								
								
					
								
<td class="slNo"><b><?php echo $record['slNo']?></b> </td>  
  <td  class="dated"><?php echo $record['dated']?> </td>  
   <td  class="aorNo"><?php echo $record['aorNo']?> </td> 
  <td  class="caseNo"><?php echo nl2br($record['caseNo'])?> </td>  
  <td  class="title"><?php echo $record['title']?> </td>  
  
  <td  class="tag"><?php echo $record['tag']?> </td>  
  <td  class="hod"><?php echo $record['hod']?> </td>  
  <td  class="clientRep"><?php echo $record['clientRep']?> </td>  
  <td  class="background"><?php echo nl2br($record['background'])?> </td>  
  <td  class="Instruction"><?php echo nl2br($record['Instruction'])?> </td>  
  
  <td  class="aorCouncel"><?php echo $record['aorCouncel']?> </td>  
  <td  class="councel_1"><?php echo $record['councel_1']?> </td>  
  <td  class="councel_2"><?php echo $record['councel_2']?> </td>  
  <td  class="remarks"><?php echo $record['remarks']?> </td>  
  <td  class="status"><?php echo  
	$os->caseStatus[$record['status']]; ?></td> 
  
							 	
								
						  <td class="actionLink">                   
                        <span id="<?php echo  $DivIds['BUTTONS']; ?>"  style="display:none"  class="buttonSa">
						 <?php if($os->checkAccess('Edit')){?>
						<a style="display:none;" class="editButton" href="javascript:void(0)" onclick="os.editRecord('<? echo $DivIds['EDITPAGE']?><?php echo  $DivIds['EDITID']; ?>')">Edit</a>
						<? } ?>
						 <?php if($os->checkAccess('Delete')){?>
						<a class="deleteButton" href="javascript:void(0)" onclick="os.deleteRecord('<?php echo  $DivIds['EDITID']; ?>') ">Delete</a>
						
						<? } ?>
						
						</span>
						
                        
                       </td>
														
					</tr>
				 
                            
							
							<?php $i++; $c++;
							} 
							}?>
							
							
							
						</table>
				 
				 		<?php echo $recordsA['links'];?>			
	         
	  <br />
			  
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>







	
    <script>
	
	 function searchText()
	 {
	 
	   
 var slNoV= os.getVal('slNo'); 
 var datedV= os.getVal('dated'); 
 var caseNoV= os.getVal('caseNo'); 
 var titleV= os.getVal('title'); 
 var deptV= os.getVal('dept'); 
 var tagV= os.getVal('tag'); 
 var hodV= os.getVal('hod'); 
 var clientRepV= os.getVal('clientRep'); 
 var backgroundV= os.getVal('background'); 
 var InstructionV= os.getVal('Instruction'); 
 var aorNoV= os.getVal('aorNo'); 
 var aorCouncelV= os.getVal('aorCouncel'); 
 var councel_1V= os.getVal('councel_1'); 
 var councel_2V= os.getVal('councel_2'); 
 var remarksV= os.getVal('remarks'); 
 var statusV= os.getVal('status'); 
window.location='<?php echo $listPAGEUrl; ?>slNo='+slNoV +'&dated='+datedV +'&caseNo='+caseNoV +'&title='+titleV +'&dept='+deptV +'&tag='+tagV +'&hod='+hodV +'&clientRep='+clientRepV +'&background='+backgroundV +'&Instruction='+InstructionV +'&aorNo='+aorNoV +'&aorCouncel='+aorCouncelV +'&councel_1='+councel_1V +'&councel_2='+councel_2V +'&remarks='+remarksV +'&status='+statusV +'&';
	  
	 }
	function  searchReset()
	{
			
	  window.location='<?php echo $listPAGEUrl; ?>slNo=&dated=&caseNo=&title=&dept=&tag=&hod=&clientRep=&background=&Instruction=&aorNo=&aorCouncel=&councel_1=&councel_2=&remarks=&status=&';	
	   
	
	}
		
	 dateCalander();
	
	</script>
	
    
   
	<? include('bottom.php')?>