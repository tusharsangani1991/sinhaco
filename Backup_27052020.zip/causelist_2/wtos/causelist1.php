<? 
set_time_limit(0);
$okImg=$site['url'].'image/tick.png';
$importImg=$site['url'].'image/import.png';
$excelImg=$site['url'].'image/excel.png';
$defaultDeptCode=$os->userDetails['dept'];
unset($_SESSION['recordD']);




function array_natsort($aryData, $strIndex, $strSortBy, $strSortType=false)
{
    //    if the parameters are invalid
    if (!is_array($aryData) || !$strIndex || !$strSortBy)
        //    return the array
        return $aryData;
       
    //    create our temporary arrays
    $arySort = $aryResult = array();
   
    //    loop through the array
    foreach ($aryData as $aryRow)
        //    set up the value in the array
        $arySort[$aryRow[$strIndex]] = $aryRow[$strSortBy];
       
    //    apply the natural sort
    natsort($arySort);

    //    if the sort type is descending
    if ($strSortType=="desc")
        //    reverse the array
        arsort($arySort);
       
    //    loop through the sorted and original data
    foreach ($arySort as $arySortKey => $arySorted)
        foreach ($aryData as $aryOriginal)
            //    if the key matches
            if ($aryOriginal[$strIndex]==$arySortKey)
                //    add it to the output array
                array_push($aryResult, $aryOriginal);

    //    return the return
    return $aryResult;
}
// echo $defaultDeptCode;
 function multySort($data=NULL,$field=NULL,$order='ASC',$field2=NULL,$order2='ASC')  # custom array multy sort  $this->multySort($cases,'id',$order='ASC');
			{
	
		if(is_array($data) && count($data)>0 && $field!=NULL )
		{
			
			
			foreach ($data as $key => $row) 
			{
				$temp[$key]  = (int)$row[$field];
				$temp2[$key]  = (int)$row[$field2];
			}
			
			
			
			
			if($order=='DESC')
			{
				array_multisort($temp, SORT_DESC, $data);
			}
			else
			{
				array_multisort($temp, SORT_ASC,$temp2, SORT_ASC, $data);
			}
			
			
			return $data;
			
			}
		return $data;
	
	}
function getInnerContent($startkey,$endKey,$str)
{
   $rs='NO RESULTS';
   $ex='(.*?)';
  echo  $rex ="/$startkey $ex $endKey/";
   
      if(preg_match_all($rex , $str, $matches))
  {
   if($matches[0]!='')
   {
     unset($matches[0]);
   }
   $rs= $matches;
  }
 
   
   
   return $rs;

}
function getFile($link)
{
	if($link=='')
	{
	  echo 'Missing Link';
	  exit();
	
		/*$filename = "sample.html";
		$handle = fopen($filename, "rb");
		$contents = fread($handle, filesize($filename));
		fclose($handle);*/
	}else
	{
		$contents = file_get_contents($link);
		
	}
	if($contents!='')
	{
		$fString=strip_tags($contents);
		return $fString;
	}
}


if(count($os->department)!=3)
{
  echo "Department Error";  exit();
}

function checkMonthlyList()
{
 global $os;
  $query="SELECT count(*) c, DATE_FORMAT(dated, '%d-%m-%Y') d FROM monthlylist";
  $cdl=$os->mq($query);
  $cdl=$os->mfa($cdl);
  return $cdl;

}
function checkDailyList()
{
 global $os;
  $query="SELECT count(*) c, DATE_FORMAT(dailydate, '%d-%m-%Y') d FROM dailylist";
  $cdl=$os->mq($query);
  $cdl=$os->mfa($cdl);
  return $cdl;

}

function totalCaseData()
{
	global $os;
	$query="SELECT count(*) c , dept FROM cases group by dept";
	$cdl=$os->mq($query);
	while( $cn=$os->mfa($cdl))
	{
	$tdata[$cn['dept']]=$cn['c'];
	
	}
	return $tdata;

}
function getItemsNo($val)
{   
      $finalItems=array();
	  
	// ITEM NOS. 1485 - 1508 OF THE MONTHLY LIST.
      preg_match_all("/ITEM .*?MONTHLY LIST/", str_replace("\n",',',$val), $monthlyMatches);
	 
	
	  
	  if(is_array($monthlyMatches[0]))
	  {
	  
	    foreach($monthlyMatches[0] as $cc=>$items)
		{
		
		  if($items!='')
		  {
				
				
				
	  
				
				
				
				$items=str_replace("\n",',',$items);
				$replaceBlank=array('MONTHLY LIST','FROM THE ','OF THE','COMBINED','ITEM', 'NOS.','NO.','.');
				$itemStr=str_replace( $replaceBlank,'', $items);  
				
				 
				
				
				$itemStr=str_replace( array('AND','TO'),array(',','-'), $itemStr); // general format
		  	// _d($itemStr); #5656
				
				 
				
				$itemStrA=preg_match_all('/[0-9]+.?-.?[0-9]+/',$itemStr,$itemRange);
				
			
			//	$itemStr=str_replace( $itemRange[0],'', $itemStr); // general format
				
				
		  // _d($itemRange);
		   #---------------$itemRange extract ----------------
		   
		   
				
	
		   foreach($itemRange[0] as $itemRangeStr)
		   {
		   
		  
		   
		   
		    $itemRangeStrA=explode('-',$itemRangeStr);
			
			
			
		    $itemRangeA=range($itemRangeStrA[0],$itemRangeStrA[1]);
			
			
		    foreach($itemRangeA as $v)
			{
			 $finalItems[]= $v;
			} 
			 
		
		   }
		   
		  
		  
		   
		   $itemStr=str_replace(' ',',',$itemStr);
		   $itemStrA=preg_match_all('/[0-9]+/',$itemStr,$itemSingles);
		    foreach($itemSingles[0] as $v)
			{
			 $finalItems[]= $v;
			} 
		   
		 
		   
		   
		 }
		 }
		 
		// _d($items);
	   // _d($finalItems);
	  
	  }
	 
	  return $finalItems;
	 

}

 function extractCaseVal($caseString)
 {
 $p=$caseString;
 
 
   $case=array();
    //preg_match_all("/[A-Z]+\s\d+\/\d+\s/", $caseString, $matches);//.*? GA 705A/2015 APO 102A/2015  WP 1205A/2014  //    WP.CT 401/2013     aug 2015
	
//	preg_match_all("/[A-Z]+\s\d+\/\d+\s|[A-Z]+\s\d+[A-Z]+\/\d+\s/", $caseString, $matches);
   preg_match_all("/[A-Z]+\s\d+\/\d+\s|[A-Z]+\s\d+[A-Z]+\/\d+\s|[A-Z]+\.[A-Z]+\s\d+\/\d+\s/", $caseString, $matches); // WP.CT 401/2013     aug 2015
	//preg_match_all("/[A-Z]+\.[A-Z]+\s\d+\/\d+\s/", $caseString, $matches);  // WP.CT 401/2013     aug 2015
	 
						  
	
	 
	if(is_array($matches[0]))
	{
	     $case['CASE NO']=implode("\n",$matches[0]);
		 
	     $caseString=str_replace($matches[0],'',$caseString);
	
	}
	  $lines=explode("\n",$caseString);
	  
	  
	//   if(strpos($p,'136/2015'))
						//  {_d($lines);}
	  
	  
	if(is_array($lines))
	{
	     
		 $fLA=explode(' Vs',$lines[0]);
		 
		 $causT1=$fLA[0];
		 $pt1=$fLA[1];
		 
		 if($pt1=='')
		 {
					  $fLA=explode(' And',$lines[0]);
					  $causT1=$fLA[0];
					  $pt1=$fLA[1];
		 }
		 
		 
		 
		 
		 if(substr($lines[1],0,2)=='  ')
		 {
		    $causT2=$lines[1];
		 }else
		 {
		   $pt2=$lines[1];
		   $causT2=$lines[2];
		 
		 }
		 
		 
		  #----565-----#
		  // temporary solution while ptnr field contain two column in nic causelist/ permanet sol hint load total list into another fields
			$pt2=str_replace(array('----','****'),'',$lines[3]);
			$pattern = '/\[.*?\]/';
			$pt2= preg_replace($pattern, '', $pt2);
		 #----565-----#

		 
		$case['CAUSE TITLE']=str_replace(array('  ',"\n"),' ',trim("$causT1 Vs $causT2"));
		$case['PTNR']=trim("$pt1 $pt2");
		 
		
	
	}
	
  
  
 return $case;
  
	
	
   
 }

function importDailyList()
{
 
  
	global $os;
	
	$warningList='';## not implemented
	$dailydate=$os->now();
	$modifyDate=$os->now();
	$modifyBy=$os->userDetails['adminId']; 
	$addedDate=$os->now();
	$addedBy=$os->userDetails['adminId'];
	$link=$os->getByFld('caselinks','caselinksId','1','daily');
	
    $caseStr=getFile($link);
    $os->mq('TRUNCATE TABLE dailylist');
   ## search 5555
   $strArr=preg_split("/COURT NO\./", $caseStr,-1);
    
	$insertQueryInitial='INSERT INTO `causelist`.`dailylist` (`dailylistId` ,`itemNo` ,`caseNo` ,`title` ,`advocate` ,`floors` ,`courtNo` ,`monthlyItems` ,`warningList` ,`dailydate` ,`ignorData` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ';
    
	 
   foreach($strArr as $kk=>$val)
   {
        
		$importSQL='';
		$sqlStrArr=array();
		$courtNo =(int)$val; # echo $courtNo.'<br>';
	//	if($courtNo<1)continue;		 
		$floorA = explode("\n",$val);
		$floors =trim($floorA['1']);
		
		 
		 
		
		#-----  monthly data search
		
		
		$monthlyItems= getItemsNo($val); // 2012-01-24  
		
		 
		   
		$monthlyItems=implode(' ,',$monthlyItems);
		
		
		 $cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
	//	_d(count( $cases));
		// _d($cases); 
		 
		#----- monthly data search end 
	 
	    	foreach($cases as $cvK=>$casesVal)
					{
					
					
					
					
					
					$itemNoIndex=$cvK-1;
					
					if($itemNoIndex>=0){
								
					 
					    $itemNo=(int)$cases[$itemNoIndex];
						
						if($itemNo>0)
						{
						
						## debug  9009
					
					
					
					
					
					#debug 9009 
					
					      $cV=extractCaseVal($casesVal);
						  
						  $caseNo=$cV['CASE NO'];
						  $title=$cV['CAUSE TITLE'];
						  
						
						  $advocate=$cV['PTNR'];
						  
						 
						  
						  ## 	$courtNo $floor $itemNo $caseNo $title $advocate $monthlyItems 
						$caseNo=addslashes($caseNo);
						$title=addslashes($title);
						$advocate=addslashes($advocate);
						 
						
						
						## generateSql  666
						 $sqlStrArr[]="(NULL , '$itemNo', '$caseNo', '$title', '$advocate', '$floors', '$courtNo', '$monthlyItems', '$warningList', '$dailydate', '0', '$addedBy', '$addedDate', '$modifyDate','$modifyBy') ";
						  
						 
								if(count($sqlStrArr)>10){   ##insert at a time 
									## import to table  888
									$importSQL = implode(',',$sqlStrArr); 
									
								   
									
									if($importSQL!=''){	
											$importSQL= $insertQueryInitial. $importSQL .";";
											
											//if(strpos($importSQL,'1492')){   echo $importSQL; exit(); }
											
											if( $os->mq($importSQL ))
											{
											
												 
											$sqlStrArr=array();
											}else{
										
											
												
											
											     //  echo 	$importSQL;										 
											 
											}
											
									
									}
									## import to table  888
								
								}
						 
						 
						 
						  ## generateSql   666
						
						}
						
						
						
					   
					
					
					}
					} 
					//if(strpos($importSQL,'CP 250/2015')){ echo count($sqlStrArr); echo $importSQL;}
					 
					## import to table  888
					
					
				 
				if(count($sqlStrArr)>0){
					$importSQL = implode(',',$sqlStrArr);
					
				if($importSQL!=''){
				
				
				
				$importSQL=$insertQueryInitial . $importSQL .";";
				if( $os->mq($importSQL )){
				
				 
				
				$sqlStrArr=array();
				}else{
					
				//echo count($sqlStrArr);
			//	 echo  " $caseNo ";
				}
				
				
				}}
				     ## import to table  888
   
   }
   
   ## search 5555
   
  // 
 
}
function importMonthlyList()
{
   
 
  
	global $os;
	
	$warningList='';## not implemented
	$dailydate=$os->now();
	$modifyDate=$os->now();
	$modifyBy=$os->userDetails['adminId']; 
	$addedDate=$os->now();
	$addedBy=$os->userDetails['adminId'];
	$link=$os->getByFld('caselinks','caselinksId','1','monthly');
	$insertQueryInitial='INSERT INTO `causelist`.`monthlylist` (`monthlylistId` ,`itemNo` ,`caseNo` ,`title` ,`advocate` ,`floors` ,`courtNo` ,`monthlyItems` ,`warningList` ,`dated` ,`ignorData` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ';
    $caseStr=getFile($link);
    $os->mq('TRUNCATE TABLE monthlylist');
   ## search 5555
   $strArr=preg_split("/COURT NO\./", $caseStr,-1);
   
   
   foreach($strArr as $kk=>$val)
   {
        $importSQL='';
		$sqlStrArr=array();
		$courtNo =(int)$val; # echo $courtNo.'<br>';
	//	if($courtNo<1)continue;		 
		$floorA = explode("\n",$val);
		$floors =trim($floorA['1']);
		
		 
		 
		
		#-----  monthly data search
		
		// $monthlyItems= getItemsNo($val); // 2012-01-24    not need in monthly lists
		// $monthlyItems=implode(' ,',$monthlyItems);
		
		 $cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
		
		//_d($cases); 
		 
		#----- monthly data search end 
	 
	    	foreach($cases as $cvK=>$casesVal)
					{
					$itemNoIndex=$cvK-1;
					
					if($itemNoIndex>=0){
								
					 
					    $itemNo=(int)$cases[$itemNoIndex];
						
						if($itemNo>0)
						{
					      $cV=extractCaseVal($casesVal);
						  
						  $caseNo=$cV['CASE NO'];
						  $title=$cV['CAUSE TITLE'];
						  $advocate=$cV['PTNR'];
						  
						  ## 	$courtNo $floor $itemNo $caseNo $title $advocate $monthlyItems 
						$caseNo=addslashes($caseNo);
						$title=addslashes($title);
						$advocate=addslashes($advocate);
						 
						
						
						## generateSql  666
						 $sqlStrArr[]="(NULL , '$itemNo', '$caseNo', '$title', '$advocate', '$floors', '$courtNo', '$monthlyItems', '$warningList', '$dailydate', '0', '$addedBy', '$addedDate', '$modifyDate','$modifyBy') ";
						
						 if(count($sqlStrArr)==50){   ##insert at a time 
						 
						 
						 ## import to table  888
					 
							$importSQL = implode(',',$sqlStrArr);
							
							if($importSQL!=''){
							$importSQL=$insertQueryInitial . $importSQL .";";
							$os->mq($importSQL );
							}
							$sqlStrArr=array();
							
						 }
						
						
						## generateSql   666
						
						}
						
					
					
					
					}
					} 
				
					 
					## import to table  888
					if(count($sqlStrArr)>0){
					$importSQL = implode(',',$sqlStrArr);
					
				if($importSQL!=''){
				$importSQL=$insertQueryInitial . $importSQL .";";
				$os->mq($importSQL );
				}}
				     ## import to table  888
   
   }
   
   ## search 5555
   
  // 
 

 
}


function getMonthlyListByItem($itemList,$courtNo,$searchKeyStr, $caseRecord)  //  get monthlylist by search keystring ( maybe kword or excel caseNo)
{
 
  global $os;
  
 

 if(trim($searchKeyStr)!=''){
  
	// $query="SELECT * FROM monthlylist  where caseNo!='' and $searchKeyStr  and courtNo='$courtNo' and itemNo IN ($itemList) ";
	// $query="SELECT * FROM monthlylist  where caseNo!='' and $searchKeyStr  and courtNo='$courtNo'";
	$query="SELECT * FROM monthlylist  where caseNo!='' and $searchKeyStr ";  //  
	 
	 
   $queryRs=$os->mq($query);
    while($record=$os->mfa($queryRs))
	 {
	 
	 
	   $record['itemNo']=$record['itemNo'].'M';
	   
	   if(is_array($caseRecord))
	   {
	       // $record['caseNo']=$caseRecord['caseNo'];
			$record['hod']=$caseRecord['hod'];
			$record['clientRep']=$caseRecord['clientRep'];
			$record['background']=$caseRecord['background'];
			$record['Instruction']=$caseRecord['Instruction'];
			$record['aorCouncel']=$caseRecord['aorCouncel'];
			$record['councel_1']=$caseRecord['councel_1'];
			$record['councel_2']=$caseRecord['councel_2'];
			$record['remarks']=$caseRecord['remarks'];
		 
		 
		  
	   
	   }
	   
	   
	   
	   $monthlyKey=$record['monthlylistId'].'M';  // set key to identify monthly list and not over written by other;
	   $os->monthlyList[$monthlyKey]=$record;
	 
	 }
	
 

  } 
 
}


function filterMonthlyList($monthlyList)
{
 //return array();
// return $monthlyList;  ///  temporary solution // need to rectify jojo/
// filter monthly list, allowed only listed monthly item in daily list

    

    global $os;
	$itemA=array();
	$filteredMonthlyItem=array();
	 
	$queryD="SELECT distinct(monthlyItems) ,courtNo FROM dailylist group by courtNo ";
	$queryRsD=$os->mq($queryD);
	while($recordD=$os->mfa($queryRsD))
	{
	
	  
			$courtNo=$recordD['courtNo'];
			if(trim($recordD['monthlyItems'])!='')
			{
			 // echo $recordD['monthlyItems']; 
			 
			      $recordD['monthlyItems']=substr($recordD['monthlyItems'],0,50000);  // large no of data // php is unable to load// so trancate to 50k
				    
					$itemsA=explode(',',$recordD['monthlyItems']);
				 
					foreach($itemsA as $itemNo)
					{
				 
					
						$itemKey=trim($courtNo).'-'.trim($itemNo).'M';
						$itemA[$itemKey]=$itemKey;
					}
			
			}
 

	}
	 
 

if(is_array($monthlyList) && count($monthlyList)>0)
{
                   foreach($monthlyList as $record)
					{
						$itemKey=trim($record['courtNo']).'-'.trim($record['itemNo']);
						
						 
						if(in_array($itemKey,$itemA))
						{
						
						$filteredMonthlyItem[]=$record;
						}
						
					}


}

 
 
return $filteredMonthlyItem;
}
function filterCasesByCaseNo($searchedCases,$dept)
{
// filter searchedcase list  by  only listed in excel case list
    global $os;
	$itemA=array();
	$filteredItem=array();
	$query="SELECT caseNo FROM cases  where caseNo!='' and dept='$dept' ";
	$queryRs=$os->mq($query);
	while($caseRecord=$os->mfa($queryRs))
	{
		 $caseA=explode("\n",$caseRecord['caseNo']);
		 foreach($caseA as $kk=>$singleCase)  ## remove empty value
		 {
		   if(trim($singleCase)!='') 
		   {  
		       $itemA[]=trim($singleCase);
					 
			}
		 }
		 
		
		
		
		
	}
		
// _d(count( $itemA));


if(is_array($searchedCases) && count($searchedCases)>0)
{
                   foreach($searchedCases as $record)
					{
					    $matches=0;
					    $caseA=explode("\n",$record['caseNo']);
						
					    foreach($caseA as $kk=>$singleCase)  ## remove empty value
						 {
						   $trimedsingleCase=trim($singleCase);
						   if($trimedsingleCase!='') 
						   { 
						 //   _d($trimedsingleCase);
						     if(in_array($trimedsingleCase,$itemA)){ $matches++; 
							      //_d(  $matches);
							 }
							 
						 
						   }
						   
						   
						 }
					
					  if($matches>0)
					  {
					    $filteredItem[]= $record;
					  
					  }
					
						 
						 
						
					}


}


 
return $filteredItem;
}

function searchByKeyRecord($key)
{
        global $os;
		$os->monthlyList=array();
		$searchByKeyA=array();
		$key =str_replace('*AND*','&',$key);
		$keyA=explode(',',$key);
		 
		
		foreach($keyA as $k)
		{
		$keyStrATitle[]="title LIKE '%$k%'";
		$keyStrAAdvocate[]="advocate LIKE '%$k%'";
		$keyStrACase[]="caseNo LIKE '%$k%'";  
		}
		
		$keyStrTitle=implode(' OR ',$keyStrATitle);
		$keyStrAdvocate=implode(' OR ',$keyStrAAdvocate);
		$keyStrCase=implode(' OR ',$keyStrACase);
		
   
			$searchKeyStr="( $keyStrTitle OR  $keyStrAdvocate  OR  $keyStrCase)";
			$query="SELECT * FROM dailylist  where caseNo!='' and $searchKeyStr";
			$queryRs=$os->mq($query);
			//echo $query;
			 while($record=$os->mfa($queryRs))
             {
			 
			 
			  $searchByKeyA[]=$record;
			  
			 }
			 
			  getMonthlyListByItem($record['monthlyItems'],$record['courtNo'],$searchKeyStr);   // generate monthly list
			 ###-- search monthly-items 345
				
					 
			 
				
			 
			 #- 345 ------------
return $searchByKeyA;
}

function searchByKey($key)
{
		global $os;
		$os->monthlyList=array();
		$searchByKeyA=array();
		$downloadKey='searchByKey';
				
		$searchByKeyA=searchByKeyRecord($key);
		
		  
	 	$os->monthlyList=filterMonthlyList($os->monthlyList);		
	 
				
				if(count($os->monthlyList)>0)
				{
				foreach($os->monthlyList as $record)
				{
				
				  $searchByKeyA[]= $record;
				
				}
				
				}
				
				if(is_array($searchByKeyA) && count($searchByKeyA)>0){
			 	$searchByKeyA= multySort($searchByKeyA,'courtNo','ASC','itemNo','ASC'); // jojo create problem
				}
				
				
				$_SESSION['downloadSearchData'][$downloadKey]=$searchByKeyA;
				
				$totalRec=count( $searchByKeyA);
				$key =str_replace('*AND*','&',$key);
 
   
  ?>
  <div style="width:100%; height:10px; padding-top:2px;">
  <div style="width:800px; float:left;">Search By kewords <? echo $key ?>  Total Record <? echo $totalRec; ?></b> </div><div style="width:100px; float:right;"> &nbsp; <a class="tlinkCss refresh" href="downloadSearchData.php?downloadKey=<? echo $downloadKey ?>"   style="text-decoration:none"> Download </a> &nbsp;</div>
  </div>
  <div style="clear:both; height:1px">&nbsp; </div>
  <br />
  <table border="1" cellpadding="1">
  <tr>
  <td><b>Item No.</b></td>
  <td><b>Case No </b></td>
  <td><b>Title</b></td>
  <td><b>PTNR</b></td>
  <td><b>Court No</b></td>
  
  </tr>
  
  <? 
  
 foreach($searchByKeyA as $record)
 {
 

 
 ?>
 <tr>
 <td ><? echo $record['itemNo'] ?></td>
 <td width="120"><? echo nl2br($record['caseNo']); ?></td>
 <td><? echo $record['title'] ?></td>
  <td><? echo $record['advocate'] ?></td>
  <td><? echo $record['courtNo'] ?></td>
  
  </tr>
   
 <?
  
  
 

	 
 }
 
 
  
?>




</table> <?


}

function searchByCaseNoRecord($dept)
{
  global $os;
  
		$searchByCaseNoA=array();
		$os->monthlyList=array();
		$singleCaseA=array();
		$query="SELECT * FROM cases  where caseNo!='' and dept='$dept' ";
		
		
		
		$queryRs=$os->mq($query);
		while($caseRecord=$os->mfa($queryRs))
		{
		 $caseA=explode("\n",$caseRecord['caseNo']);
		 foreach($caseA as $kk=>$singleCase)  ## remove empty value
		 {if(trim($singleCase)=='')  {  
		  unset ($caseA[$kk]);
					 
			}else{
			$singleCase=trim($singleCase);
			 // $singleCaseA[]=trim($singleCase); not need
			 
			 ##  --- search start777
			 
			   // 777 $caseStr = implode('|',$caseA);
			  // 777	$searchKeyStr=" caseNo RLIKE '$caseStr' ";
			 // if(strpos($singleCase,'AP 224/2009')!==false){ echo $dailyQuery; exit();}  for debug help
			  
			    
				$searchKeyStr=" caseNo LIKE '%$singleCase%' ";
			
				
				$dailyQuery="select itemNo,courtNo,title,advocate,caseNo from dailylist where $searchKeyStr ";
					
				$dailyRs=$os->mq($dailyQuery );
				while($dailyRec=$os->mfa($dailyRs )){
								
					if(is_array($caseRecord))
					{
					
				 
					$dailyRec['hod']=$caseRecord['hod'];
					$dailyRec['clientRep']=$caseRecord['clientRep'];
					$dailyRec['background']=$caseRecord['background'];
					$dailyRec['Instruction']=$caseRecord['Instruction'];
					$dailyRec['aorCouncel']=$caseRecord['aorCouncel'];
					$dailyRec['councel_1']=$caseRecord['councel_1'];
					$dailyRec['councel_2']=$caseRecord['councel_2'];
					$dailyRec['remarks']=$caseRecord['remarks'];
											
					}
				    $searchByCaseNoA[]=$dailyRec;
				}
				
				
				
				
				getMonthlyListByItem($dailyRec['monthlyItems'],$dailyRec['courtNo'],$searchKeyStr,$caseRecord);
				
				
				$singleCaseA=array();
			 
		 
			 
			 ##  777
			 
			 
			 
			 
			 
			}
		 }
		 
		 if(count($caseA)>0)
		 { #777 code
		 
		    ##/ to place code 777 can be optimized
		 }
		
		
		
		}
		
return $searchByCaseNoA;

}



function searchByCaseNo($dept) 
{
  global $os;
  
 // echo $dept;  //  need to implement search by department
 
         $searchByCaseNoA=array();
		 $os->monthlyList=array();
		 $downloadKey='searchByCaseNo';
		 
		
		 
		$searchByCaseNoA=searchByCaseNoRecord($dept); // search andgenerate monthly list internal process
		
		 
		
		
		$os->monthlyList=filterMonthlyList($os->monthlyList);
		
		if(count($os->monthlyList)>0)
		{
		foreach($os->monthlyList as $record)
		{
		
		//_d($record);
		
		
		if(is_array($record)){
		  $searchByCaseNoA[]= $record;
		  }
		
		}
		
		}
		 
		
		 
	
	$searchByCaseNoA=filterCasesByCaseNo($searchByCaseNoA,$dept);  // filter by excel case
	//_d( $searchByCaseNoA);
	if(is_array($searchByCaseNoA) && count($searchByCaseNoA)>0){
	$searchByCaseNoA= multySort($searchByCaseNoA,'courtNo','ASC','itemNo','ASC');
		}
		$_SESSION['downloadSearchData'][$downloadKey]=$searchByCaseNoA;
	
		
			?>
			<div style="width:100%; height:10px; padding-top:2px;">
			<div style="width:800px; float:left;">Search By Case NO   Total Record: <? echo count($searchByCaseNoA); ?>  </div><div style="width:100px; float:right;"> &nbsp; <a class="tlinkCss refresh" href="downloadSearchData.php?downloadKey=<? echo $downloadKey ?>&dept=<? echo $dept; ?>"   style="text-decoration:none"> Download </a> &nbsp;</div>
			</div>
			<br />
			<style>
  .combine { border: 1px solid #cccccc;}
  .combine td { border-bottom: 1px solid #cccccc;  word-wrap: break-word;
  
    border-left: 1px solid #bebebe;
    border-top: 1px solid #ffffff;}
	.combine tr:hover { background-color:#E6F7FF;}
  
    
  </style>
			<table class="combine"   cellpadding="1" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;">
			<tr>
							
            	    	   
             
			 
			<td><b>ITEM NO.</b></td>
			<td width="120"><b>CASE NO </b></td>
			<td><b>CAUSE TITLE</b></td>
			<td><b>COURT</b></td>
			 
			<? if($dept=='Dept. 1' || $dept=='Dept. 2' ){ ?>
		 
			<td><b>HOD	</b></td>
			<td><b>CLIENT REP.</b></td>
			<td><b>BACKGROUND</b></td>
			<td><b>INSTRUCTION</b></td>
						
			
			
			<? } ?>
			<? if($dept=='Dept. 3'){ ?>
		 
						
			 
			<td><b>AOR/COUNSEL</b></td>
			<td><b>COUNSEL - 1</b></td>
			<td><b>COUNSEL - 2</b></td>
			
			<? } ?>
			
			<td><b>LAWYER</b></td>
			<td><b>COUNSEL 	</b></td>
			<td><b>SL NO.</b></td>
			</tr>
			
			<? 
		
		$normalSlNo=1;
		
		foreach( $searchByCaseNoA as $record)
		{
		 
		
		
				
			?>
			<tr>
			<td><? echo $record['itemNo'] ?></td>
			<td><? echo nl2br($record['caseNo']) ?></td>
			<td><? echo $record['title'] ?></td>
			<td><? echo $record['courtNo'] ?></td>
			
			<? if($dept=='Dept. 1' || $dept=='Dept. 2' ){ ?>
		    <td><? echo $record['hod'] ?></td>
			<td><? echo $record['clientRep'] ?></td>
			<td><? echo nl2br($record['background']) ?></td>
			<td><? echo nl2br($record['Instruction']) ?></td>
					
			
			<? } ?>
			<? if($dept=='Dept. 3'){ ?>
		 
						
			 <td><? echo $record['aorCouncel'] ?></td>
			 <td><? echo $record['councel_1'] ?></td>
			 <td><? echo $record['councel_2'] ?></td>
			
			
			<? } ?>
			<td><? echo $record['advocate'] ?></td>
			<td><? echo $record['remarks'] ?></td>
			<td><? echo $normalSlNo ?></td>
			
			</tr>
			
			
			
			<?
		 
		$normalSlNo++;
		 
		 
		 
		
		}
		 
		
		
  
		?></table> <?	   
 
 
}
function getDailyDate()
{ global $os;
            $query="SELECT dailydate FROM dailylist  limit 1 ";
			$queryRs=$os->mq($query);
			
			 $record=$os->mfa($queryRs);
			 //_d($record);
			 $d=$record['dailydate']; 
			$d= $os->showDate($d); 
			return $d;

}

function searchCombine($key,$dept,$orderBy) // by case no by keywords
{

		global $os;
		 
		
		// search by key 555
		$downloadKey='searchCombine';
		$os->monthlyList=array();
		$searchByKeyA=array();
		
		//echo $orderBy;
		//exit();
		
		$searchByKeyA=searchByKeyRecord($key);
		
		
		$os->monthlyList=filterMonthlyList($os->monthlyList);
		if(count($os->monthlyList)>0)
		{
		foreach($os->monthlyList as $record)
		{
				
			  $searchByKeyA[]= $record;
		}
				
		}
		
	
				// search by key 555
			// Search By  caseno 777
			$searchByCaseNoA=array();
			
			$searchByCaseNoA=searchByCaseNoRecord($dept); // search and generate monthly list
			 
			$os->monthlyList=filterMonthlyList($os->monthlyList);
					
			if(count($os->monthlyList)>0)
			{
			foreach($os->monthlyList as $record)
			{
			if(is_array($record)){
			$searchByCaseNoA[]= $record;
			}
			
			}
			
			}
			
		//  t5t
			$searchByCaseNoA=filterCasesByCaseNo($searchByCaseNoA,$dept);  // filter by excel case
			
		//	search by case no 777	
		
		$indexforNat=1;
		// remove duplicate and merge two results  888
			$searchCombineData=array();
		//	_d($searchByKeyA); ##222
			if(count($searchByKeyA)>0)
			{
				foreach($searchByKeyA as $record)
				{
				  // if(!isset($record['hod'])){ $record['hod']='test';}
				
					$key=$record['courtNo'].'_'.$record['itemNo'];
					$searchCombineData[$key]=$record;
				
					$searchCombineData[$key]['natIndex']=$indexforNat;
					$indexforNat++;
					
					
				}
					
			
			}
			
			
			
			
			
			if(count($searchByCaseNoA)>0)
			{
				foreach($searchByCaseNoA as $record)
				{
				// if(!isset($record['hod'])){ $record['hod']='pest';}
				
					$key=$record['courtNo'].'_'.$record['itemNo'];
					$searchCombineData[$key]=$record;
					$searchCombineData[$key]['natIndex']=$indexforNat;
					$indexforNat++;
				}
			
			}
			
			if(is_array($searchCombineData) && count($searchCombineData)>0){
		
		  if($orderBy!='') 
		  {
	  echo $orderBy .'active';
		$orderBy='hod';
		 // _d($searchCombineData);
	//	 _d($searchCombineData);
		 $searchCombineData=array_natsort($searchCombineData, 'natIndex', 'hod', 'asc');
		  // $searchCombineData= multySort($searchCombineData,$orderBy,'DASC');
		  
		  } 
		  else
		  {
		   $searchCombineData= multySort($searchCombineData,'courtNo','ASC','itemNo','ASC');
		  
		  }
		  
		  }
		// remove duplicate and merge two results  888
		
		
		
				$_SESSION['downloadSearchData'][$downloadKey]=$searchCombineData;
				
				$totalRec=count( $searchCombineData);
 
   
  ?>
  <div style="width:100%; height:10px; padding-top:2px;">
  <div style="width:800px; float:left;">Combine Data   Total Record <? echo $totalRec; ?></b> </div>
  <div style="width:300px; float:right;"> 
  
    
    &nbsp; <a class="tlinkCss refresh" href="javascript:void(0)" onclick="printById('PrintArea')"   style="text-decoration:none">Print </a> &nbsp;
   
  
    
    
   <!--<a class="tlinkCss refresh" href="downloadSearchData.php?downloadKey=<? echo $downloadKey ?>&dept=<? echo $dept; ?>&orderby=hod"   style="text-decoration:none"> Download 
  by HOD</a> -->&nbsp;
   &nbsp; <a class="tlinkCss refresh" href="downloadSearchData.php?downloadKey=<? echo $downloadKey ?>&dept=<? echo $dept; ?>"   style="text-decoration:none"> Download </a> &nbsp;
 

  <!-- &nbsp; <a class="tlinkCss refresh" href="javascript:void(0)" onclick="printById('PrintArea')"   style="text-decoration:none">Send SMS </a> &nbsp;
  --> 

   <a class="tlinkCss refresh" href="javascript:void(0)" onclick="popUpWindow('message.php?key=all_<?echo $dept;?>', 50, 50, 950, 620)">Send SMS</a>

   
   
   
   
   
 </div>
  </div>
  <div style="clear:both; height:1px">&nbsp; </div>
  <br />
  <div id="PrintArea">
 <div style="text-align:center; font-size:10px;"> 
 <? if($dept=='Dept. 3'){?> AOR CAUSELIST <? }else{ ?> SINHA & CO. CAUSELIST <? } ?>
 
  Date:<? echo getDailyDate(); ?> </div>
  <style>
  .combine { border: 1px solid #cccccc;}
  .combine td { border-bottom: 1px solid #cccccc;  word-wrap: break-word;
  
    border-left: 1px solid #bebebe;
    border-top: 1px solid #ffffff;}
	.combine tr:hover { background-color:#E6F7FF;}
  
    
  </style>
  <table class="combine"    cellpadding="1" cellspacing="0" style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:9px;">
			<tr>
							
            	    	   
             
			 
			<td><b>ITEM NO.</b></td>
			<td style="width:87px;"><b>CASE NO </b></td>
			<td style="width:250px;"><b>CAUSE TITLE</b></td>
			<td><b>COURT</b></td>
			 
			<? if($dept=='Dept. 1' || $dept=='Dept. 2' ){ ?>
		 
			<td style="width:83px;"><b>HOD	</b></td>
			<td style="width:83px;"><b>CLIENT REP.</b></td>
			<td style="width:200px;"><b>BACKGROUND</b></td>
			<td style="width:150px;"><b>INSTRUCTION</b></td>
						
			
			
			<? } ?>
			<? if($dept=='Dept. 3'){ ?>
		 
						
			 
			<td><b>AOR/COUNSEL</b></td>
			<td style="width:83px;"><b>COUNSEL - 1</b></td>
			<td style="width:83px;"><b>COUNSEL - 2</b></td>
			
			<? } ?>
			
			<td style="width:73px;"><b>LAWYER</b></td>
			<td style="width:83px;"><b>COUNSEL	</b></td>
			<td><b>SL NO.</b></td>
			</tr>
			
			<? 
		
		$normalSlNo=1;
		
		foreach( $searchCombineData as $record)
		{
		 
		
		
				
			?>
			<tr>
			<td><? echo $record['itemNo'] ?></td>
			<td><? echo nl2br($record['caseNo']) ?></td>
			<td><? echo $record['title'] ?></td>
			<td><? echo $record['courtNo'] ?></td>
			
			<? if($dept=='Dept. 1' || $dept=='Dept. 2' ){ ?>
		    <td><? echo $record['hod'] ?></td>
			<td><? echo $record['clientRep'] ?></td>
			<td><? echo nl2br($record['background']) ?></td>
			<td><? echo nl2br($record['Instruction']) ?></td>
					
			
			<? } ?>
			<? if($dept=='Dept. 3'){ ?>
		 
						
			 <td><? echo $record['aorCouncel'] ?></td>
			 <td><? echo $record['councel_1'] ?></td>
			 <td><? echo $record['councel_2'] ?></td>
			
			
			<? } ?>
			<td><? echo $record['advocate'] ?></td>
			<td><? echo $record['remarks'] ?></td>
			<td><? echo $normalSlNo ?></td>
			
			</tr>
			
			
			
			<?
		 
		$normalSlNo++;
		 
		 
		 
		
		}
		 
		
		
  
		?></table> 
		
	</div>	
		
		<?







}

function searchByCaseNo_NotInUse($dept) ## search Faster
{
  global $os;
  
 // echo $dept;  //  need to implement search by department
 
  $singleCaseA=array();
  $dailylistIdStrA=array();
		$query="SELECT caseNo FROM cases  where caseNo!='' and dept='$dept' ";
		
		$queryRs=$os->mq($query);
		while($record=$os->mfa($queryRs))
		{
		 
		 $caseA=explode("\n",$record['caseNo']);
		 foreach($caseA as $singleCase)
		 {
		 
		   if( $singleCase!='')
		   {
		   
		    $singleCaseA[]=$singleCase;
		   
		   }
		   
	 
		   if(count($singleCaseA)>20)
		   {
		 
		       #------------444
			               $caseStr = implode('|',$singleCaseA);
						   $dailyQuery="select GROUP_CONCAT(dailylistId) dl from dailylist where caseNo RLIKE '$caseStr'";
						   //echo $dailyQuery."<br>";
						   $dailyRs=$os->mq($dailyQuery );
						   $dailyRrc=$os->mfa($dailyRs );
						   if($dailyRrc['dl']!=''){
						   $dailylistIdStrA[]= $dailyRrc['dl'];
						   }
						   $singleCaseA=array();
			   
			   #------------444
		   
		   }
		   
		 
		 }
		
		
		
		}
		
   #------------444
   
			               $caseStr = implode('|',$singleCaseA);
						   $dailyQuery="select GROUP_CONCAT(dailylistId) dl from dailylist where caseNo RLIKE '$caseStr'";
						   // echo $dailyQuery."<br>";
						   $dailyRs=$os->mq($dailyQuery );
						   $dailyRrc=$os->mfa($dailyRs );
						   if($dailyRrc['dl']!=''){
						   $dailylistIdStrA[]= $dailyRrc['dl'];
						   }
						   $singleCaseA=array();
			   
			   #------------444
			   
			   
  

  
  
  if(count($dailylistIdStrA)>0)
  {
    $dailylistIdStr = implode(',',$dailylistIdStrA);

  }
  
   if($dailylistIdStr!=''){
  
   $query="SELECT * FROM dailylist  where dailylistId IN($dailylistIdStr)";
   
   $queryRs=$os->mq($query);
   $recCount=mysql_num_rows($queryRs);
   $downloadKey='searchByCaseNo';
   $_SESSION['downloadSearchData'][$downloadKey]=$query;
  
   
  ?>
  <div style="width:100%; height:10px; padding-top:2px;">
  <div style="width:800px; float:left;">Total Number Of Records <b><? echo  $recCount  ?></b> </div><div style="width:100px; float:right;"> &nbsp; <a class="tlinkCss refresh" href="downloadSearchData.php?downloadKey=<? echo $downloadKey ?>"   style="text-decoration:none"> Download </a> &nbsp;</div>
  </div>
  <br />
  <table border="1" cellpadding="1">
  <tr>
  
  <td  width="120"><b>Case No </b></td>
  <td><b>Title</b></td>
  <td><b>PTNR</b></td>
  <td><b>Court No</b></td>
  
  </tr>
  
  <? 
  
  while($record=$os->mfa($queryRs))
 {
 
 ?>
 <tr>
 
 <td><? echo nl2br($record['caseNo']) ?></td>
 <td><? echo $record['title'] ?></td>
  <td><? echo $record['advocate'] ?></td>
  <td><? echo $record['courtNo'] ?></td>
  
  </tr>
  
 
 
 <?
 
 
	 
 }
  
?></table> <?

}else{ echo 'No Data Found';}
}



function extractCaseValPDFText($caseString)
 {
 $p=$caseString;

   $case=array();
    //preg_match_all("/[A-Z]+\s\d+\/\d+\s/", $caseString, $matches);//.*? GA 705A/2015 APO 102A/2015  WP 1205A/2014 //    WP.CT 401/2013     aug 2015
	//preg_match_all("/[A-Z]+\s\d+\/\d+\s|[A-Z]+\s\d+[A-Z]+\/\d+\s/", $caseString, $matches);
    preg_match_all("/[A-Z]+\s\d+\/\d+\s|[A-Z]+\s\d+[A-Z]+\/\d+\s|[A-Z]+\.[A-Z]+\s\d+\/\d+\s/", $caseString, $matches); 
	
	 
						  
	
	 
	if(is_array($matches[0]))
	{
	     $case['CASE NO']=implode("\n",$matches[0]);
		 
	     $caseString=str_replace($matches[0],'',$caseString);
	
	}
	  $lines=explode("\n",$caseString);
	  
	  
	//   if(strpos($p,'136/2015'))
						//  {_d($lines);}
	  
	  
	if(is_array($lines))
	{
	     
		 $fLA=explode(' Vs',$lines[0]);
		 
		 $causT1=$fLA[0];
		 $pt1=$fLA[1];
		 
		 if($pt1=='')
		 {
					  $fLA=explode(' And',$lines[0]);
					  $causT1=$fLA[0];
					  $pt1=$fLA[1];
		 }
		 
		 
		 
		  $causT2=$lines[1];
		/* if(substr($lines[1],0,2)=='  ')
		 {
		    $causT2=$lines[1];
		 }else
		 {
		   $pt2=$lines[1];
		   $causT2=$lines[2];
		 
		 }
		 */
		 
		  #----565-----#
		  // temporary solution while ptnr field contain two column in nic causelist/ permanet sol hint load total list into another fields
		//	$pt2=str_replace(array('----','****'),'',$lines[3]);
		//	$pattern = '/\[.*?\]/';
		//	$pt2= preg_replace($pattern, '', $pt2);
		 #----565-----#

		 
		$case['CAUSE TITLE']=str_replace(array('  ',"\n"),' ',trim("$causT1 Vs $causT2"));
		$case['PTNR']=trim("$pt1 $pt2");
		 
		
	
	}
	
  
  
 return $case;
  
	
	
   
 }


function importDailyListPDFText()
{
 
  
	global $os;
	
	$warningList='';## not implemented
	$dailydate=$os->now();
	$modifyDate=$os->now();
	$modifyBy=$os->userDetails['adminId']; 
	$addedDate=$os->now();
	$addedBy=$os->userDetails['adminId'];
	//$link=$os->getByFld('caselinks','caselinksId','1','daily');	
    //$caseStr=getFile($link);
	$caseStr= $os->dailyText;
    $os->mq('TRUNCATE TABLE dailylist');
   ## search 5555
   $strArr=preg_split("/COURT NO\./", $caseStr,-1);
    
	$insertQueryInitial='INSERT INTO `causelist`.`dailylist` (`dailylistId` ,`itemNo` ,`caseNo` ,`title` ,`advocate` ,`floors` ,`courtNo` ,`monthlyItems` ,`warningList` ,`dailydate` ,`ignorData` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ';
    
	 
   foreach($strArr as $kk=>$val)
   {
        
		$importSQL='';
		$sqlStrArr=array();
		$courtNo =(int)$val; # echo $courtNo.'<br>';
	//	if($courtNo<1)continue;		 
		$floorA = explode("\n",$val);
		$floors =trim($floorA['1']);
		
		 
		 
		
		#-----  monthly data search
		
		
		$monthlyItems= getItemsNo($val); // 2012-01-24  
		
		 
		   
		$monthlyItems=implode(' ,',$monthlyItems);
		
		
		 $cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
	//	_d(count( $cases));
		// _d($cases); 
		 
		#----- monthly data search end 
	 
	    	foreach($cases as $cvK=>$casesVal)
					{
					
					
					
					
					
					$itemNoIndex=$cvK-1;
					
					if($itemNoIndex>=0){
								
					 
					    $itemNo=(int)$cases[$itemNoIndex];
						
						if($itemNo>0)
						{
						
						## debug  9009
					
					
					
					
					
					#debug 9009 
					
					      $cV=extractCaseValPDFText($casesVal);
						  
						  $caseNo=$cV['CASE NO'];
						  $title=$cV['CAUSE TITLE'];
						  
						
						  $advocate=$cV['PTNR'];
						  
						 
						  
						  ## 	$courtNo $floor $itemNo $caseNo $title $advocate $monthlyItems 
						$caseNo=addslashes($caseNo);
						$title=addslashes($title);
						$advocate=addslashes($advocate);
						 
						
						
						## generateSql  666
						 $sqlStrArr[]="(NULL , '$itemNo', '$caseNo', '$title', '$advocate', '$floors', '$courtNo', '$monthlyItems', '$warningList', '$dailydate', '0', '$addedBy', '$addedDate', '$modifyDate','$modifyBy') ";
						  
						 
								if(count($sqlStrArr)>10){   ##insert at a time 
									## import to table  888
									$importSQL = implode(',',$sqlStrArr); 
									
								   
									
									if($importSQL!=''){	
											$importSQL= $insertQueryInitial. $importSQL .";";
											
											//if(strpos($importSQL,'1492')){   echo $importSQL; exit(); }
											
											if( $os->mq($importSQL ))
											{
											
												 
											$sqlStrArr=array();
											}else{
										
											
												
											
											     //  echo 	$importSQL;										 
											 
											}
											
									
									}
									## import to table  888
								
								}
						 
						 
						 
						  ## generateSql   666
						
						}
						
						
						
					   
					
					
					}
					} 
					//if(strpos($importSQL,'CP 250/2015')){ echo count($sqlStrArr); echo $importSQL;}
					 
					## import to table  888
					
					
				 
				if(count($sqlStrArr)>0){
					$importSQL = implode(',',$sqlStrArr);
					
				if($importSQL!=''){
				
				
				
				$importSQL=$insertQueryInitial . $importSQL .";";
				if( $os->mq($importSQL )){
				
				 
				
				$sqlStrArr=array();
				}else{
					
				//echo count($sqlStrArr);
			//	 echo  " $caseNo ";
				}
				
				
				}}
				     ## import to table  888
   
   }
   
   ## search 5555
   
  // 
 
}
function importMonthlyListPDFText()
{
   
 
  
	global $os;
	
	$warningList='';## not implemented
	$dailydate=$os->now();
	$modifyDate=$os->now();
	$modifyBy=$os->userDetails['adminId']; 
	$addedDate=$os->now();
	$addedBy=$os->userDetails['adminId'];
	//$link=$os->getByFld('caselinks','caselinksId','1','monthly');
    // $caseStr=getFile($link);
	$caseStr= $os->monthlyText;
	
	
	
	$insertQueryInitial='INSERT INTO `causelist`.`monthlylist` (`monthlylistId` ,`itemNo` ,`caseNo` ,`title` ,`advocate` ,`floors` ,`courtNo` ,`monthlyItems` ,`warningList` ,`dated` ,`ignorData` ,`addedBy` ,`addedDate` ,`modifyDate` ,`modifyBy`)VALUES ';
   
	
	
	
    $os->mq('TRUNCATE TABLE monthlylist');
   ## search 5555
   $strArr=preg_split("/COURT NO\./", $caseStr,-1);
   
   
   foreach($strArr as $kk=>$val)
   {
        $importSQL='';
		$sqlStrArr=array();
		$courtNo =(int)$val; # echo $courtNo.'<br>';
	//	if($courtNo<1)continue;		 
		$floorA = explode("\n",$val);
		$floors =trim($floorA['1']);
		
		 
		 
		
		#-----  monthly data search
		
		// $monthlyItems= getItemsNo($val); // 2012-01-24    not need in monthly lists
		// $monthlyItems=implode(' ,',$monthlyItems);
		
		 $cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
		
		//_d($cases); 
		 
		#----- monthly data search end 
	 
	    	foreach($cases as $cvK=>$casesVal)
					{
					$itemNoIndex=$cvK-1;
					
					if($itemNoIndex>=0){
								
					 
					    $itemNo=(int)$cases[$itemNoIndex];
						
						if($itemNo>0)
						{
					      $cV=extractCaseValPDFText($casesVal);
						  
						  $caseNo=$cV['CASE NO'];
						  $title=$cV['CAUSE TITLE'];
						  $advocate=$cV['PTNR'];
						  
						  ## 	$courtNo $floor $itemNo $caseNo $title $advocate $monthlyItems 
						$caseNo=addslashes($caseNo);
						$title=addslashes($title);
						$advocate=addslashes($advocate);
						 
						
						
						## generateSql  666
						 $sqlStrArr[]="(NULL , '$itemNo', '$caseNo', '$title', '$advocate', '$floors', '$courtNo', '$monthlyItems', '$warningList', '$dailydate', '0', '$addedBy', '$addedDate', '$modifyDate','$modifyBy') ";
						
						 if(count($sqlStrArr)==50){   ##insert at a time 
						 
						 
						 ## import to table  888
					 
							$importSQL = implode(',',$sqlStrArr);
							
							if($importSQL!=''){
							$importSQL=$insertQueryInitial . $importSQL .";";
							$os->mq($importSQL );
							}
							$sqlStrArr=array();
							
						 }
						
						
						## generateSql   666
						
						}
						
					
					
					
					}
					} 
				
					 
					## import to table  888
					if(count($sqlStrArr)>0){
					$importSQL = implode(',',$sqlStrArr);
					
				if($importSQL!=''){
				$importSQL=$insertQueryInitial . $importSQL .";";
				$os->mq($importSQL );
				}}
				     ## import to table  888
   
   }
   
   ## search 5555
   
  // 
 

 
}



 
?>