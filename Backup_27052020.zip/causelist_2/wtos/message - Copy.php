<? 
error_reporting(0);
include('includes/config.php');
include('top.php');
ini_set('max_execution_time', '-1');
ini_set('memory_limit', '2048M'); 
include('sendSms.php');
$contactNo=array();
$remarksData=array();
?>
<?
if($_GET['key']=="all")
{
$k=0;
$searchData =$_SESSION['downloadSearchData']['searchCombine'];
foreach($searchData as $record)
{
	_d($record);
	 if($record['remarks'])
	 {
        preg_match_all('/[0-9]{10}/', $record['remarks'], $matches);
	   
	    $matches = $matches[0][0];
	   $contactNo[$k]=$matches;
	   $k++;
	   }
}
}


$msgEnquery='';
if($_POST['message']=='OK')
{






	
 $msg=$_POST['msgText'];
	if(count($contactNo)>0)
	{
		foreach($contactNo as $mobileNo)
		{
			
			if($mobileNo!='')
			{
			
			//$smsObj= new sms;
			//$smsText= str_ireplace( "#ROLLNO#", $mobleNoData['rollNo'],$msg);
			$smsNumbersStr= $mobileNo;
			//$smsObj->sendSMS($smsText,$smsNumbersStr);
			$os->saveSendingSms($msg,$mobileNos=$smsNumbersStr , $status='send',$note='Send SMS');
			}
		}
		
		
		
		
		  $msgEnquery='<font style="color:#00CC00" > Message sent successfully.</font> ';
							
	}
}





 
?>
  <style>
.btnStyle{ display:none;}
</style>
<div style="width:100%; margin:10px 0px 0px 20px;">
 


 <table>
 <tr>
 <td >
 
 <form method="post" action="">
<input type="hidden" name="message" value="OK" />
 <input type="hidden" name="status" value="Active" />
  <h2  style="font-weight:bold"><? echo $msgEnquery ?></h2>
 
 <b>Message</b></br>
<textarea style="width: 442px; margin: 0px; height: 527px;"  name="msgText" id="msgText" ></textarea>	<br>
	
	<input type="submit" name="button" value="Send"  style="cursor:pointer; color:#009900;margin-left: 8cm;" />
 
  </form>
 
	
 </td>
 <td >
 
	<table class="table_top" style="width:auto">
	<tr style=" background:#eeeeee;">
		<th >
	Message Template List 
		</th>
		
	</tr>
	<tr>
	<td class="scroll" valign="top">
	<div class="scroll_div" style="width:400px;">
	
<table  border="0" cellspacing="0" cellpadding="0" class="noBorder"  >
<tr class="borderTitle" >
<td >#</td>
<td ><b>Available Template</b></td>  
<td ></td>  
</tr>
<?php
$c=0;
$smsQuery="select * from smstemplate where smstemplateId>0  and active='active' order by priority ";
$smsTemMq=$os->mq($smsQuery);  
while($record=$os->mfa( $smsTemMq)){ 
$c++;
?>
<tr class="trListing" >
<td><?php echo $c; ?>     </td>
<td><?php echo $record['smsText']?> </td>  

<td class="actionLink">                   
<span id="<?php echo  $DivIds['BUTTONS']; ?>"    class="buttonSa">


<a href="javascript:void(0)" onclick="setMessageVal('<?php echo  $record['smsText']; ?>') ">Use It</a>



</span>


</td>



</tr>
<? 
} ?>  
</table> 
</div>
	</td>
	
	
	</tr>
	</table>

	
	
 </td>
 </tr>
  </table>
 


 
 

<? include($site['root-wtos'].'bottom.php'); ?>
<style>
.listTableAPP{ border:1px dotted  #666666;}
.listTableAPP td{border:none; border-bottom:1px dotted #EFEFEF; border-right:1px dotted #666666;}
.gray{ color:#999999;}
</style>
<style>
.rollList{ width:67px; margin-top:1px; border:1px dotted #999999; background-color:#CCFFD9;  float:left;}
.rollBox{ height:400px; overflow-y:scroll;}
.assignedListBox{ margin-bottom:10px;}
.assignListCount{ margin:3px; border:1px dotted #999999; background-color:#FFD7C4;}
.assignListCount:hover{ background-color:#FFFFCA;}
.errorShow{ color:#FF0000; padding:5px;}
.scroll_div{height:500px;overflow-x:hidden;overflow-y:scroll;}
</style>
<style>
.tableclass{ border:2px groove #ffffff; float:left; padding-left:5px;}
.tableclass td{ border:2px groove #ffffff; padding:10px;}
.groove{border:2px groove #ffffff;}
.table_top{ border:1px solid #cecece; border-collapse:collapse; border-spacing:0; width:1400px;}
.table_top td{ vertical-align:top;}
.table_top td, .table_top th{ border:1px solid #b3b3b3;}
.list_ta{ border-collapse:collapse; border-spacing:0;}
.list_ta th,.list_ta td{ border:1px solid #cecece;}
.list_ta td{ padding:1px 1px; vertical-align:top;}
.list_ta  tbody {height:500px;overflow-y: scroll;}
.list_ta thead, .list_ta tbody tr { }  
</style>
</div>


<script> 
function setMessageVal(message)
{
	os.setVal('msgText',message);
  
}
 
</script> 