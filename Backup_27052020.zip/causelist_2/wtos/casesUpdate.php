<?php
include('includes/config.php');
include('top.php');
  if($os->checkAccess('Edit')){}else{ echo 'Please do not temper software . '; exit();}
 
 


// config 

$DivIds['AJAXPAGE']='casesEdit';
$listPAGE='cases';
$primeryTable='cases';
$primeryField='casesId';
$listHeader='Update Cases';
$deptCode=$_POST['dept'];
$caseListToEdit=$_POST['caseListToEdit'];
if($deptCode!=''){
$defaultDeptCode=$deptCode;
}
$os->setFlash($flashMsg);
//tinyMce();

//searching......



## saving data  444

if($_POST['updateCases']=='OK')
{
	 
	if(count($_POST['dated'])>0)
	{
	  foreach ($_POST['dated'] as $ak=>$dated)
	  {
	  
	  $dataToSave=array();
	  $dated=$dated;
	  $aorNo=$_POST['aorNo'][$ak];
	  $caseNo=addslashes($_POST['caseNo'][$ak]);
	  $title=addslashes($_POST['title'][$ak]);
	  $tag=$_POST['tag'][$ak];
	  $hod=$_POST['hod'][$ak];
	  $clientRep=$_POST['clientRep'][$ak];
	  $aorCouncel=$_POST['aorCouncel'][$ak];
	  $councel_1=$_POST['councel_1'][$ak];
	  $councel_2=$_POST['councel_2'][$ak];
	  $remarks=$_POST['remarks'][$ak];
	  $background=addslashes($_POST['background'][$ak]);
	  $Instruction=addslashes($_POST['Instruction'][$ak]);
	   $InstructionTemp=addslashes($_POST['InstructionTemp'][$ak]);
	  if(trim($InstructionTemp)!='')
	  {
	  $background=$background."\n".$Instruction;
	 
	  $Instruction=$InstructionTemp;
	  }
	  
	  
	  
		 
			$dataToSave['dated']=$dated; 
			$dataToSave['caseNo']=$caseNo; 
			$dataToSave['title']=$title; 
			$dataToSave['tag']=$tag; 
			$dataToSave['hod']=$hod; 
			$dataToSave['clientRep']=$clientRep; 
			$dataToSave['background']=$background; 
			$dataToSave['Instruction']=$Instruction; 
			$dataToSave['aorNo']=$aorNo; 
			$dataToSave['aorCouncel']=$aorCouncel; 
			$dataToSave['councel_1']=$councel_1; 
			$dataToSave['councel_2']=$councel_2; 
			$dataToSave['remarks']=$remarks; 
			 
			
			
			$dataToSave['modifyDate']=$os->now();
			$dataToSave['modifyBy']=$os->userDetails['adminId']; 
		    $insertedId=$os->save($primeryTable,$dataToSave,$primeryField,$ak);
	  
	   $successMsg="Data saved successfully";  
	  
	  
	  }
	
	
	}


}

##444

  
?>
<style>

	.slNo{}
	.dated{}
	.caseNo{}
	.title{}
	.dept{}
	.tag{}
	
	<? if($deptCode=='Dept. 1' || $deptCode=='Dept. 2' ){ ?>
	.aorNo{ display:none;}
	.aorCouncel{display:none;}
	.councel_1{display:none;}
	.councel_2{display:none;}
	<? } ?>
	<? if($deptCode=='Dept. 3' ){ ?>
	.hod{display:none;}
	.clientRep{display:none;}
	.background{display:none;}
	.Instruction{display:none;}
	<? } ?>
	
	
	
	
	.remarks{}
	.status{}
	</style>
	<table class="container">
				<tr>
					<td  class="leftside">
						
				  
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td  class="middle" style="padding-left:5px;">
			  
			  
			  <div class="listHeader"> <?php  echo $listHeader; ?></div>
			  
			  <!--  ggggggggggggggg   -->
			  <br />
			 
			  <br />
			  <form action="" enctype="multipart/form-data" method="post">
			  
			  <table cellspacing="2" cellpadding="2" border="0">
			  <tr><td valign="top";> Department:	<br />					  
										  
										   <? if($os->userDetails['adminType']=='Admin'){ ?>
   <input type="text" name="dept" id="dept" value="<? echo $defaultDeptCode?>"  readonly="1"/>
										  
										  <? } else{?>
										
	
	<select name="dept" id="dept" class="textbox fWidth" ><option value="">Select Department</option>	<? 
										  $os->onlyOption($os->department,$defaultDeptCode);	?></select>	
										 
										  <? } ?>
										  
										  <br /> <br /> <input type="submit" value="EDIT" style="cursor:pointer;" />
  </td><td>Enter Mltiple case<br /><textarea name="caseListToEdit" style="height:50px; width:500px;" ><? echo $caseListToEdit ?></textarea>	</td></tr>
			  </table>
			 									  
	 
						   
			  <input type="hidden" name="prepareCases" value="OK" />
			 
			 </form>
			 
			  
			 
			  <?  if($successMsg!=''){ 
			  ?>
			   <br />
			  <div style="color:#009900;"> <b><? echo  $successMsg?> </b></div>
			   <br />
			  <? 
			  } ?>
			 
			 <!-- edit eeeeeeeeeeeeeeeeeeeee  -->
			 
			   <form action="" enctype="multipart/form-data" method="post">
<? 
if($_POST['prepareCases']=='OK' )
{	
        
		if($deptCode=='')
		{
			 $failMsg= 'Update Fail . Please Select Department';
		}
		elseif(trim($caseListToEdit)=='')
		{
			 $failMsg= 'Update Fail . Please enter case Nos';
		}
		
		
		
		if($deptCode!='' && trim($caseListToEdit)!='')
		{
		
		$caseListToEditA=array();
		
			$caseListToEdit=str_replace('"',"",$caseListToEdit);
			$caseListToEdit=explode("\n",$caseListToEdit);
			foreach($caseListToEdit as $kk=>$singleCase)  ## remove empty value
			{
			if(trim($singleCase)!='')  
			{$caseListToEditA[]= trim($singleCase);  }
			}
		 
		 
		  if(count($caseListToEditA)>0){
		  $caseStr = implode('|',$caseListToEditA);
		  $caseQuery="select DISTINCT * from cases where caseNo RLIKE '$caseStr' and dept='$deptCode'";
		  $caseRs=$os->mq($caseQuery );
		   
		  
		  ?>
		  <input type="submit"  value="SAVE" style="cursor:pointer;" />
		   <table  border="0" cellspacing="0" cellpadding="0" class="listTable" >
							<tr class="borderTitle" >
								 
								
								
  <td class="slNo" ><b>SL No</b></td>  
  <td class="dated" ><b>Date</b></td>  
   <td class="aorNo" ><b>Aor No</b></td>  
  
  <td class="caseNo" ><b>Case No</b></td>  
  <td class="title" ><b>Title</b></td>  
 
  <td  class="tag"><b>Tag</b></td>  
 
  <td class="hod" ><b>HOD</b></td>  
  <td class="clientRep" ><b>Client Rep.</b></td>  
 <!-- <td class="background" ><b>Background</b></td>  
  <td class="Instruction" ><b>Instruction</b></td>  -->
 
 <!-- <td class="aorCouncel" ><b>Aor-Councel</b></td>  
  <td class="councel_1" ><b>Councel-1</b></td>  
  <td class="councel_2" ><b>Councel-2</b></td>  -->
  <td class="remarks" ><b>Remarks</b></td>  
 
								
							</tr>
		  
		  <?
			 while($record=$os->mfa($caseRs ))
			 {
			 $casesId=$record['casesId'];
			  ?>
			  <tr class="borderTitle" >
			<td class="slNo"><b><?php echo $record['slNo']?></b> </td>  
  <td  class="dated"  valign="top"><input type="text" name="dated[<? echo $casesId ?>]" value="<?php echo $record['dated']?>" /> </td>  
     <td  class="aorNo"  valign="top"><input type="text" name="aorNo[<? echo $casesId ?>]" value="<?php echo $record['aorNo']?>" /></td> 
  
  <td  class="caseNo"  valign="top"><textarea name="caseNo[<? echo $casesId ?>]" ><?php echo stripslashes($record['caseNo']);?></textarea>  </td>  
  <td  class="title"  valign="top"><textarea name="title[<? echo $casesId ?>]" ><?php echo stripslashes($record['title']);?></textarea></td>  
  
  <td  class="tag"  valign="top"><input type="text" name="tag[<? echo $casesId ?>]" value="<?php echo $record['tag']?>" /></td>  

  <td  class="hod"  valign="top"><input type="text" name="hod[<? echo $casesId ?>]" value="<?php echo $record['hod']?>" /></td>  
  <td  class="clientRep"  valign="top"><input type="text" name="clientRep[<? echo $casesId ?>]" value="<?php echo $record['clientRep']?>" /></td>  
  
  
 
  <td  class="remarks"  valign="top"><input type="text" name="remarks[<? echo $casesId ?>]" value="<?php echo $record['remarks']?>" /></td>  
  </tr>
  <tr class="borderTitle">
   <td  class="aorCouncel"  valign="top"><b>Aor-Councel :</b><br /><input type="text" name="aorCouncel[<? echo $casesId ?>]" value="<?php echo $record['aorCouncel']?>" /></td>  
  <td  class="councel_1"  valign="top"><b>Councel-1 :</b><br /><input type="text" name="councel_1[<? echo $casesId ?>]" value="<?php echo $record['councel_1']?>" /></td>  
  <td  class="councel_2"  valign="top"><b>Councel-2 :</b><br /><input type="text" name="councel_2[<? echo $casesId ?>]" value="<?php echo $record['councel_2']?>" /></td>  
  <td  class="background"  valign="top" colspan="4"> <b>Background :</b><br /><textarea style="height:50px; width:500px;" name="background[<? echo $casesId ?>]" ><?php echo stripslashes($record['background']);?></textarea></td>  
  <td  class="Instruction"  valign="top" colspan="2"> <b>Instruction :</b><br /><textarea style="height:50px; width:300px;"  name="Instruction[<? echo $casesId ?>]" ><?php echo stripslashes($record['Instruction']);?></textarea></td>  
  <td  class="Instruction"  valign="top" colspan="8"> <b>Updated Instruction :</b><br /><textarea style="height:50px; width:300px;"  name="InstructionTemp[<? echo $casesId ?>]" ></textarea> </td>  
  
  </tr>
   <tr><td colspan="20" style="height:4px; "></td></tr>
  <tr><td colspan="20" style="height:4px; background-color:#FF0000;"></td></tr>

			 <tr><td colspan="20" style="height:4px; "></td></tr>
			  
			  
			    
			<? 
			 }
			  
			 ?> 
			 
			 
			  </table>  <input type="submit"  value="SAVE" style="cursor:pointer;" /><?
		 
		 }
		 
		  
		 
		 
		
		}
		

}		 
			 
			 
			 
	?>	
	 <input type="hidden" name="updateCases" value="OK" />
	
	</form>
	 <br />
			  <?  if($failMsg!=''){ 
			  ?>
			  <div style="color:#FF0000;"> <b><? echo  $failMsg?> </b></div>
			  <? 
			  } ?>
			  <br />
	 <!-- edit eeeeeeeeeeeeeeeeeeeee  -->	
			
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>







	
    
    
   
	<? include('bottom.php')?>