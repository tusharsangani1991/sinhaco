<?php
    $url = "https://malert.in/api/api_http.php";
    $recipients = array('8017477871');
    $param = array(
        'username' => 'SINHAP',
        'password' => 'cause@2018',
        'senderid' => 'SINHAP',
        'text' => 'Hello World sinha!',
        'route' => 'Informative',
        'type' => 'text',
         
        'to' => implode(';', $recipients),
    );
    $post = http_build_query($param, '', '&amp;');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Connection: close"));
    $result = curl_exec($ch);
    if(curl_errno($ch)) {
        $result = "cURL ERROR: " . curl_errno($ch) . " " . curl_error($ch);
    } else {
        $returnCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        switch($returnCode) {
            case 200 :
                break;
            default :
                $result = "HTTP ERROR: " . $returnCode;
        }
    }
    curl_close($ch);
    print $result;
?> 