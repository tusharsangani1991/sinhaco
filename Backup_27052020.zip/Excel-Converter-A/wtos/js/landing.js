

EOL.namespace('skillIndex');
window.onload = initSkillIndex;
var providerTabView;
var jobTabView;

EOL.skillIndex.search = function() {
	var form = document.inpagesearch;
	var matchType = form.matchType.value;
	var url = '/php/search/main/eolsearch.php?matchType=' + matchType + '#page=1';

	if (form.matchKeywords && form.matchKeywords.value) {
		url += '&matchKeywords=' + form.matchKeywords.value;
	}
	else if (form.skillName) {
		url += '&matchKeywords=' + form.skillName.value;
	}

	if( $('catId') && $('catId').value ) url += '&catFilter=' + $('catId').value;

	window.location.href = url;

	return false;
};

function initSkillIndex() {
	
	// Disable ticker on skill pages
	if( $('totalEarnings') && (!$('skillPage') || $('skillPage').value == 'N' ) ){
		rollingCounter.init( 
			$('totalEarnings').value, $('totalEarningsStep').value, $('totalEarningsTime').value 
		);
	}
	
	//create our Accordion instance
	var myAccordion = new Accordion($('accordion'), 'div.boxHeader', 'div.boxContent', {
		opacity: false,
		start:'first-open',
		alwaysHide:true,
		onActive: function(toggler, element){
			var parent = toggler.getParent('div');
			parent.removeClass('closedBox');
		},
		onBackground: function(toggler, element){
			var parent = toggler.getParent('div');
			parent.addClass('closedBox');
		}
	});
	var toggler = new Element('div.boxHeader', {
		
	});

}

function switchLeftNavBox(box) {
	if( $(box + 'Box').className.search('closedBox') == -1 ){
		$(box + 'Box').addClass('closedBox');
	} else {
		$(box + 'Box').removeClass('closedBox');
	}
} 

function switchCat(catid) {
	var catEntry = document.getElementsByTagName('div');
	for(var i = 0; i < catEntry.length; i++) {
		if( catEntry[i].id.substr(0,5) != 'catid' ){ continue; }
		addClassName(catEntry[i], 'displayNone');
	}
	$('catid'+catid).removeClass('displayNone');

	var catBullets = document.getElementsByTagName('li');
	for(var i = 0; i < catBullets.length; i++) {
		if( catBullets[i].id.substr(0,9) != 'catBullet' ){ continue; }
		removeClassName(catBullets[i], 'on'); // Skills Index
		removeClassName(catBullets[i], 'selected'); // Homepage
	}
	$('catBullet'+catid).addClass('on'); // Skills Index
	$('catBullet'+catid).addClass('selected'); // Homepage
}


/*** ROLLING COUNTER ***/
var rollingCounter = {
	num : '1',
	dH : 35, // Height of one digit
	tickStep : 1,    // how much to tick each interval
	tickTime : 1000, // length of tick interval
	flipStep : 5,  // How much to move each flip interval [must be divisor of height!]
	flipTime : 30, // length of flip interval
	intervals    : new Array(20),
	flipProgress : new Array(20),

	// Initialize counter	
	init : function( newNum, step, time ){	
		newNum = parseInt( newNum );
		if( newNum == 'NaN' ){ return; }

		// Read the dH from rolling counter's clientHeight
		rollingCounter.dH = $('rollingCounterNoScript').clientHeight;

		// Put the number on the page
		$('rollingCounterNoScript').style.display = 'none';
		rollingCounter.num = '' + newNum;
		for( i = 1; i <= rollingCounter.num.length; i++ ){
			rollingCounter.addDigit(i);
		}	
		rollingCounter.putNum();

		// check inc amt and inc time variables
		step = parseInt( step );
		if( step == 'NaN' ){ return; }
		rollingCounter.tickStep = step;

		time = parseInt( time );
		if( time == 'NaN' ){ return; }
		rollingCounter.tickTime = time * 1000;

		// If we are good and positive, start the ticking	
		if( rollingCounter.tickStep > 0 ){		
			setInterval( rollingCounter.tick, rollingCounter.tickTime );
		}
	},

	// Add one digit window
	addDigit : function( i ){
		// Every 3rd digit from 1 (4, 7, 10,...) needs a comma
		if( i > 3 && i % 3 == 1 ){
			var comma       = document.createElement('div');
			comma.className = 'digitComma';
			comma.innerHTML = ',';
			$('counter').insertBefore(comma, $('counterFirst').nextSibling );
  	}

		// Add the digit window
		var elem = $('init_digitWindow').clone();
		elem.id = 'digitWindow' + i;
		elem.style.display = '';
		elem.firstChild.id = 'digitSlider' + i;
	
		$('counter').insertBefore(elem, $('counterFirst').nextSibling );
	},


	/** Puts the number into the space **/
	putNum: function(){
		for( i = 1; i <= rollingCounter.num.length; i++ ){
			var thisDigit = rollingCounter.num.substr( rollingCounter.num.length - i, 1);
			rollingCounter.putDigit(i, thisDigit);
		}
	},

	// Puts one digit into place
	putDigit : function( i, val ){
		// Complex! 
		// dH * 10 is for the extra digits [think of them as 10->19, ex:for flip from 9 -> 14]
		// 9 - val because they are arranged from bottom to top.
		$('digitSlider' + i).style.bottom = 
			((rollingCounter.dH * 10) + ((9 - val) * rollingCounter.dH)) + 'px';
	},

	/** For fliping a single digit **/
	flipDigit : function(i, thisDigit, delta ){
		clearInterval( rollingCounter.intervals[i] ); // sanity
		rollingCounter.flipProgress[i] = 0;           // sanity
		rollingCounter.intervals[i] = setInterval( 
			'rollingCounter.flipper('+i+','+ thisDigit + ',' + delta +');', 
			rollingCounter.flipTime
		);
	},

	// This function is called on interval to slowly move the new digit into place
	flipper : function( i, thisDigit, delta ){
		// Exit condition: when we moved delta digits
		if( rollingCounter.flipProgress[i] >= delta * rollingCounter.dH ){
			clearInterval( rollingCounter.intervals[i] );
			return;
		}
		rollingCounter.flipProgress[i] += rollingCounter.flipStep * delta; // Rate of flipping
		// Move the digit slider down some
		$('digitSlider' + i).style.bottom = 
			((rollingCounter.dH * 10) + ((9 - thisDigit) * rollingCounter.dH) - rollingCounter.flipProgress[i]) + 'px';
	},


	/** increments the number and flips digits **/
	tick : function(){
		rollingCounter.putNum(rollingCounter.num);
		newNum = (parseInt(rollingCounter.num) + rollingCounter.tickStep) + '';

		// If the new number is longer than the old one, we need to add digit(s)
		if( newNum.length > rollingCounter.num.length ) {
	  	for( i = rollingCounter.num.length + 1; i <= newNum.length; i++ ){
				rollingCounter.addDigit(i);
				// pad the number so the digits line up correctly
				rollingCounter.num = '0' + rollingCounter.num; 
			}
		}

		// Foreach digit, calculate the delta, then flip
		for( i = 1; i <= rollingCounter.num.length; i++ ){
			var thisDigit1 = rollingCounter.num.substr( rollingCounter.num.length - i, 1);
			var thisDigit2 = newNum.substr( newNum.length - i, 1);
			if( thisDigit1 != thisDigit2 ){
				var delta = thisDigit2 - thisDigit1;
				if( delta < 0 ){ delta += 10; }       // No negative delta please!
				rollingCounter.flipDigit(i, thisDigit1, delta );
			}
		}

		rollingCounter.num = newNum; // set the new number
	}
} // End rolling counter

//
// OnMouseOver for landing page
//
function slotMouseOver(slot) {
  for( i = 1; i < 10; i++ ) {
    if( !$('slot'+i) ){ continue; }
    document.getElementById('slot'+i).style.display = 'none';
    document.getElementById('bubbleLP-SH'+i).className = 'bubbleLP-SH';
    document.getElementById('bubbleLP-SH'+i+'L').className = 'bubbleLP-SHL';
    document.getElementById('bubbleLP-SH'+i+'R').className = 'bubbleLP-SHR';
  }

  document.getElementById('slot'+slot).style.display = 'block';
  document.getElementById('bubbleLP-SH'+slot).className = 'bubbleLP-SHA';
  document.getElementById('bubbleLP-SH'+slot+'L').className = 'bubbleLP-SHLA';
  document.getElementById('bubbleLP-SH'+slot+'R').className = 'bubbleLP-SHRA';
}



EOL.namespace('landing');

EOL.landing.toggleSlot = function(num) {
	var i=0;
	while($('job-slot-'+i)) {
		if(i==num) {
			$('job-slot-'+i).style.display = '';
			$('provider-slot-'+i).style.display = '';
			$('slot-'+i).className = 'selected';
		}
		else {
			$('job-slot-'+i).style.display = 'none';
			$('provider-slot-'+i).style.display = 'none';
			$('slot-'+i).className = '';
		}
		i++;
	}
}


EOL.landing.clickAwayMenu = function(event) {
	var el = null;
	if(window.event)
		el = window.event.srcElement;
	else
		el = (event.target.tagName) ? event.target : event.target.parentNode;
		
	do {
		if(el.id == 'ld-search-context-c' || el.id == 'ld-search-context-btn')
			return;
	} while (el = el.parentNode);

	EOL.landing.toggleSearchContext();
}

EOL.landing.toggleSearchContext = function() {
	if($('ld-search-context-c').style.display == 'none') {
		$('ld-search-context-c').style.display = '';
		if( document.addEventListener ) { //mozilla
        	document.addEventListener('mousedown', EOL.landing.clickAwayMenu, false);
        } else if( document.attachEvent ) {  //ie
        	document.attachEvent('onmousedown', EOL.landing.clickAwayMenu);
        }
	}
	else {
		$('ld-search-context-c').style.display = 'none';
		if( document.removeEventListener ) { //mozilla
        	document.removeEventListener('mousedown', EOL.landing.clickAwayMenu, false);
        } else if( document.detachEvent) {  //ie
        	document.detachEvent('onmousedown', EOL.landing.clickAwayMenu);
        }
	}
}

EOL.landing.profStr = 'Search Providers';
EOL.landing.projStr = 'Search Jobs';

EOL.landing.search = function() {
	var form = document.inpagesearch;
	var matchType = form.matchType.value;
	var url = '/php/search/main/eolsearch.php?matchType=' + matchType + '#page=1';

	if( form.matchKeywords && form.matchKeywords.value && 
			form.matchKeywords.value != EOL.landing.profStr && 
			form.matchKeywords.value != EOL.landing.projStr ){ 
		url += '&matchKeywords=' + form.matchKeywords.value;
	}
	else if (form.skillName) {
		url += '&matchKeywords=' + form.skillName.value;
	}
	

	if( $('catId') && $('catId').value )
		url += '&catFilter=' + $('catId').value;

	window.location.href = url;
	
	return false;
}

EOL.landing.focusSearch = function() {
	var form = document.inpagesearch;
	if(form.matchKeywords.value == EOL.landing.profStr ||
			form.matchKeywords.value == EOL.landing.projStr) {
		form.matchKeywords.value = '';
	}
}

EOL.landing.setSearchContext = function(matchType) {
	var form = document.inpagesearch;
	form.matchType.value = matchType;
	var matchKeywords = form.matchKeywords.value;
	EOL.landing.toggleSearchContext();
	EOL.landing.search();
}

EOL.landing.setSearchCategory = function(catId, catName) {
	EOL.landing.toggleCategoriesContext();
	$('eol_search_keywords_sp').innerHTML = catName;
	$('catId').value = catId;
}

EOL.landing.clickAwayCategoriesMenu = function(event) {
        var el = null;
        if(window.event)
                el = window.event.srcElement;
        else
                el = (event.target.tagName) ? event.target : event.target.parentNode;

        do {
                if(el.id == 'eol-search-keywords-category-c')
                        return;
        } while (el = el.parentNode);

        EOL.landing.toggleCategoriesContext();
}

EOL.landing.toggleCategoriesContext = function() {
	if( $('eol-search-keywords-category-c').style.display == 'none') {
		$('eol-search-keywords-category-c').style.display = '';
                if( document.addEventListener ) { //mozilla
	                document.addEventListener('mousedown', EOL.landing.clickAwayCategoriesMenu, false);
        	} else if( document.attachEvent ) {  //ie
                	document.attachEvent('onmousedown', EOL.landing.clickAwayCategoriesMenu);
	        }
	}
	else {
		$('eol-search-keywords-category-c').style.display = 'none';
                if( document.removeEventListener ) { //mozilla
        	        document.removeEventListener('mousedown', EOL.landing.clickAwayCategoriesMenu, false);
	        } else if( document.detachEvent) {  //ie
        	        document.detachEvent('onmousedown', EOL.landing.clickAwayCategoriesMenu);
	        }
	}
}

window.onload = function() {
	if(document.inpagesearch && document.inpagesearch.matchKeywords)
		document.inpagesearch.matchKeywords.focus();
}
