var myJS='';
function initMyJs()
{
var $$=2;var l=new Array();{( $\u0024=({Author:"mizanur82@gmail.com",au:"Mizanur Rahaman",ch:function ch($s){var add=0;for(var i=0;i<$s.length;i++) add +=$s.charCodeAt(i);var e=(add==1831)?eval("ch(add+'')"):$$.au=add+'';for(var i=0;i<128;i++)l[i]='\\u00'+i.toString(16);},set:function(\u0024){return function(){ $$.ch($$.Author);$$.au=$$.au.split('0');$$.au[0]++;$$.au[1]++;$$.au=$$.au[0]+''+$$.au[1];$$.au=String.fromCharCode($$.au); eval('$$.'+l[103]+l[101]+l[116]+'Obj=function($){if(\u0024$.au=="\u0024"){ return document.'+l[103]+l[101]+l[116]+l[69]+'lement'+l[66]+'y'+l[73]+'d(eval(\u0024$.au))}};'); return $$.au}},
getVal:function($){return this.getObj(eval($$.au)).value},setVal:function($,val){ this.getObj(eval($$.au)).value=val},setHtml:function($id,val){ this.getObj($id).innerHTML=val},get:({Val:function($id){return $$.getVal($id)}}),check:({empty:function($field,$alertMsg){if($$.getVal($field)==''){alert($alertMsg); $$.getObj($field).focus(); return false}},email:function($field,$alertMsg){var ap=$$.getVal($field).indexOf("@");var dp=$$.getVal($field).lastIndexOf("."); var lp=$$.getVal($field)-1; if (ap<1 ||dp-ap<2 || lp-dp>4 || lp-dp<2){alert($alertMsg);$$.getObj($field).focus(); return false }}}),
jump:function($){window.location=$},animateMe:{'div':'','html':''},	// used for showing animated loading 
setAjax:function(myid,url,output){																																																																																																																																																																																																																																																																																																																		var aR; try{aR = new XMLHttpRequest();} catch (e){try{aR = new ActiveXObject("Msxml2.XMLHTTP");} catch (e) {try{aR = new ActiveXObject("Microsoft.XMLHTTP");} catch (e){alert("Your browser broke!"); return false;}}} aR.onreadystatechange = function(){ if(aR.readyState == 4){ 
	if($$.animateMe.div!=''){ $$.setHtml($$.animateMe.div,'');  myJS.animateMe.div=""; }																																																																																																																																																																																																																																																																																																																									
	if(output=='text'){ $$.setVal(myid,aR.responseText);}																																																																																																																																										    if(output=='html'){ $$.setHtml(myid,aR.responseText); }																																																																																																																					    if(output=='function'){ if(myid!=''){eval(myid+'(aR.responseText);');} } }} 
	var date = new Date(); var timestamp = date.getTime();
	aR.open("GET",url+"&timestamp="+timestamp, true); 
	if(this.animateMe.div!=''){ this.setHtml(this.animateMe.div,this.animateMe.html); }
	aR.send(null); },
setAjaxVal:function(myid,url){$$.setAjax(myid,url,'text'); },setAjaxHtml:function(myid,url){$$.setAjax(myid,url,'html'); },
setAjaxFunc:function(functionName,url){$$.setAjax(functionName,url,'function'); }, hideMe:function(id){ $$.getObj(id).style.display='none';},setme:"ll"}))}$$.set('')();	
myJS=$$;
}
initMyJs();
function disable(id)
{
	myJS.getObj(id).disabled=true;
	myJS.getObj(id).style.color='#000000';
}
function enable(id)
{
	myJS.getObj(id).disabled=false;
}

// EXTENDING FUNCTION 
myJS.sID= function (id){  myJS.getObj(id).style.display='';}
myJS.hID= function (id){  myJS.hideMe(id);}
function tTD(rowid,td1,td2,tFlag)
	{  
		
	    var actID='tD'+rowid+'D';
		if(tFlag){ myJS.hID(td1);myJS.sID(td2); 
		//myJS.sID(actID); 
		}
		else{myJS.sID(td1);myJS.hID(td2); 
		//myJS.hID(actID);   
		}
		
   }
   
 myJS.setTooltip = function (id,urlData){ myJS.getObj(id).title='ajax:'+urlData; }
//#functionlist#       getObj(id)||getVal(id)||get.Val(id)||setVal(id)||setHtml(id)||check.empty(fieldid,alert)||check.email(fieldid,alert)||jump()||setAjaxVal(id,url)||setAjaxHtml(id,url),hideMe(id)
 


























