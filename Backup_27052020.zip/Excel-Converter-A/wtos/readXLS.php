<?php
// Test CVS
include('../includes/config.php');

include('../topBlank.php');

require_once 'Excel/reader.php';

$ParentPage='shop';
$folderInner='WAH/';

if(isset($_REQUEST['submit']))
{

	$uploadFile=$_FILES['excelFile']['tmp_name'];
	//echo $uploadFile;
}
// ExcelFile($filename, $encoding);
$data = new Spreadsheet_Excel_Reader();


// Set output Encoding.
$data->setOutputEncoding('CP1251');


$data->read($uploadFile);


error_reporting(E_ALL ^ E_NOTICE);



for ($RowsNu = 2; $i <= $data->sheets[0]['numRows']; $RowsNu++)
{
	#category array#	
	$catArray=$os->get_shopcategory();
	$collectCatArray=array();
	if(is_array($catArray) && count($catArray)>0)
	{
		foreach($catArray as $catArrayVal)
		{
			$collectCatArray[$catArrayVal['catId']]=strtolower(trim($catArrayVal['title']));
		}
	}
	
	#state array#
	$stateArray=$os->get_state();
	$collectStateArray=array();
	if(is_array($stateArray) && count($stateArray)>0)
	{
		foreach($stateArray as $stateArrayVal)
		{
			$collectStateArray[$stateArrayVal['stateId']]=$stateArrayVal['name'];
		}
	}
	
	#city array#
	$cityArray=$os->get_cities();
	$collectCityArray=array();
	if(is_array($cityArray) && count($cityArray)>0)
	{
		foreach($cityArray as $cityArrayVal)
		{
			$collectCityArray[$cityArrayVal['cityId']]=$cityArrayVal['name'];
		}
	}
	
	# area array  #
	$areaArray=$os->get_area();
	$collectAreaArray=array();
	if(is_array($areaArray) && count($areaArray)>0)
	{
		foreach($areaArray as $areaArrayVal)
		{
			$collectAreaArray[$areaArrayVal['areaId']]=$areaArrayVal['name'];
		}
	}
	
	
	for ($j = 1; $j <= $data->sheets[0]['numCols']; $j++) 
	{
		//echo "\"".$data->sheets[0]['cells'][$i][$j]."\",";
	}	
		
		
		if($data->sheets[0]['cells'][$RowsNu][6]!="")
		{
			
			#category Add#
			if(trim($data->sheets[0]['cells'][$RowsNu][5])!='')
			{
				$cateField1=strtolower(trim($data->sheets[0]['cells'][$RowsNu][5]));
				$catkey = array_search($cateField1,$collectCatArray);
				$dataToSave['catId']=$catkey;
				if(empty($catkey)){
				$data11=array();
				$data11['title']=strtolower(trim($cateField1));
				$data11['addedDate']=date("Y-m-d h:i:s");
				$data11['active']='1';
				$dataToSave['catId']=$os->save_shopcategory($data11);
				}
			}
			else
			$dataToSave['catId']='';
			
			#State Add#
			if(trim($data->sheets[0]['cells'][$RowsNu][2])!='')
			{
				$stateField1=strtolower(trim($data->sheets[0]['cells'][$RowsNu][2]));
				$statekey = array_search($stateField1,$collectStateArray);
				$dataToSave['stateId']=$statekey;
				if(empty($statekey)){
				$data11=array();
				$data11['name']=strtolower(trim($stateField1));
				$data11['addedDate']=date("Y-m-d h:i:s");
				$data11['active']='1';
				$dataToSave['stateId']=$os->save_state($data11);
				}
			}
			else
			$dataToSave['stateId']='';

			#city Add#
			if(trim($data->sheets[0]['cells'][$RowsNu][3])!='')
			{
				$cityField1=strtolower(trim($data->sheets[0]['cells'][$RowsNu][3]));
				$State=strtolower(trim($data->sheets[0]['cells'][$RowsNu][2]));
				$stateKey=$os->get_state("name='$State'");
				$citykey = array_search($cityField1,$collectCityArray);
				$dataToSave['cityId']=$citykey;
				if(empty($citykey)){
				$data11=array();
				$data11['name']=strtolower(trim($cityField1));
				$data11['addedDate']=date("Y-m-d h:i:s");
				$data11['active']='1';
				$data11['stateId']=$stateKey[0]['stateId'];
				$dataToSave['cityId']=$os->save_cities($data11);
				}
			}
			else
			$dataToSave['cityId']='';
			
			
			#Area Add#
			if(trim($data->sheets[0]['cells'][$RowsNu][4])!='')
			{
				$areaField1=strtolower(trim($data->sheets[0]['cells'][$RowsNu][4]));
				$City=strtolower(trim($data->sheets[0]['cells'][$RowsNu][3]));
				$CityKey=$os->get_cities("name='$City'");
				$areakey = array_search($areaField1,$collectAreaArray);
				$dataToSave['areaId']=$areakey;
				if(empty($areakey)){
				$data11=array();
				$data11['name']=strtolower(trim($areaField1));
				$data11['addedDate']=date("Y-m-d h:i:s");
				$data11['active']='1';
				$data11['cityId']=$CityKey[0]['cityId'];
				$dataToSave['areaId']=$os->save_area($data11);
				}
			}
			else
			$dataToSave['areaId']='';
			
			
			$dataToSave['country']=$data->sheets[0]['cells'][$RowsNu][1];
			$dataToSave['name']=$data->sheets[0]['cells'][$RowsNu][6];
			$dataToSave['district']=$data->sheets[0]['cells'][$RowsNu][7];
			$dataToSave['propietorName']=$data->sheets[0]['cells'][$RowsNu][8];
			$dataToSave['address']=$data->sheets[0]['cells'][$RowsNu][9];
			$dataToSave['month']=$data->sheets[0]['cells'][$RowsNu][10];
			$dataToSave['phone']=$data->sheets[0]['cells'][$RowsNu][11];
			$dataToSave['particulars']=$data->sheets[0]['cells'][$RowsNu][12];
			$dataToSave['DOA']=$data->sheets[0]['cells'][$RowsNu][13];
			$dataToSave['validTill']=$data->sheets[0]['cells'][$RowsNu][14];
			$dataToSave['discount']=$data->sheets[0]['cells'][$RowsNu][15];
			$dataToSave['addedBy']=$data->sheets[0]['cells'][$RowsNu][16];
			$dataToSave['addedDate']=date("Y-m-d h:i:s");
			
			
			
			
		
			$os->save_shop($dataToSave,$primeryField,$rowId);
			
		 }
		 else
		 {
		 $flashMsg=($rowId)?'Record Updated Successfully':'Record Added Successfully';
	  
		$os->ScriptRedirect($site['url'].$folderInner.$ParentPage.'.php');

		 }
		 
		 


}


?>
