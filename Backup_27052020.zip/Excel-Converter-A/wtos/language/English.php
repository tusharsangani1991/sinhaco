<? 
#common text

$sLang['COM_text_Logout']="Logout";
$sLang['COM_text_Total']="Total";
$sLang['COM_text_Show']="Show";

#Navigation
$sLang['COM_text_Home']="Home";
$sLang['Manage User']="Manage User";
$sLang['Backups']="Backups";
$sLang['Reports']="Reports";

?>