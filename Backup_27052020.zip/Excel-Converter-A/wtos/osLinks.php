<style>
.linkClass{
margin:2px 5px 2px 20px;
}
</style>
<fieldset class="cFielSet"  >
					<legend  class="cLegendOSL" >Manage</legend>

						   <a href="<? $seoLink->l('excelConvert',true); ?>" >Download Cause List</a> &nbsp; 	<br />
						  
					 </fieldset>


<fieldset class="cFielSet"  >
					<legend  class="cLegendOSL" >System Tools</legend>
					  <a href="<? $seoLink->l('loadMonthlyList',true); ?>" >Load Monthly List</a> &nbsp; 	<br />
						  <!-- <a href="<? $seoLink->l('excelConvertList',true); ?>" >Excel Convert List</a> --> &nbsp; 	<br />
						 
						
						 <a href="<? $seoLink->l('admin',true); ?>" >Admin</a> &nbsp; 	<br />
						 <a href="<? $seoLink->l('changepwd',true); ?>" >Change Password </a> &nbsp; 	<br />
						  <a href="<? $seoLink->l('settings',true); ?>" > Settings</a> &nbsp; 	<br />
						<!-- <a href="?dLoad=true" > Download Database </a> <br />-->
			 
						  
					 </fieldset>





<div class="linkClass">

				
				
				
				
			
				</div>