<?php
include('includes/config.php');
include('top.php');


?>


<? 
$fusionChart=false;
?>


	<table class="container">
				<tr>
					<td width="243" class="leftside">
						
				 
						
						<?php  include('osLinks.php'); ?>
					</td>
			  <td width="770" class="middle" style="padding-left:5px;">
			  
			  
			  <!--  ggggggggggggggg   -->
			  
			  <!--<div class="headertext">  </div>-->
			  
				<div style="font-size:14px; font-weight:bold; color:#333333; padding-left:100px;">
				      <img src="<?php echo $site['url'] ?>image/sc.jpg" alt=""  style="padding:15px; margin:auto;"/>
					    
				</div>
				 
				 
				 
			  
			  <!--   ggggggggggggggg  -->
			  
			  </td>
			  </tr>
			</table>






   
	<? include('bottom.php')?>