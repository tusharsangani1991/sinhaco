
				  
		</div>
	</div>
	<div align="center" style="text-align:center; display:none;">
	<a href="http://webtrackers.co.in/" title="Powered By Webtrackers4u" target="_blank">
	<img src="<?php echo $site['url'] ?>image/poweredBy.png" alt="" width="30" height="25"  style="margin:0 0 0 5px; border:none;"/></a></div>
	<!--Copyright &copy; <?php echo date('Y');?> www.webtrackers.co.in - All Rights Reserved.-->
</div>
</body>
</html>
