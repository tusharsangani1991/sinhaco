<? 
include(inclPath('classes').'/export.php');
#include(inclPath('classes').'/tooltip.php');

include('os.php');

$pagevar[myJs][]=$site['url'].'js/basic.function.js';

$pagevar[myJs][]=$site['url'].'js/common.js';
$pagevar[myJs][]=$site['url'].'js/jquery-1.2.2.pack.js';


$pagevar[myCss][]=$site['themePath'].'css/style.css';

$pagevar['defaultPage']='home.php';
$pageVar['segment']=array();

$sefu= new sefu('.php');
$seoLink=&$sefu;
$requestPage= $sefu->LoadPageName();
$pageVar[segment]=$sefu->getSegments();
$content=$pagevar[defaultPage];


$os->loginKey=$site['loginKey'];
$os->processLogin('username','password','admin');


if(is_array($_SESSION[$os->loginKey]) && $_SESSION[$os->loginKey]!='')
{
	$os->userDetails=$_SESSION[$os->loginKey];

}



if($_GET['logout']=="logout")
{
	 $os->Logout();
	 
	 $os->Execute($os->rId[jump], $site['url'].'login.php',"results"); 
}

if($os->CurrentPageName()!='login.php')
{
	 if(!$os->isLogin())
	  {
		 $os->Execute($os->rId[jump], $site['url'].'login.php',"results"); 
	  }
}


if($_GET['dLoad']=='true')
{
  $export->download($site['db'].'.sql',$export->dbDump($site['db']));
}

?>