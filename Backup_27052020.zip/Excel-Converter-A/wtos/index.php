<?php   header('location:login.php');

include('includes/config.php');
include('os.php');
$filename = "sample.html";
$handle = fopen($filename, "rb");
$contents = fread($handle, filesize($filename));
fclose($handle);
$fString=strip_tags($contents);
$floor=array( 'GROUND FLOOR' => 'GROUND FLOOR', 2 => 'green', 3 => 'red');
//$array = array(0 => 'blue', 1 => 'red', 2 => 'green', 3 => 'red');

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
$startkey='COURT NO';
$endKey='COURT NO';
$str=$fString;
$strArr2=array();

 $strArr=preg_split("/COURT NO\./", $str);
 
 if(is_array($strArr))
 {
   foreach($strArr as $val)
   {
   
   
   $courtNO =(int)$val; 
   
   
   
   if($courtNO<1)
         continue;
		 
     $floorA = explode("\n",$val);
	 $floor =$floorA['1'];
	 $strArr2[$courtNO]=	 preg_split("/(\\d)+\.  /", $val);
  
  
   
   }
 
 
 }
 
 _d($strArr2);

 
//$p=$os->getInnerContent($startkey,$endKey,$str);


?>

<? 
//$fString = file_get_contents('http://causelists.nic.in/calcutta/org/cl.html');
//http://localhost/Excel-converter/wtos/sample.html
?>