<?
set_time_limit(0);
session_start();
include('coomon.php');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title><?php echo $site['siteTitle'];?></title>
<meta name="description" content="description">
<meta name="keywords" content="keywords1 , keywords2">
<script>
var themepath='<?php echo $themepath ?>';
</script>
<?   echo   $os->addCss($pagevar[myCss]); ?>
<?   echo  $os->addJs($pagevar[myJs]); ?>


</head>
<body>
<?php  
$classL='loginboxS';
if($os->isLogin()){ 
$classL='loginboxSL';

}

function navSelectedHeader($nav)
{
global $pageVar;

 echo ($pageVar[segment][1]==$nav)?'class="selected"':'';

}




?>
<div class="main">
	<div class="wrapper">
		<div class="header">
		</div>
		<div class="curvebox">
			<div class="headerimage"><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="4%" align="center"><a href="<?php echo $site['url']?>/dashBoard.php"><img src="<?php echo $site['url']?>image/logo.png" alt="" width="45" height="31" style=" margin:0 0 0 5px; border:none;"/></a></td>
    <td width="5%" align="center"><span class="style2" style="width:350px;"><strong> <? echo $site['siteHeading']; ?> </strong></span></td>
    <td  align="center">&nbsp;</td>
    <td  height="32" align="center">Welcome <span class="style2"><strong><?php echo $os->userDetails['name']; ?></strong></span>
	
	&nbsp; <a href="" class="style2" style="text-decoration:none"> <? echo date('d-M-Y'); ?> </a> &nbsp; &nbsp;
	&nbsp; <a href="" class="style2" style="text-decoration:none"> REFRESH </a> &nbsp;
	
	</td>
    <td ><?php if($os->isLogin()){ ?><a href="?logout=logout" style="text-decoration:none;"><span class="style4">Logout</span></a> <?php }?>
	<?php if($os->isLogin()){ ?>  <a href="<? $seoLink->getLink('changepwd',true); ?>" style="text-decoration:none;"><span class="style4">| Change Password</span></a> <?php }?>
	
	</td>
  </tr>
</table>

<?php

ob_start(); 
$recordPerPage= $os->recordPerPageDD();
$recordPerPageDDS=ob_get_clean();

?>

</div>
			<div class="buttons-section">
				<!--<a href="#" class="home">Home</a>-->
			
						
							
				<span style="color:#333333; font-size:16px; font-weight:bold;"> Appellate Side</span>  <span style="size:12px;"> Causelists Extractor</span>  
				
				<div class="clear"></div>
			</div>
		
