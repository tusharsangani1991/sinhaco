<?
include(inclPath('classes').'/sm.php');
function varP($key)
{
  $postval='';
  if(isset($_POST[$key]))
  {
     $postval=str_replace('m#m','&',$_POST[$key]);
  }
  return $postval;
  
}

function varG($key)
{
  $getval='';
  if(isset($_GET[$key]))
  {
     $getval=$_GET[$key];
  }
  return $getval;
  
}

function tinyMce()
{
 // include('tinyMCE.php'); 
}

 

class os extends sm 
{
##  causelist 565 
var $department=array('Dept. 1'=>'Dept. 1','Dept. 2'=>'Dept. 2','Dept. 3'=>'Dept. 3');

//var $smsKey=array( '0'=>'#[CASENO]#','1'=>'#[DATE]#','2'=>'#[COURTNO]#'); 
	
var $smsKey=array( '[#Case_No#]'=>'','[#Item_No#]'=>'','[#Cause_Title#]'=>'','[#Court_No#]'=>'','[#Date#]'=>''); 
##  causelist 565 end

  var $hhh=array('1'=>'one','2'=>'two');
   var $activeStatus=array('1'=>'one','2'=>'two');
    var $caseStatus=array('Active'=>'Active','InActive'=>'InActive');
		
function changeStatusDD_2($statusArr,$selected,$table,$satusfld,$idFld,$idVal,$colorStatus)
	{

	    $vars=	"'$table','$satusfld','$idFld','$idVal'";		

		$backGround=($colorStatus[$selected])?$colorStatus[$selected]:'FFFFFF';
		echo '<input type="text"   value='.$selected.' id="changeStatusDD_2" name="changeStatusDD" style="width:50px;height:10px;" onchange="os.changeStatus(this,'.$vars.')" >';

		// return   $selected;

	}
	function checkAccess($accKey=''){
		if($accKey!=''){
			$accArr = array();
			
			if($this->userDetails['access']!=''){
				$accArr = explode(',',$this->userDetails['access']);
			}
			if(is_array($accArr) && in_array($accKey,$accArr)){
				return true;
			}
		}
		else{
			return false;
		}
	}
	
	function wtlogs($title='',$description='')
	{
	
		$dataToSave['title']=$title;
		$dataToSave['description']=$description;
		$dataToSave['addedDate']=$this->now();
		$dataToSave['addedBy']=$this->userDetails['adminId'];
		$this->save('wtlogs',$dataToSave);
	
	
	
	}
	
	function saveSendingSms($smsText,$mobileNos , $status='send' ,$note='',$addedBy='')
	{
		
		$dataToSave['smsText']=$smsText;
		$dataToSave['dated']=$this->now(); 
		$dataToSave['mobileNos']=$mobileNos; 
		//$dataToSave['applicantIds']=$applicantIds; 
		$dataToSave['status']=$status; 
		$dataToSave['note']=$note;
		$dataToSave['addedBy']=$addedBy; 
		$qResult=$this->save('sms',$dataToSave,'smsId','');	
	
	}

function sendMsgStatus($msgId)
{
	 $fc=file_get_contents ('https://malert.in/api/api_http_dlr.php?username=SINHAP&password=cause@2018&msgid='.$msgId);
	  $p= stristr($fc,'stat');	 
	 $p= stristr($p,'text',true);	 
	  
	  return($p);
	
}
}


$os= new os;
