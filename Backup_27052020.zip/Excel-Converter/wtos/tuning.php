<?php  
function getFile($link)
{
	if($link=='')
	{
		$filename = "sample.html";
		$handle = fopen($filename, "rb");
		$contents = fread($handle, filesize($filename));
		fclose($handle);
	}else
	{
		$contents = file_get_contents($link);
		
	}
	if($contents!='')
	{
		$fString=strip_tags($contents);
		return $fString;
	}
}

#+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++#
function tuneSearch($keys,&$urlString)
{




 if($keys==''){return ;}
global $os;
$startkey='COURT NO';
$endKey='COURT NO';
$str=$urlString;
$strArr2=array();
 // _d( $str);

 $strArr=preg_split("/COURT NO\./", $str,-1);
 
 if(is_array($strArr))
 {
   foreach($strArr as $val)
   {
   
  // echo '<br>-------------------------------------------++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------';
  //  _d('888-'.$val);
  
  /* 444444444444  
	  if($courtNO==7)
	  {
	    _d($itemsNo);
		echo $os->q;
		_d($mList);
		//exit();
	  }
	  	444444444444444   */

   
   $courtNO =(int)$val; 
   
  // echo $courtNO.'<br>';
   if($courtNO<1)
         continue;
		 
     $floorA = explode("\n",$val);
	 $floor =$floorA['1'];
		 
	#--- search string -----##
	 $foundStr=false;
	
	#999
	/*
	if($courtNO==7)
	{
	_d( $val);
	
	}else
	{
	
	continue;
	}
	*/
	#9999
	 
	 $fStr=strpos($val,$keys);
	 if( $fStr!==false ){$foundStr=true;}  // first step quick serch 
      
	 $fStr2=strpos(str_replace("\n",'',$val),$keys);
	 if( $fStr2!==false ){$foundStr=true;}  // first step quick serch // serch also key separated by newline
	  
	  #-----  monthly data search
	 
	  $itemsNo= getItemsNo($val); // 2012-01-24
	 
	  
	  $mList=array();	
	  $dM=date('m/Y');  #323
	  if(is_array($itemsNo) && count($itemsNo)>0)
	  {  
	   $andItemNo='and  itemNo IN ('.implode(',',$itemsNo).' )   ';
	   $where=" courtNO>0  $andItemNo  and  dataStr like '%$keys%' and courtNo='$courtNO' and month='$dM' ";
	   
	 //  echo $where;  
	   
	   
	  
	   $mList=$os->get_monthlylist($where,'','',' dataStr, itemNo ');
	   
	  // echo $os->q;
	    
		//_d( $where);
	/* 444444444444  
	  if($courtNO==16)
	  {
	    _d($itemsNo);
		echo $os->q;
		_d($mList);
		//exit();
	  }
	  	444444444444444   */
	  //echo $os->q.'<br><br>';
	  
	  }	 
			
		
	  #----- monthly data search end 
	
	
	$cases=array();
	$proceedControl=false;
	
	 if($foundStr==true)
	 {
	  //  $cases=	 preg_split('/\n(\d+)\.\s/', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
		$cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );  // updated 22 april 2015
		$proceedControl=true;
		
	 }
	 ## add monthly list  
	
	if(is_array($mList) && count($mList)>0)
	{
		foreach($mList as $val)
		{
		
		
			$cases[]=$val['itemNo']."M";
			$cases[]=$val['dataStr'];
		
		 
		 }
		 $proceedControl=true;
		
	}
		
		
		 ## add monthly list end   
	
	 if($proceedControl==true)
	 {	
		
		 
		
		 
				if(is_array($cases))
				{
					
					
					
					foreach($cases as $cvK=>$casesVal)
					{
					   
					 
					   
					   $foundStrSTEP2=false;
					   
					//   $fStrSplited=strpos(str_replace("\n",'',$casesVal),$keys);  // 2nd step details serch   // str_replace added because keyword may be splited by new line
					   $fStrSplited=strpos($casesVal,$keys);  // 2nd step details serch   
					   if( $fStrSplited!==false){$foundStrSTEP2=true;} 
	                   
					   $fStrSplited2=strpos(str_replace("\n",'',$casesVal),$keys);
					   if( $fStrSplited2!==false){$foundStrSTEP2=true;} 
					   
					   
					   
					   if( $foundStrSTEP2==true)
					   {
					   
					
					 
					    $itemNo=$cases[$cvK-1];
						
						if((int) $itemNo>0)
						{
					
					  
					    $cV=extractCaseVal($casesVal);
						
						$caseKEY="$courtNO-$itemNo-".rand(200,300);
						
					
						$os->finalArr[$caseKEY]= $cV;
						$os->finalArr[$caseKEY]['ITEM NO.']=$itemNo;
						$os->finalArr[$caseKEY]['COURT']=$courtNO;
									
					   
					    # search and put extracted data to filtered xls 
						filterAndWriteData($os->finalArr[$caseKEY],$caseKEY);
						
											   
					   
					    $os->caseCount++;
						}
					   
					  
					  
					  
					  
					   } 
					   
					   
					   
					   
					   
					   
					
					   
					} 
				}
	 
	 
	 }
	
	  
	
	#--- search string end -----##
		 
		 
		 
		 
		 
    // $floorA = explode("\n",$val);
	// $floor =$floorA['1'];
	//
  
    
   
   }
 
 
 }
 
 
 
 }
 
 
 function extractCaseVal($caseString)
 {
 
   $case=array();
    preg_match_all("/[A-Z]+\s\d+\/\d+\s/", $caseString, $matches);
	
	if(is_array($matches[0]))
	{
	     $case['CASE NO']=implode("\n",$matches[0]);
	     $caseString=str_replace($matches[0],'',$caseString);
	
	}
	  $lines=explode("\n",$caseString);
	if(is_array($lines))
	{
	     
		 $fLA=explode(' Vs',$lines[0]);
		 
		 $causT1=$fLA[0];
		 $pt1=$fLA[1];
		 
		 if($pt1=='')
		 {
					  $fLA=explode(' And',$lines[0]);
					  $causT1=$fLA[0];
					  $pt1=$fLA[1];
		 }
		 
		 
		 
		 
		 if(substr($lines[1],0,2)=='  ')
		 {
		    $causT2=$lines[1];
		 }else
		 {
		   $pt2=$lines[1];
		   $causT2=$lines[2];
		 
		 }
		 
		$case['CAUSE TITLE']=trim("$causT1 Vs $causT2");
		$case['PTNR']=trim("$pt1 $pt2");
		 
		
	
	}
	
  
  
 return $case;
  
	
	
   
 }
function filterAndWriteData(&$extractData,$caseKEY)
{

  
 global $os;
 
 $os->finalArrCombined[$caseKEY]=$extractData;
  if(is_array($os->xlsFile))
  {
       
	   foreach($os->xlsFile as $k=>$xData)
	   {
	   
				 if(is_array( $xData))
				 {
						 for($i=1;$i<=21;$i++)
							  {
								 if(!isset($xData[$i]))
								 {
									   $xData[$i]='';
								 
								 }
							   }
				
				 
				  ksort($xData);
				  $xData[]='';
				 }
				
		
		
		 ### search case no 
		 $caseNoExist=false;
		 if($xData[5]!='')
		 {
		    
		    
					    //_d($extractData['CASE NO']);  _d($xData[5]);
						// echo '<br>-------------------------------------------------------<br>';
						
						$xcelCaseNoA=explode("\n",$xData[5]);
						
						if(is_array($xcelCaseNoA))
						{
							
						   foreach($xcelCaseNoA as $xcelCaseNo)
						   {	
								 
								 //  preg_match_all("/[A-Z]+\d*\/\d+\s/", $xcelCaseNo, $xcelCaseNoM);
								  // $xcelCaseNo=	$xcelCaseNoM[0][0];
								//   _d($xcelCaseNoM);
									
								$xcelCaseNoSingle=str_replace('(PT)','',$xcelCaseNo); 										
							     	
								if($extractData['CASE NO']!='' && $xcelCaseNoSingle!='')
								{
									if( strpos($extractData['CASE NO'],$xcelCaseNoSingle)!==false)
									{
										//echo $xcelCaseNo.'.....'.$xcelCaseNoSingle.'..........<br>';		
										$caseNoExist=true;
									}
								}
								
								
							}
					    }
		  
						 
						 
						 
						 
						 
						  if( $caseNoExist==true)
						  {
							   
							// echo $k.". ". $extractData['CASE NO'].'---'.$xData[5].'<br>';
							  $xData[2]=$extractData['ITEM NO.'];//  item no
							//  $xData[3]=$os->causeDate;//  
							  
							  $xData[8]=$extractData['COURT'];//  court no
							  $xData[22]=trim($extractData['PTNR']);
							  
							
							  fputcsv($os->fpOutputFiltered , $xData);//  put values
							  
							  
							  ## storing combined data ##
							  							
							  ##  ========= storing combined data end =========== ##
							
							   
							   $os->finalArrCombined[$caseKEY]['DATE']=$xData[3];
							   $os->finalArrCombined[$caseKEY]['AOR']=$xData[4];
							   $os->finalArrCombined[$caseKEY]['IND']=$xData[7];
							   $os->finalArrCombined[$caseKEY]['ERSTWHILE ADVOCATE']=$xData[9];
							   $os->finalArrCombined[$caseKEY]['ALLOTMENT TO A.O.R.']=$xData[10];
							   $os->finalArrCombined[$caseKEY]['COUNSEL - 1']=$xData[11];
							   $os->finalArrCombined[$caseKEY]['CONTACT 1']=$xData[12];
							   $os->finalArrCombined[$caseKEY]['ADDRESS']=$xData[13];
							   $os->finalArrCombined[$caseKEY]['COUNSEL - 2']=$xData[14];
							   $os->finalArrCombined[$caseKEY]['CONTACT 2']=$xData[15];
							   $os->finalArrCombined[$caseKEY]['ADDRESS2']=$xData[16];
							   $os->finalArrCombined[$caseKEY]['COUNSEL - 3']=$xData[17];
							   $os->finalArrCombined[$caseKEY]['CONTACT 3']=$xData[18];
							   $os->finalArrCombined[$caseKEY]['ADDRESS3']=$xData[19];
							   $os->finalArrCombined[$caseKEY]['REMARKS']=$xData[20];
							   $os->finalArrCombined[$caseKEY]['TIME']=$xData[21];
							  
							  //$os->finalArrCombined[$caseKEY]
						  }
						  // fputcsv($os->fpOutputConbined , $xData);//  put values
						  
		   }
		  
		  else{
							  
							/*   temporarily it is off
							  
							   $ct=explode('Vs',$extractData['CAUSE TITLE']);
							   $sKey= $ct[1];
							   
								
							
								$fKey= explode(',',$os->excelFilterKey);
								if(is_array($fKey)&& count($fKey)>0)
								{
								 
								 foreach($fKey as $fK)
								 {
								   $fK=strtoupper($fK);
								  
							 
									  if(strpos($ct[1],$fK)!==false)
										   {
											   $sKey=$ct[0];
										   }
							   
							 
								  if( strpos($xData[6],$sKey)!==false)
								  {
								  
									  $xData[2]=$extractData['ITEM NO.'];//  item no
									  $xData[3]=$os->causeDate;//  item no
									  $xData[8]=$extractData['COURT'];//  court no
									  $xData[22]=$extractData['PTNR'];
									  fputcsv($os->fpOutputFiltered , $xData);//  put values
								  
								  }
								  }
							
								   
							   }
							  
							 */ 
							  
			 }
		  
		  
		  
		  
		  
		 
	     
		
	   
	   }
	   
	   
  }

/*

  $colVals=array($os->caseCount,$itemNo,'-','-',$cV['CASE NO'],$cV['CAUSE TITLE'],'-',$courtNO,'-','-','-','-','-','-','-','-','-','-','-','-','-');
  fputcsv($os->fpOutput , $colVals);//  put values
  $os->xlsFile 		
  */   
 // _d($extractData);

}

    
function getItemsNo($val)
{   
      $finalItems=array();
	  
	 
      preg_match_all("/ITEM .*?MONTHLY LIST/", str_replace("\n",',',$val), $monthlyMatches);
	 
	  
	  
	  
	  if(is_array($monthlyMatches[0]))
	  {
	  
	    foreach($monthlyMatches[0] as $cc=>$items)
		{
		
		  if($items!='')
		  {
				$items=str_replace("\n",',',$items);
				$replaceBlank=array('MONTHLY LIST','FROM THE ','OF THE','COMBINED','ITEM', 'NOS.','NO.','.');
				$itemStr=str_replace( $replaceBlank,'', $items);  
				
				$itemStr=str_replace( array('AND','TO'),array(',','-'), $itemStr); // general format
		  	// _d($itemStr); #5656
				
				
				
				$itemStrA=preg_match_all('/[0-9]+.?-.?[0-9]+/',$itemStr,$itemRange);
				$itemStr=str_replace( $itemRange[0],'', $itemStr); // general format
				
		  // _d($itemRange);
		   #---------------$itemRange extract ----------------
	
		   foreach($itemRange[0] as $itemRangeStr)
		   {
		    $itemRangeStrA=explode('-',$itemRangeStr);
			
		    $itemRangeA=range($itemRangeStrA[0],$itemRangeStrA[1]);
		    foreach($itemRangeA as $v)
			{
			 $finalItems[]= $v;
			} 
			 
		
		   }
		   
		   
		   
		   
		   
		   $itemStr=str_replace(' ',',',$itemStr);
		   $itemStrA=preg_match_all('/[0-9]+/',$itemStr,$itemSingles);
		    foreach($itemSingles[0] as $v)
			{
			 $finalItems[]= $v;
			} 
		   
		
		   
		   
		 }
		 }
		 
		// _d($items);
	   // _d($finalItems);
	  
	  }
	 
	  return $finalItems;
	 

}
 
//$p=$os->getInnerContent($startkey,$endKey,$str);


?>

<? 
//$fString = file_get_contents('http://causelists.nic.in/calcutta/org/cl.html');
//http://localhost/Excel-converter/wtos/sample.html
?>