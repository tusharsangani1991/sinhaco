<?php
//ini_set();
set_time_limit(0);
include('includes/config.php');
include('top.php');


// config 
$rowId=$_GET['editRowId'];

$listPAGE='loadMonthlyList';
$primeryTable='monthlylist';
$primeryField='monthlylistId';
$editHeader='LOAD MONTHLY CAUSELIST';


##  update row
if(varP('operation'))
{

	
	
	
	 if(varP('operation')=='updateField')
	 {
	
	  #---- edit section ----# 	 
			
	  $dataToSave['title']=varP('title');
	  $dataToSave['urlLink']=varP('urlLink');
	  $dataToSave['month']=varP('month');
	  $dataToSave['adedDate']=date('ymdhis');
	  
	  
	    include('tuning.php');
        $fString=getFile($dataToSave['urlLink']);
	
	$strArr=preg_split("/COURT NO\./", $fString);
    if(is_array($strArr))
    {
	$delM=$dataToSave['month'];
	mysql_query("delete from $primeryTable where month='$delM' ");
   foreach($strArr as $val)
   {
   

   
   $courtNO =(int)$val; 
   if($courtNO<1)
         continue;
		 
     $floorA = explode("\n",$val);
	 $floor =$floorA['1'];
	 $cases=	 preg_split('/\n(\d+)\.\s/', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
		 if(is_array($cases))
		 {
					foreach($cases as $cvK=>$casesVal)
					{
					    $itemNo=(int)$cases[$cvK-1];
					   
					 
					   
					    $cV=extractCaseVal($casesVal);
						
						 	 	 	 	
						 
						
						 if($itemNo>0)
						 {
						 //  echo "  courtNO $courtNO   itemNo $itemNo <br>";
						 $dataToSave['itemNo']=$itemNo;		
						 $dataToSave['courtNo']=$courtNO;		
						 $dataToSave['caseNo']=$cV['CASE NO'];
						 $dataToSave['causeTitle']=addslashes($cV['CAUSE TITLE']);
						 $dataToSave['PTNR']=addslashes($cV['PTNR']);
						 $dataToSave['dataStr']=addslashes($casesVal);		
					     $os->save($primeryTable,$dataToSave,$primeryField,$rowId);
						 
						 }
					   
					}
				}
	 
	 
	 
	
	  
    
   
   }
 
 
 }
 
	
	
	
	
			  
	
	  $flashMsg=($rowId)?'Record Updated Successfully':'Record Added Successfully';
	 
	  #---- edit section end ----#
	
	 }
	 
	
	
}


// get row data
if($rowId)
  {
        
	   $where="$primeryField='$rowId'";
		$pageData=$os->getT($primeryTable,'',$where);
		
		
		if(isset($pageData[0]))
		{
		  $pageData=$pageData[0];
		}
        
  }




$admintypes=array('Admin'=>'Admin','Super Admin'=>'Super Admin');
$adminAccess=array('0'=>'No','1'=>'Yes');

$dM=date('m/Y');
$dMA=$os->getT($primeryTable,' count(*) cc',"month='$dM'");
 

?>

<table class="container">
  <tr>
    <td width="243" class="leftside"><?php  include('osLinks.php'); ?>
    </td>
    <td class="middle" style="padding-left:5px;"><div class="formsection">
        <h3>
          <?php  echo $editHeader; ?>
        </h3>
        <form  action="<? echo $listPAGE ?>.php" method="post"   enctype="multipart/form-data">
          <fieldset class="cFielSet"  >
          <legend  class="cLegend"> INPUT DETAILS</legend>
          <table border="0" class="formClass"   >
            <tr >
              <td>Title : </td>
              <td><input value="MONTHLY CAUSELIST <? echo date('m-Y'); ?> " type="text" name="title" class="textbox fWidth" style="width:250px;" /></td>
              <td>Month</td>
              <td><input value="<? echo $dM; ?>" type="text" name="month" class="textbox fWidth" readonly="1"/> mm/yyyy  
			 
			  
			  
			              </td>
            </tr>
            <tr >
              <td>URL Link : </td>
              <td colspan="3"><input value="http://causelists.nic.in/calcutta/monthly/cl.html" type="text" style="width:290px;" name="urlLink" class="textbox fWidth" />
			   	 <?  if($dMA[0]['cc']>0) { ?>
		         <span style="color:#00CC00; font-size:9px;"> ALREAY LOADED</span>
		         <? } 
				  echo '<font style="color:#006600; font-weight:bold">'.$flashMsg.'</font>';
				 ?> 
			  
			  </td>
            </tr>
			 
			
			
         
          </table>
          </fieldset>
          
		<?   if($dMA[0]['cc']>0) { ?>
		<input type="submit" class="submit"  value="RELOAD MONTHLY LIST" style="color:#FF0000; font-weight:bold;" />
        <? 	  } else{   ?> 
		  <input type="submit" class="submit"  value="LOAD MONTHLY LIST" />
		  <? } ?>
		  
		  
          <input type="button" class="submit"  value="Cancel" 
									onclick="javascript:window.location='<? echo $listPAGE ?>.php';" />
          <input type="hidden" name="operation" value="updateField" />
		  <? if($dataToSave['excelDownload']!=''){ ?>
		  
		 <!--  <input type="hidden" name="xLoad" value="down" />
		    <input type="hidden" name="xURL" value="<? echo $outFileName ?>" />-->
		
		
		<a style="text-decoration:none"  href="?xLoad=down&xURL=<? echo $outFileName ?>"> <input type="button" class="submit"  value="DOWNLOAD SEARCH DATA" style="color:#FF0000; font-size:14px; font-weight:bold; text-decoration:none; cursor:pointer;" />  </a>
		<a style="text-decoration:none"  href="?xLoad=downF&xURL=<? echo $outFileNameFiltered ?>"> <input type="button" class="submit"  value="DOWNLOAD FILTERED DATA" style="color:#1C460D; font-size:14px; font-weight:bold; text-decoration:none; cursor:pointer;" />  </a>
		
		
		 <!-- <a style="text-decoration:none"  href="<? echo $site['url'].$dataToSave['excelDownload'] ?>"> <input type="button" class="submit"  value="DOWNLOAD EXCEL" style="color:#FF0000; font-size:14px; font-weight:bold; text-decoration:none; cursor:pointer;" />   </a>	-->	   
		  <? } ?>
		  
        </form>
		<table width="200" border="0">
		  <tr>
			<td><!--<a  href="<? echo $site['url'].$dataToSave['excelDownload'] ?>"> <img src="<?php echo $site['url']?>image/download.jpg" alt="" width="70" height="40" style="  border:none;"/>  </a>--></td>
		  </tr>
		</table>
      </div></td>
  </tr>
</table>



<? include('bottom.php')?>
