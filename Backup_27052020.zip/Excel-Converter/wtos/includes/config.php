<?php 
set_time_limit (0);
$site['droot']=$_SERVER[DOCUMENT_ROOT];

if($_SERVER['SERVER_ADDR']!='127.0.0.1')
{  
    $site['root']=$site['droot']."/Excel-Converter/wtos/";
	$site['host']="localhost";
	$site['user']="sinha";
	$site['pass']="sinha#";
	$site['db']="excel_converter";
	$site['url']="http://sinhaco.com/Excel-Converter/wtos/";
	
	$site['imgPath']=$site['droot']."/Excel-Converter/wtos/";

	
	
	$site['theme']='wtos-theme';
	$site['themePath']=$site['url'].$site['theme']."/";
	$site['urlFront']=" ";
	$site['indexUrl']=$site['url'];



}
else
{

	$site['root']=$site['droot']."/Excel-Converter/wtos/";
	$site['host']="localhost";
	$site['user']="root";
	$site['pass']="";
	$site['db']="excel_converter";
	$site['url']="http://localhost/Excel-Converter/wtos/";
	
	
	$site['imgPath']=$site['droot']."/Excel-Converter/wtos/";

	
	
	$site['theme']='wtos-theme';
	$site['themePath']=$site['url'].$site['theme']."/";
	$site['urlFront']=" ";
	$site['indexUrl']=$site['url'];
}


$site['defaultLanguage']="English"; #English
$site['classes']=$site['root'].'classes';
$site['language']=$site['root'].'language';
$site['loginKey']='wtos-key-excel';

function inclPath($dir='')
{
  global $site;
  $dir=($dir!='')?$site[$dir]:$site['root'];
  return $dir;
}

$site['siteTitle']='SINHA & COMPANY ';
$site['siteHeading']='ADMINISTRATION';



?>