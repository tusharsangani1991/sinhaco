<?php
 
if($_GET['xLoad']=='down')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}
if($_GET['xLoad']=='downF')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}
if($_GET['xLoad']=='downC')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}
if($_GET['xLoad']=='downC2')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}


if($_GET['xLoad']=='downN')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}


if($_GET['xLoad']=='downF')
{


	header('Content-Type: application/csv');
	header('Content-Disposition: attachment; filename='.$_GET['xURL']);
	header('Pragma: no-cache');
	echo readfile('wtos-excelDownload/'.$_GET['xURL']);
	exit();
}



include('includes/config.php');
include('top.php');


// config 
$rowId=$_GET['editRowId'];

$listPAGE='excelConvert';
$primeryTable='excelconvert';
$primeryField='excelConvertId';
$editHeader='CAUSELIST EXTRACTOR';


##  update row
if(varP('operation'))
{

	 if(varP('operation')=='updateField')
	 {
	
	  #---- edit section ----# 	 	 	 	 		 	
	  $dataToSave['title']=varP('title');
	  $dataToSave['date']=varP('date');
	  
	  $dataToSave['urlLink']=varP('urlLink');
	  $dataToSave['searchKey']=varP('searchKey');
	  $dataToSave['filterKey']=varP('filterKey');
	  $os->excelFilterKey=$dataToSave['filterKey'];
	  
	  $outFileName=date("d-m-y-h-i-s")."_".'causelist'.'.csv';
	  $dataToSave['excelDownload']= 'wtos-excelDownload/'.$outFileName;
	  
	  $outFileNameFiltered=date("d-m-y-h-i-s")."_".'causelistFiltered'.'.csv';
	  $dataToSave['excelDownloadFiltered']= 'wtos-excelDownload/'.$outFileNameFiltered;
	  
	  $outFileNameConbined=date("d-m-y-h-i-s")."_".'causelistAll'.'.csv';
	  $dataToSave['excelDownloadConbined']= 'wtos-excelDownload/'.$outFileNameConbined;
	  
	  $outFileNameConbined2=date("d-m-y-h-i-s")."_".'causelistAll2'.'.csv';
	  $dataToSave['excelDownloadConbined2']= 'wtos-excelDownload/'.$outFileNameConbined2;
	  
	  
	  
	  $dataByExCaseNo=date("d-m-y-h-i-s")."_".'dataByExCaseNo'.'.csv';
	  $dataToSave['dataByExCaseNo']= 'wtos-excelDownload/'.$dataByExCaseNo;
	  
	  
	  $finalRecord=date("d-m-y-h-i-s")."_".'finalRecord'.'.csv';
	  $dataToSave['finalRecord']= 'wtos-excelDownload/'.$finalRecord;
	 
	
	 
	 
	 
	 
	  $fname = $site['imgPath'].$dataToSave['excelDownload'];
	 // $fp = fopen($fname,'w');
	  
	  $excelFile=$os->UploadPhoto('excelFile',$site['imgPath'].'wtos-excelUpload');
	  	    
	  if($excelFile!='')
	  {
	  	$dataToSave['excelFile']='wtos-excelUpload/'.$excelFile;
	  }
	  
	  ##------------------- exel to array ------------------##
	  
  	  
	   // $fn=$_FILES['excelFile']['tmp_name']; 
		$fn=$dataToSave['excelFile'];
		
		//require_once 'xcelReader/reader.php';
		
		
		
         $os->causeDate=$dataToSave['date'];
         include('tuning.php');
        $fString=getFile($dataToSave['urlLink']);
		
		$colnameSearch=array('SL NO.','ITEM NO.','DATE','CASE NO','CAUSE TITLE','COURT','LAWYER');
		
		$colnameCombined2=array('SL NO.','ITEM NO.','CASE NO','CAUSE TITLE','COURT','ALLOTMENT TO A.O.R.','COUNSEL - 1','COUNSEL - 2','LAWYER');
		$colnamefINAL=array('ITEM NO.','CASE NO','CAUSE TITLE','COURT','ALLOTMENT TO A.O.R.','COUNSEL - 1','COUNSEL - 2','COUNSEL - 3','LAWYER','SL NO.');
		
			
		
		$colname=array('SL NO.','ITEM NO.','DATE','AOR','CASE NO','CAUSE TITLE','IND','COURT','ERSTWHILE ADVOCATE','ALLOTMENT TO A.O.R.','COUNSEL - 1','CONTACT 1','ADDRESS','COUNSEL - 2','CONTACT 2','ADDRESS','COUNSEL - 3','CONTACT','ADDRESS','REMARKS','TIME','LAWYER');
		
		    #$fc=parseExcel($fn,$colname); // not need due to input field is text box
			#if(isset($fc[0])){ unset($fc[0]);}
		$fc=explode(',',$dataToSave['searchKey']);
	
		if(is_array($fc))
		{
		
		    
			 # parse excel file 
			 $os->readXLS($dataToSave['excelFile']); //output  $os->xlsFile 
	    
		 	 $os->fpOutputFiltered = fopen($dataToSave['excelDownloadFiltered'], 'w');
			 fputcsv($os->fpOutputFiltered , $colname);//  put columns
			 
			 $os->fpOutputConbined = fopen($dataToSave['excelDownloadConbined'], 'w');
			 fputcsv($os->fpOutputConbined , $colname);//  put columns
			 
			 $os->fpOutputConbined2 = fopen($dataToSave['excelDownloadConbined2'], 'w');
			 fputcsv($os->fpOutputConbined2 , $colnameCombined2);//  put columns
			 
			 
			 
			 $os->dataByExCaseNo = fopen($dataToSave['dataByExCaseNo'], 'w');
			 fputcsv($os->dataByExCaseNo , $colnameCombined2);//  put columns
			 
			 $os->finalRecord = fopen($dataToSave['finalRecord'], 'w');
			 fputcsv($os->finalRecord , $colnamefINAL);//  put columns
			 
			 
			   
			 
			 
			 
			
		     $os->fpOutput = fopen($dataToSave['excelDownload'], 'w');
			 fputcsv($os->fpOutput , $colnameSearch);//  put columns
		   
		   
		   $os->caseCount=1;
		   $os->finalArr=array();
		   $os->finalArrCombined=array();
		  
		  foreach($fc as $k=>$val)
		  { 
		      $val=strtoupper($val);
			  
		       tuneSearch($val,$fString);
			
		   
		  }
		  
		 
		 
		  
		 
		  
		  
		  #--- get output, sort  and write to file 
		  
		  if( count($os->finalArr)>0)
		  {
		     $ijk=1; 
			 
			 $finalArr= $os->multySort($os->finalArr,'COURT','ASC','ITEM NO.','ASC');
		
		    
			 foreach( $finalArr as $op)
			 {
				 $colVals=array($ijk,$op['ITEM NO.'],$os->causeDate,$op['CASE NO'],$op['CAUSE TITLE'],$op['COURT'],$op['PTNR']);
				 fputcsv($os->fpOutput , $colVals);//  put values
				 $ijk++;
			 }
		  
		  
		  }
		  
		    #--- get output combined , sort  and write to file 
		
		 
		 if( count($os->finalArrCombined)>0)
		  {
		     $ijk=1; 
			 
			 $finalArrCombined= $os->multySort($os->finalArrCombined,'COURT','ASC','ITEM NO.','ASC');
		    
			 foreach( $finalArrCombined as $op)
			 {
				 
				  if($op['DATE']==''){$op['DATE']=$os->causeDate;}  			 
				 
				 $colVals=array($ijk,$op['ITEM NO.'],$op['DATE'],$op['AOR'],$op['CASE NO'],$op['CAUSE TITLE'],$op['IND'],$op['COURT'],
								 $op['ERSTWHILE ADVOCATE'],$op['ALLOTMENT TO A.O.R.'],$op['COUNSEL - 1'],$op['CONTACT 1'],$op['ADDRESS'],$op['COUNSEL - 2'],
								 $op['CONTACT 2'],$op['ADDRESS2'],$op['COUNSEL - 3'],$op['CONTACT 3'],$op['ADDRESS3'],$op['REMARKS'],$op['TIME'],$op['PTNR']);
				 fputcsv($os->fpOutputConbined , $colVals);//  put values
				
				$colValsC=array($ijk,$op['ITEM NO.'],$op['CASE NO'],$op['CAUSE TITLE'],$op['COURT'],$op['ALLOTMENT TO A.O.R.'],$op['COUNSEL - 1'],$op['COUNSEL - 2'],$op['PTNR']);
				 fputcsv($os->fpOutputConbined2 , $colValsC);//  put values
				
				
				
				 $ijk++;
			 }
		  
		  
		  }
		  
		 
		 // exit();
		   /* get data matching with case no of xls   787 */ 
						 
						 
					$os->casesByExcelCaseNo=array();
					$os->getDataByExelCaseNo($os->xlsFile,$fString );
					## marge extra data to combined array 
					
					 
					$os->margeCombinedAndDataByExelCaseNo($os->finalArrCombined, $os->casesByExcelCaseNo);
					
		 
		  
		  /* end; 787 */ 
		 
		 ## out put not matched data
		
		  if( count($os->notMatchedData)>0)
		  {
		     $ijk=1; 
			 
			 $notMatchedData= $os->multySort($os->notMatchedData,'COURT','ASC','ITEM NO.','ASC');
		    
			 foreach( $notMatchedData as $op)
			 {
				 
				  if($op['DATE']==''){$op['DATE']=$os->causeDate;}  			 
				 
							
				$colValsC=array($ijk,$op['ITEM NO.'],$op['CASE NO'],$op['CAUSE TITLE'],$op['COURT'],$op['ALLOTMENT TO A.O.R.'],$op['COUNSEL - 1'],$op['COUNSEL - 2'],$op['PTNR']);
				 fputcsv($os->dataByExCaseNo , $colValsC);//  put values
				
				
				
				 $ijk++;
			 }
		  
		  
		  }
		  
		  # not matched +matched data
		  
		 if( count($os->notMatchedPlusMatchedData)>0)
		  {
		     $ijk=1; 
			 
			 $notMatchedPlusMatchedData= $os->multySort($os->notMatchedPlusMatchedData,'COURT','ASC','ITEM NO.','ASC');
		    
			 foreach( $notMatchedPlusMatchedData as $op)
			 {
				 
				  if($op['DATE']==''){$op['DATE']=$os->causeDate;}  			 
				 
							
				$colValsC=array($op['ITEM NO.'],$op['CASE NO'],$op['CAUSE TITLE'],$op['COURT'],$op['ALLOTMENT TO A.O.R.'],$op['COUNSEL - 1'],$op['COUNSEL - 2'],$op['COUNSEL - 3'],$op['PTNR'],$ijk);
				 fputcsv($os->finalRecord , $colValsC);//  put values
				
				
				
				 $ijk++;
			 }
		  
		  
		  }
		  
		 
		  
		
		 // _d($os->finalArrCombined);
		  
		#--#
		  
			fclose($os->fpOutput);
			fclose($os->fpOutputFiltered);
			fclose($os->fpOutputConbined);
			
			fclose($os->dataByExCaseNo);
			fclose($os->finalRecord);
		 
						
		}
			
  	  ##------------------- exel to array ------------------##
		  
	  $os->save($primeryTable,$dataToSave,$primeryField,$rowId);
	  $flashMsg=($rowId)?'Record Updated Successfully':'Record Added Successfully';
	 
	  #---- edit section end ----#
	
	 }
	 
	
	
}


// get row data
if($rowId)
  {
        
	   $where="$primeryField='$rowId'";
		$pageData=$os->getT($primeryTable,'',$where);
		
		
		if(isset($pageData[0]))
		{
		  $pageData=$pageData[0];
		}
        
  }




$admintypes=array('Admin'=>'Admin','Super Admin'=>'Super Admin');
$adminAccess=array('0'=>'No','1'=>'Yes');
?>

<table class="container">
  <tr>
    <td width="243" class="leftside"><?php  include('osLinks.php'); ?>
    </td>
    <td class="middle" style="padding-left:5px;"><div class="formsection">
        <h3>
          <?php  echo $editHeader; ?>
        </h3>
        <form  action="<? echo $listPAGE ?>.php" method="post"   enctype="multipart/form-data" onsubmit="return checkKey();">
          <fieldset class="cFielSet"  >
          <legend  class="cLegend"> INPUT DETAILS</legend>
          <table border="0" class="formClass"   >
            <tr >
              <td>Title : </td>
              <td><input value="CAUSELIST  " type="text" name="title" class="textbox fWidth" />
              </td>
              <td>Date:</td>
              <td><input value="<? echo date('d/m/Y'); ?>" type="text" name="date" class="textbox fWidth" />
              </td>
            </tr>
            <tr >
              <td>URL Link : </td>
              <td colspan="3">
			  <input value="http://causelists.nic.in/calcutta/org/cl.html" type="text" style="width:360px;" name="urlLink" class="textbox fWidth" />
			 <!-- file:///D:/wamp/www/Excel-Converter/reproblem/CAUSELIST-04.04.12.htm
			  http://causelists.nic.in/calcutta/org/cl.html
			  file:///D:/wamp/www/Excel-Converter/chcl.htm
			  
			  -->
			  
			  
			  
			  </td>
            </tr>
			 <tr >
              <td valign="top">Search Key : </td>
              <td colspan="3"><input value="STATE OF WEST BENGAL,STATE OF W.B" type="text" style="width:360px;" name="searchKey" id="searchKey" class="textbox fWidth" />
			  <br />
			  <span style="font-size:9px; color:#666666;"> Enter multiple keyword seperated by comma(,)    </span>
			  </td>
            </tr>
			
			<!-- <tr >
              <td valign="top">Filter Key : </td>
              <td colspan="3"><input value="" type="text" style="width:290px; background:#C4C4C4;" name="filterKey" id="filterKey" class="textbox fWidth" readonly="1" />
			  <br />
			  <span style="font-size:9px; color:#666666;"> Enter multiple filter keyword seperated by comma(,)    </span>
			  </td>
            </tr>-->
			
			 <tr >
            <td>Excel File : </td>
              <td colspan="3"><input type="file"  name="excelFile" />
              </td>
            </tr>
          </table>
          </fieldset>
          <input type="submit" class="submit"  value="Submit" />
          <input type="button" class="submit"  value="Cancel" 
									onclick="javascript:window.location='<? echo $listPAGE ?>.php';" />
          <input type="hidden" name="operation" value="updateField" />
		  
		  <br /><br />
		  <? if($dataToSave['excelDownload']!=''){ ?>
		  
		 <!--  <input type="hidden" name="xLoad" value="down" />
		    <input type="hidden" name="xURL" value="<? echo $outFileName ?>" />-->
		
		<style >
		.btn1{
		color:#FF0000; font-size:11px;  text-decoration:none; cursor:pointer; background:#E0E0E0; border:1px solid #FF0000; margin:0 2px 0 2px;padding:0 2px 0 2px;
		font-weight:bold;
		
		}
		.btn1:hover
{
 color:#FFFFFF; font-size:11px;  text-decoration:none; cursor:pointer; background:#FA261B; border:1px solid #FF0000; margin:0 2px 0 2px;padding:0 2px 0 2px;
 font-weight:bold;
 
}
.btn2{
	color:#1C460D; font-size:11px;  text-decoration:none; cursor:pointer;background:#E0E0E0; border:1px solid #333333; margin:0 2px 0 2px;padding:0 2px 0 2px;
		
		}
		.btn2:hover
{
 color:#FFFFFF; font-size:11px;  text-decoration:none; cursor:pointer;background:#28772B; border:1px solid #000000; margin:0 2px 0 2px;padding:0 2px 0 2px;
 
}
		</style>
		
		
		
		
		<a style="text-decoration:none"  href="?xLoad=down&xURL=<? echo $outFileName ?>"> 
		<span  class="btn2" > SEARCH DATA</span> 
		
			
		</a>
		
		
		
		<a style="text-decoration:none"  href="?xLoad=downF&xURL=<? echo $outFileNameFiltered ?>"> 
	<span  class="btn2"  > FILTERED DATA</span> 
		  </a>
		  <a style="text-decoration:none"  href="?xLoad=downC&xURL=<? echo $outFileNameConbined ?>"> 
	<span  class="btn2"  > SEARCH+FILTERED DATA 1</span> 
		  </a>
		  
		   <a style="text-decoration:none"  href="?xLoad=downC2&xURL=<? echo $outFileNameConbined2 ?>"> 
	<span  class="btn2"  > SEARCH+FILTERED DATA 2</span> 
		  </a>
		  
		  
		  <a style="text-decoration:none"  href="?xLoad=downN&xURL=<? echo $dataByExCaseNo ?>"> 
	<span  class="btn2"  > NOT MATCHED DATA</span> 
		  </a>
		  
		   <a style="text-decoration:none"  href="?xLoad=downF&xURL=<? echo $finalRecord ?>"> 
	<span  class="btn1"> FINAL DATA<span style="font-size:9px">(SEARCH+FILTERED+NOT MATCHED)</span> </span> 
		  </a>
		
		
		 <!-- <a style="text-decoration:none"  href="<? echo $site['url'].$dataToSave['excelDownload'] ?>"> <input type="button" class="submit"  value="DOWNLOAD EXCEL" style="color:#FF0000; font-size:14px; font-weight:bold; text-decoration:none; cursor:pointer;" />   </a>	-->	   
		  <? } ?>
		  
        </form>
		<table width="200" border="0">
		  <tr>
			<td><!--<a  href="<? echo $site['url'].$dataToSave['excelDownload'] ?>"> <img src="<?php echo $site['url']?>image/download.jpg" alt="" width="70" height="40" style="  border:none;"/>  </a>--></td>
		  </tr>
		</table>
      </div></td>
  </tr>
</table>
<script>
function checkKey()
{
 
  if(os.check.empty('searchKey','Keyword Missing')==false){return false;}
  return true;
 

}
</script>


<? include('bottom.php')?>
