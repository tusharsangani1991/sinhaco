<?
include(inclPath('classes').'/sm.php');
function varP($key)
{
  $postval='';
  if(isset($_POST[$key]))
  {
     $postval=str_replace('m#m','&',$_POST[$key]);
  }
  return $postval;
  
}

function varG($key)
{
  $getval='';
  if(isset($_GET[$key]))
  {
     $getval=$_GET[$key];
  }
  return $getval;
  
}

function tinyMce()
{
  include('tinyMCE.php'); 
}



class os extends sm 
{

function getInnerContent($startkey,$endKey,$str)
{
   $rs='NO RESULTS';
   $ex='(.*?)';
  echo  $rex ="/$startkey $ex $endKey/";
   
      if(preg_match_all($rex , $str, $matches))
  {
   if($matches[0]!='')
   {
     unset($matches[0]);
   }
   $rs= $matches;
  }
 
   
   
   return $rs;

}

 
function readXLS($file)
{
   
	if($file==''){return; }
	$this->xlsFile=array();
	require_once 'Excel/reader.php';
	$dataX = new Spreadsheet_Excel_Reader();
	$dataX->setOutputEncoding('CP1251');
	$dataX->read($file); // uploaded excel file
	
	
		for ($RowsNu = 2; $i <= $dataX->sheets[0]['numRows']; $RowsNu++)
		{ 
		
			if($dataX->sheets[0]['cells'][$RowsNu][1]!='')
			{
				$this->xlsFile[]=$dataX->sheets[0]['cells'][$RowsNu];
			}
			
			if($dataX->sheets[0]['cells'][$RowsNu][1]=='')
			{
		 		return;
			}
		}	 
	
	
}

  
	 function multySort($data=NULL,$field=NULL,$order='ASC',$field2=NULL,$order2='ASC')  # custom array multy sort  $this->multySort($cases,'id',$order='ASC');
			{
	
		if(is_array($data) && count($data)>0 && $field!=NULL )
		{
			
			
			foreach ($data as $key => $row) 
			{
				$temp[$key]  = (int)$row[$field];
				$temp2[$key]  = (int)$row[$field2];
			}
			
			
			
			
			if($order=='DESC')
			{
				array_multisort($temp, SORT_DESC, $data);
			}
			else
			{
				array_multisort($temp, SORT_ASC,$temp2, SORT_ASC, $data);
			}
			
			
			return $data;
			
			}
		return $data;
	
	}
	
	 function multySortNOTUsed($data=NULL,$field=NULL,$order='ASC',$field2=NULL,$order2='ASC')  # custom array multy sort  $this->multySort($cases,'id',$order='ASC');
			{
	
		if(is_array($data) && count($data)>0 && $field!=NULL )
		{
			
			
			foreach ($data as $key => $row) 
			{
				$temp[$key]  = (int)$row[$field];
				//$temp2[$key]  = (int)$row[$field2];
			}
			
			
			
			
			if($order=='DESC')
			{
				array_multisort($temp, SORT_DESC, $data);
			}
			else
			{
				array_multisort($temp, SORT_ASC, $data);
			}
			
			
			return $data;
			
			}
		return $data;
	
	}
	
	
	function getDataByExelCaseNo($xlsFile, &$urlString )
	{
	   /// take too much timme to search
	
	
	 	global $os;
	
	
	
	if(is_array($xlsFile ))
     	{
       
	   
	 
	   $klm=99999;
	   
	   foreach($xlsFile  as $k=>$xData)
	       {
	
		 ### search by  case no 
					 if(trim($xData[5])!='')
			          {
										  ###   duplicate of tune search 333 ##
						  //  $pC=explode('\n',$xData[5]);
						//	_d( $p);
						
						
						  preg_match_all("/[A-Z].*?\d+\/\d+/", $xData[5], $xcelCaseNoM); ## WP 588/2011  /[A-Z]+\s\d+\/\d+\s/   /[A-Z]* \d*\/\d+\s/
								  $pC=	$xcelCaseNoM[0];
							
							if(is_array($pC))
							foreach($pC as $caseNoSplited)
							{ # 987987
							
							   $keys=$caseNoSplited; 
							//   echo "$keys  <br>";
							   
							//  echo '--<br>--';
							     // search for each case no 
							
							     								  
																  
																  
											
										if($keys==''){return ;}
										
											$startkey='COURT NO';
											$endKey='COURT NO';
											$str=$urlString;
											$strArr2=array();
																				
											 $strArr=preg_split("/COURT NO\./", $str,-1);
											 
											 if(is_array($strArr))
											 {
											   foreach($strArr as $val)
											   {
											   
											  // echo '<br>-------------------------------------------++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++--------------------------------------';
											  //  _d('888-'.$val);
											
											   
											   $courtNO =(int)$val; 
											   
											  // echo $courtNO.'<br>';
											   if($courtNO<1)
													 continue;
													 
												 $floorA = explode("\n",$val);
												 $floor =$floorA['1'];
													 
												#--- search string -----##
												 $foundStr=false;
												
														/* 444444444444  
														if($courtNO==7)
														{
														_d($itemsNo);
														echo $os->q;
														_d($mList);
														//exit();
														}
														444444444444444   */
												
												 
												 $fStr=strpos($val,$keys);
												 if( $fStr!==false ){$foundStr=true;}  // first step quick serch 
												  
												 $fStr2=strpos(str_replace("\n",'',$val),$keys);
												 if( $fStr2!==false ){$foundStr=true;}  // first step quick serch // serch also key separated by newline
												  
												  #-----  monthly data search
												 
												  $itemsNo= getItemsNo($val); // 2012-01-24
												  
												  
												  $mList=array();	
												  $dM=date('m/Y'); 
												  if(is_array($itemsNo) && count($itemsNo)>0)
												  {
												   $andItemNo='and  itemNo IN ('.implode(',',$itemsNo).' )   ';
												   $where=" courtNO>0  $andItemNo  and  dataStr like '%$keys%' and courtNo='$courtNO' and month='$dM' ";
												   $mList=$os->get_monthlylist($where,'','',' dataStr, itemNo ');
												/* 444444444444  
												
												  if($courtNO==27)
												  {
												  
												  
													_d($itemsNo);
													echo $os->q;
																_d($mList);
													
													//exit();
												  }
													444444444444444   */
												  //echo $os->q.'<br><br>';
												  
												  }	 
														
													
												  #----- monthly data search end 
												
												
												$cases=array();
												$proceedControl=false;
												
												 if($foundStr==true)
												 {
													//$cases=	 preg_split('/\n(\d+)\.\s/', $val,-1,PREG_SPLIT_DELIM_CAPTURE );
													$cases=	 preg_split('/\n(\d+)\./', $val,-1,PREG_SPLIT_DELIM_CAPTURE );  // updated 22 april 2015
													$proceedControl=true;
													
												 }
												 ## add monthly list  
												if(is_array($mList) && count($mList)>0)
												{
													foreach($mList as $val)
													{
													
													
														$cases[]=$val['itemNo']."M";
														$cases[]=$val['dataStr'];
													
													 
													 }
													 $proceedControl=true;
													
												}
													
													
													 ## add monthly list end   
													
												 if($proceedControl==true)
												 {	
													
													
													
													 
															if(is_array($cases))
															{
																
																
																
																foreach($cases as $cvK=>$casesVal)
																{
																   
																
																 
																  if(strlen ($casesVal)<10 )
																  {		
																    // echo $casesVal.'<br>';	
																	 continue;
																	 
																    }	
																	
																	
																	
																	
																	
																	
																	
																	 		
																	// echo $casesVal.'<br>';											  
																   
																   $foundStrSTEP2=false;
																   
															 //   $fStrSplited=strpos(str_replace("\n",'',$casesVal),$keys);  // 2nd step details serch   // str_replace added because keyword may be splited by new line
																   $fStrSplited=strpos($casesVal,$keys);  // 2nd step details serch   
																   if( $fStrSplited!==false){$foundStrSTEP2=true;} 
																   
																   $fStrSplited2=strpos(str_replace("\n",'',$casesVal),$keys);
																   if( $fStrSplited2!==false){$foundStrSTEP2=true;} 
																   
																   
																   
																    $chekedInduvisualMatched=false;  ## filter ITA 62/2011 data search by TA 62/2011  start 8989 
																 
																  preg_match_all("/[A-Z].*?\d+\/\d+/", $casesVal, $xCaseNoM); 
																  ## WP 588/2011  /[A-Z]+\s\d+\/\d+\s/   /[A-Z]* \d*\/\d+\s/
																		$vXC=	$xCaseNoM[0];
																		
																		if(is_array($vXC)){
																		foreach($vXC as $caseNoSplited)
																		{
																		   if($caseNoSplited==$keys){$chekedInduvisualMatched=true;}
																             
																         }}
																 
																
																  if($chekedInduvisualMatched==false )
																  {		
																   
																     continue;
																	 
																  }	
																   
																   # end 8989
																   
																   if( $foundStrSTEP2==true)
																   {
																   
																
																 
																	$itemNo=$cases[$cvK-1];
																	
																	if((int) $itemNo>0)
																	{
																
																  
																	$cV=extractCaseVal($casesVal);
																	
																	//$caseKEY="$courtNO-$itemNo-".rand(200,300);
																	$caseKEY="$courtNO-$itemNo-".$klm;
																	
																
																	$os->casesByExcelCaseNo[$caseKEY]= $cV;
																	$os->casesByExcelCaseNo[$caseKEY]['ITEM NO.']=$itemNo;
																	$os->casesByExcelCaseNo[$caseKEY]['COURT']=$courtNO;
																	
																	  $os->casesByExcelCaseNo[$caseKEY]['DATE']=$xData[3];
																	   $os->casesByExcelCaseNo[$caseKEY]['AOR']=$xData[4];
																	   $os->casesByExcelCaseNo[$caseKEY]['IND']=$xData[7];
																	   $os->casesByExcelCaseNo[$caseKEY]['ERSTWHILE ADVOCATE']=$xData[9];
																	   $os->casesByExcelCaseNo[$caseKEY]['ALLOTMENT TO A.O.R.']=$xData[10];
																	   $os->casesByExcelCaseNo[$caseKEY]['COUNSEL - 1']=$xData[11];
																	   $os->casesByExcelCaseNo[$caseKEY]['CONTACT 1']=$xData[12];
																	   $os->casesByExcelCaseNo[$caseKEY]['ADDRESS']=$xData[13];
																	   $os->casesByExcelCaseNo[$caseKEY]['COUNSEL - 2']=$xData[14];
																	   $os->casesByExcelCaseNo[$caseKEY]['CONTACT 2']=$xData[15];
																	   $os->casesByExcelCaseNo[$caseKEY]['ADDRESS2']=$xData[16];
																	   $os->casesByExcelCaseNo[$caseKEY]['COUNSEL - 3']=$xData[17];
																	   $os->casesByExcelCaseNo[$caseKEY]['CONTACT 3']=$xData[18];
																	   $os->casesByExcelCaseNo[$caseKEY]['ADDRESS3']=$xData[19];
																	   $os->casesByExcelCaseNo[$caseKEY]['REMARKS']=$xData[20];
																	   $os->casesByExcelCaseNo[$caseKEY]['TIME']=$xData[21];
																	
																	
																	
																																	   
																	
																	}
																   
																  
																  
																  
																  
																   } 
																   
																   
																 
																   
																   
																   
																
																   
																}
															}
												 
												 
												 }
												
												  
												
												#--- search string end -----##
													 
													 
													 
													 
													 
												// $floorA = explode("\n",$val);
												// $floor =$floorA['1'];
												//
											  
												
											   
											   }
											 
											 
						}
											 
											 
											 
											 
																 
																 
																 
																 
																 
																 
																 
																  ###   333 end ##
																	
																			  
																  
																				 
																				 
																				 
																				 
																				 
																				
																				  
			             
						 
						 
						 
						 
						 
						    } # 987987 close
						 
						 }
					  
		
		
	   
	          }
	   	        $klm++;
          } 
	
	
	}
	
	
	
	
	function margeCombinedAndDataByExelCaseNo($finalArrCombined,$casesByExcelCaseNo)
	{
			global $os;
			$excelData =array();
			$combineData =array();
			$os->notMatchedData =array();
			$os->notMatchedPlusMatchedData =array();
			if(is_array($casesByExcelCaseNo))
			{
					foreach($casesByExcelCaseNo as $k=>$val)
					{
					  
					  $excelData[$k]= $val['CASE NO'];					
					
					}
			
			
			
			}
			if(is_array($finalArrCombined))
			{
					foreach($finalArrCombined as $k=>$val)
					{
					  
					  $combineData[$k]= $val['CASE NO'];					
					
					}
			
			
			
			}
			
			
			
				
	
			$notMatchedData = array_diff($excelData, $combineData);
			
			$os->notMatchedPlusMatchedData=$os->finalArrCombined;
			if(is_array($notMatchedData))
			{
					foreach($notMatchedData as $k=>$val)
					{
					
					   $os->notMatchedPlusMatchedData[$k]=$casesByExcelCaseNo[$k];
					  
					  	$os->notMatchedData[]=$casesByExcelCaseNo[$k];		
					
					}
			
			
			
			}
			

	
	
	
	}
	
	
	
		
		


}


$os= new os;
